import "../../../../../assets/svelte/svelte_internal_client.js";
import { I as i } from "./Index-CIhZWQmR.js";
import "../../../../../assets/svelte/svelte_internal_flags_legacy.js";
import "../../../../../assets/svelte/svelte_svelte.js";
export {
  i as default
};
