import { g as Km } from "./Index-CIhZWQmR.js";
var ql = {
  name: "mermaid",
  version: "11.12.2",
  description: "Markdown-ish syntax for generating flowcharts, mindmaps, sequence diagrams, class diagrams, gantt charts, git graphs and more.",
  type: "module",
  module: "./dist/mermaid.core.mjs",
  types: "./dist/mermaid.d.ts",
  exports: {
    ".": {
      types: "./dist/mermaid.d.ts",
      import: "./dist/mermaid.core.mjs",
      default: "./dist/mermaid.core.mjs"
    },
    "./*": "./*"
  },
  keywords: [
    "diagram",
    "markdown",
    "flowchart",
    "sequence diagram",
    "gantt",
    "class diagram",
    "git graph",
    "mindmap",
    "packet diagram",
    "c4 diagram",
    "er diagram",
    "pie chart",
    "pie diagram",
    "quadrant chart",
    "requirement diagram",
    "graph"
  ],
  scripts: {
    clean: "rimraf dist",
    dev: "pnpm -w dev",
    "docs:code": "typedoc src/defaultConfig.ts src/config.ts src/mermaid.ts && prettier --write ./src/docs/config/setup",
    "docs:build": "rimraf ../../docs && pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts",
    "docs:verify": "pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts --verify",
    "docs:pre:vitepress": "pnpm --filter ./src/docs prefetch && rimraf src/vitepress && pnpm docs:code && tsx scripts/docs.cli.mts --vitepress && pnpm --filter ./src/vitepress install --no-frozen-lockfile --ignore-scripts",
    "docs:build:vitepress": "pnpm docs:pre:vitepress && (cd src/vitepress && pnpm run build) && cpy --flat src/docs/landing/ ./src/vitepress/.vitepress/dist/landing",
    "docs:dev": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:dev:docker": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev:docker" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:serve": "pnpm docs:build:vitepress && vitepress serve src/vitepress",
    "docs:spellcheck": 'cspell "src/docs/**/*.md"',
    "docs:release-version": "tsx scripts/update-release-version.mts",
    "docs:verify-version": "tsx scripts/update-release-version.mts --verify",
    "types:build-config": "tsx scripts/create-types-from-json-schema.mts",
    "types:verify-config": "tsx scripts/create-types-from-json-schema.mts --verify",
    checkCircle: "npx madge --circular ./src",
    prepublishOnly: "pnpm docs:verify-version"
  },
  repository: {
    type: "git",
    url: "https://github.com/mermaid-js/mermaid"
  },
  author: "Knut Sveidqvist",
  license: "MIT",
  standard: {
    ignore: [
      "**/parser/*.js",
      "dist/**/*.js",
      "cypress/**/*.js"
    ],
    globals: [
      "page"
    ]
  },
  dependencies: {
    "@braintree/sanitize-url": "^7.1.1",
    "@iconify/utils": "^3.0.1",
    "@mermaid-js/parser": "workspace:^",
    "@types/d3": "^7.4.3",
    cytoscape: "^3.29.3",
    "cytoscape-cose-bilkent": "^4.1.0",
    "cytoscape-fcose": "^2.2.0",
    d3: "^7.9.0",
    "d3-sankey": "^0.12.3",
    "dagre-d3-es": "7.0.13",
    dayjs: "^1.11.18",
    dompurify: "^3.2.5",
    katex: "^0.16.22",
    khroma: "^2.1.0",
    "lodash-es": "^4.17.21",
    marked: "^16.2.1",
    roughjs: "^4.6.6",
    stylis: "^4.3.6",
    "ts-dedent": "^2.2.0",
    uuid: "^11.1.0"
  },
  devDependencies: {
    "@adobe/jsonschema2md": "^8.0.5",
    "@iconify/types": "^2.0.0",
    "@types/cytoscape": "^3.21.9",
    "@types/cytoscape-fcose": "^2.2.4",
    "@types/d3-sankey": "^0.12.4",
    "@types/d3-scale": "^4.0.9",
    "@types/d3-scale-chromatic": "^3.1.0",
    "@types/d3-selection": "^3.0.11",
    "@types/d3-shape": "^3.1.7",
    "@types/jsdom": "^21.1.7",
    "@types/katex": "^0.16.7",
    "@types/lodash-es": "^4.17.12",
    "@types/micromatch": "^4.0.9",
    "@types/stylis": "^4.2.7",
    "@types/uuid": "^10.0.0",
    ajv: "^8.17.1",
    canvas: "^3.1.2",
    chokidar: "3.6.0",
    concurrently: "^9.1.2",
    "csstree-validator": "^4.0.1",
    globby: "^14.1.0",
    jison: "^0.4.18",
    "js-base64": "^3.7.8",
    jsdom: "^26.1.0",
    "json-schema-to-typescript": "^15.0.4",
    micromatch: "^4.0.8",
    "path-browserify": "^1.0.1",
    prettier: "^3.5.3",
    remark: "^15.0.1",
    "remark-frontmatter": "^5.0.0",
    "remark-gfm": "^4.0.1",
    rimraf: "^6.0.1",
    "start-server-and-test": "^2.0.13",
    "type-fest": "^4.35.0",
    typedoc: "^0.28.12",
    "typedoc-plugin-markdown": "^4.8.1",
    typescript: "~5.7.3",
    "unist-util-flatmap": "^1.0.0",
    "unist-util-visit": "^5.0.0",
    vitepress: "^1.6.4",
    "vitepress-plugin-search": "1.0.4-alpha.22"
  },
  files: [
    "dist/",
    "README.md"
  ],
  publishConfig: {
    access: "public"
  }
}, wn = { exports: {} }, Qm = wn.exports, Hl;
function Jm() {
  return Hl || (Hl = 1, (function(e, t) {
    (function(r, i) {
      e.exports = i();
    })(Qm, (function() {
      var r = 1e3, i = 6e4, n = 36e5, a = "millisecond", s = "second", o = "minute", l = "hour", c = "day", h = "week", u = "month", f = "quarter", d = "year", g = "date", m = "Invalid Date", y = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, x = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, b = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(B) {
        var L = ["th", "st", "nd", "rd"], T = B % 100;
        return "[" + B + (L[(T - 20) % 10] || L[T] || L[0]) + "]";
      } }, C = function(B, L, T) {
        var E = String(B);
        return !E || E.length >= L ? B : "" + Array(L + 1 - E.length).join(T) + B;
      }, k = { s: C, z: function(B) {
        var L = -B.utcOffset(), T = Math.abs(L), E = Math.floor(T / 60), M = T % 60;
        return (L <= 0 ? "+" : "-") + C(E, 2, "0") + ":" + C(M, 2, "0");
      }, m: function B(L, T) {
        if (L.date() < T.date()) return -B(T, L);
        var E = 12 * (T.year() - L.year()) + (T.month() - L.month()), M = L.clone().add(E, u), q = T - M < 0, X = L.clone().add(E + (q ? -1 : 1), u);
        return +(-(E + (T - M) / (q ? M - X : X - M)) || 0);
      }, a: function(B) {
        return B < 0 ? Math.ceil(B) || 0 : Math.floor(B);
      }, p: function(B) {
        return { M: u, y: d, w: h, d: c, D: g, h: l, m: o, s, ms: a, Q: f }[B] || String(B || "").toLowerCase().replace(/s$/, "");
      }, u: function(B) {
        return B === void 0;
      } }, w = "en", A = {};
      A[w] = b;
      var S = "$isDayjsObject", D = function(B) {
        return B instanceof N || !(!B || !B[S]);
      }, I = function B(L, T, E) {
        var M;
        if (!L) return w;
        if (typeof L == "string") {
          var q = L.toLowerCase();
          A[q] && (M = q), T && (A[q] = T, M = q);
          var X = L.split("-");
          if (!M && X.length > 1) return B(X[0]);
        } else {
          var K = L.name;
          A[K] = L, M = K;
        }
        return !E && M && (w = M), M || !E && w;
      }, O = function(B, L) {
        if (D(B)) return B.clone();
        var T = typeof L == "object" ? L : {};
        return T.date = B, T.args = arguments, new N(T);
      }, $ = k;
      $.l = I, $.i = D, $.w = function(B, L) {
        return O(B, { locale: L.$L, utc: L.$u, x: L.$x, $offset: L.$offset });
      };
      var N = (function() {
        function B(T) {
          this.$L = I(T.locale, null, !0), this.parse(T), this.$x = this.$x || T.x || {}, this[S] = !0;
        }
        var L = B.prototype;
        return L.parse = function(T) {
          this.$d = (function(E) {
            var M = E.date, q = E.utc;
            if (M === null) return /* @__PURE__ */ new Date(NaN);
            if ($.u(M)) return /* @__PURE__ */ new Date();
            if (M instanceof Date) return new Date(M);
            if (typeof M == "string" && !/Z$/i.test(M)) {
              var X = M.match(y);
              if (X) {
                var K = X[2] - 1 || 0, J = (X[7] || "0").substring(0, 3);
                return q ? new Date(Date.UTC(X[1], K, X[3] || 1, X[4] || 0, X[5] || 0, X[6] || 0, J)) : new Date(X[1], K, X[3] || 1, X[4] || 0, X[5] || 0, X[6] || 0, J);
              }
            }
            return new Date(M);
          })(T), this.init();
        }, L.init = function() {
          var T = this.$d;
          this.$y = T.getFullYear(), this.$M = T.getMonth(), this.$D = T.getDate(), this.$W = T.getDay(), this.$H = T.getHours(), this.$m = T.getMinutes(), this.$s = T.getSeconds(), this.$ms = T.getMilliseconds();
        }, L.$utils = function() {
          return $;
        }, L.isValid = function() {
          return this.$d.toString() !== m;
        }, L.isSame = function(T, E) {
          var M = O(T);
          return this.startOf(E) <= M && M <= this.endOf(E);
        }, L.isAfter = function(T, E) {
          return O(T) < this.startOf(E);
        }, L.isBefore = function(T, E) {
          return this.endOf(E) < O(T);
        }, L.$g = function(T, E, M) {
          return $.u(T) ? this[E] : this.set(M, T);
        }, L.unix = function() {
          return Math.floor(this.valueOf() / 1e3);
        }, L.valueOf = function() {
          return this.$d.getTime();
        }, L.startOf = function(T, E) {
          var M = this, q = !!$.u(E) || E, X = $.p(T), K = function(re, yt) {
            var ie = $.w(M.$u ? Date.UTC(M.$y, yt, re) : new Date(M.$y, yt, re), M);
            return q ? ie : ie.endOf(c);
          }, J = function(re, yt) {
            return $.w(M.toDate()[re].apply(M.toDate("s"), (q ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(yt)), M);
          }, Z = this.$W, ct = this.$M, at = this.$D, bt = "set" + (this.$u ? "UTC" : "");
          switch (X) {
            case d:
              return q ? K(1, 0) : K(31, 11);
            case u:
              return q ? K(1, ct) : K(0, ct + 1);
            case h:
              var Ct = this.$locale().weekStart || 0, Pt = (Z < Ct ? Z + 7 : Z) - Ct;
              return K(q ? at - Pt : at + (6 - Pt), ct);
            case c:
            case g:
              return J(bt + "Hours", 0);
            case l:
              return J(bt + "Minutes", 1);
            case o:
              return J(bt + "Seconds", 2);
            case s:
              return J(bt + "Milliseconds", 3);
            default:
              return this.clone();
          }
        }, L.endOf = function(T) {
          return this.startOf(T, !1);
        }, L.$set = function(T, E) {
          var M, q = $.p(T), X = "set" + (this.$u ? "UTC" : ""), K = (M = {}, M[c] = X + "Date", M[g] = X + "Date", M[u] = X + "Month", M[d] = X + "FullYear", M[l] = X + "Hours", M[o] = X + "Minutes", M[s] = X + "Seconds", M[a] = X + "Milliseconds", M)[q], J = q === c ? this.$D + (E - this.$W) : E;
          if (q === u || q === d) {
            var Z = this.clone().set(g, 1);
            Z.$d[K](J), Z.init(), this.$d = Z.set(g, Math.min(this.$D, Z.daysInMonth())).$d;
          } else K && this.$d[K](J);
          return this.init(), this;
        }, L.set = function(T, E) {
          return this.clone().$set(T, E);
        }, L.get = function(T) {
          return this[$.p(T)]();
        }, L.add = function(T, E) {
          var M, q = this;
          T = Number(T);
          var X = $.p(E), K = function(ct) {
            var at = O(q);
            return $.w(at.date(at.date() + Math.round(ct * T)), q);
          };
          if (X === u) return this.set(u, this.$M + T);
          if (X === d) return this.set(d, this.$y + T);
          if (X === c) return K(1);
          if (X === h) return K(7);
          var J = (M = {}, M[o] = i, M[l] = n, M[s] = r, M)[X] || 1, Z = this.$d.getTime() + T * J;
          return $.w(Z, this);
        }, L.subtract = function(T, E) {
          return this.add(-1 * T, E);
        }, L.format = function(T) {
          var E = this, M = this.$locale();
          if (!this.isValid()) return M.invalidDate || m;
          var q = T || "YYYY-MM-DDTHH:mm:ssZ", X = $.z(this), K = this.$H, J = this.$m, Z = this.$M, ct = M.weekdays, at = M.months, bt = M.meridiem, Ct = function(yt, ie, Pe, ne) {
            return yt && (yt[ie] || yt(E, q)) || Pe[ie].slice(0, ne);
          }, Pt = function(yt) {
            return $.s(K % 12 || 12, yt, "0");
          }, re = bt || function(yt, ie, Pe) {
            var ne = yt < 12 ? "AM" : "PM";
            return Pe ? ne.toLowerCase() : ne;
          };
          return q.replace(x, (function(yt, ie) {
            return ie || (function(Pe) {
              switch (Pe) {
                case "YY":
                  return String(E.$y).slice(-2);
                case "YYYY":
                  return $.s(E.$y, 4, "0");
                case "M":
                  return Z + 1;
                case "MM":
                  return $.s(Z + 1, 2, "0");
                case "MMM":
                  return Ct(M.monthsShort, Z, at, 3);
                case "MMMM":
                  return Ct(at, Z);
                case "D":
                  return E.$D;
                case "DD":
                  return $.s(E.$D, 2, "0");
                case "d":
                  return String(E.$W);
                case "dd":
                  return Ct(M.weekdaysMin, E.$W, ct, 2);
                case "ddd":
                  return Ct(M.weekdaysShort, E.$W, ct, 3);
                case "dddd":
                  return ct[E.$W];
                case "H":
                  return String(K);
                case "HH":
                  return $.s(K, 2, "0");
                case "h":
                  return Pt(1);
                case "hh":
                  return Pt(2);
                case "a":
                  return re(K, J, !0);
                case "A":
                  return re(K, J, !1);
                case "m":
                  return String(J);
                case "mm":
                  return $.s(J, 2, "0");
                case "s":
                  return String(E.$s);
                case "ss":
                  return $.s(E.$s, 2, "0");
                case "SSS":
                  return $.s(E.$ms, 3, "0");
                case "Z":
                  return X;
              }
              return null;
            })(yt) || X.replace(":", "");
          }));
        }, L.utcOffset = function() {
          return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
        }, L.diff = function(T, E, M) {
          var q, X = this, K = $.p(E), J = O(T), Z = (J.utcOffset() - this.utcOffset()) * i, ct = this - J, at = function() {
            return $.m(X, J);
          };
          switch (K) {
            case d:
              q = at() / 12;
              break;
            case u:
              q = at();
              break;
            case f:
              q = at() / 3;
              break;
            case h:
              q = (ct - Z) / 6048e5;
              break;
            case c:
              q = (ct - Z) / 864e5;
              break;
            case l:
              q = ct / n;
              break;
            case o:
              q = ct / i;
              break;
            case s:
              q = ct / r;
              break;
            default:
              q = ct;
          }
          return M ? q : $.a(q);
        }, L.daysInMonth = function() {
          return this.endOf(u).$D;
        }, L.$locale = function() {
          return A[this.$L];
        }, L.locale = function(T, E) {
          if (!T) return this.$L;
          var M = this.clone(), q = I(T, E, !0);
          return q && (M.$L = q), M;
        }, L.clone = function() {
          return $.w(this.$d, this);
        }, L.toDate = function() {
          return new Date(this.valueOf());
        }, L.toJSON = function() {
          return this.isValid() ? this.toISOString() : null;
        }, L.toISOString = function() {
          return this.$d.toISOString();
        }, L.toString = function() {
          return this.$d.toUTCString();
        }, B;
      })(), R = N.prototype;
      return O.prototype = R, [["$ms", a], ["$s", s], ["$m", o], ["$H", l], ["$W", c], ["$M", u], ["$y", d], ["$D", g]].forEach((function(B) {
        R[B[1]] = function(L) {
          return this.$g(L, B[0], B[1]);
        };
      })), O.extend = function(B, L) {
        return B.$i || (B(L, N, O), B.$i = !0), O;
      }, O.locale = I, O.isDayjs = D, O.unix = function(B) {
        return O(1e3 * B);
      }, O.en = A[w], O.Ls = A, O.p = {}, O;
    }));
  })(wn)), wn.exports;
}
var t0 = Jm();
const e0 = /* @__PURE__ */ Km(t0);
var vh = Object.defineProperty, p = (e, t) => vh(e, "name", { value: t, configurable: !0 }), r0 = (e, t) => {
  for (var r in t)
    vh(e, r, { get: t[r], enumerable: !0 });
}, Ae = {
  trace: 0,
  debug: 1,
  info: 2,
  warn: 3,
  error: 4,
  fatal: 5
}, F = {
  trace: /* @__PURE__ */ p((...e) => {
  }, "trace"),
  debug: /* @__PURE__ */ p((...e) => {
  }, "debug"),
  info: /* @__PURE__ */ p((...e) => {
  }, "info"),
  warn: /* @__PURE__ */ p((...e) => {
  }, "warn"),
  error: /* @__PURE__ */ p((...e) => {
  }, "error"),
  fatal: /* @__PURE__ */ p((...e) => {
  }, "fatal")
}, ko = /* @__PURE__ */ p(function(e = "fatal") {
  let t = Ae.fatal;
  typeof e == "string" ? e.toLowerCase() in Ae && (t = Ae[e]) : typeof e == "number" && (t = e), F.trace = () => {
  }, F.debug = () => {
  }, F.info = () => {
  }, F.warn = () => {
  }, F.error = () => {
  }, F.fatal = () => {
  }, t <= Ae.fatal && (F.fatal = console.error ? console.error.bind(console, Qt("FATAL"), "color: orange") : console.log.bind(console, "\x1B[35m", Qt("FATAL"))), t <= Ae.error && (F.error = console.error ? console.error.bind(console, Qt("ERROR"), "color: orange") : console.log.bind(console, "\x1B[31m", Qt("ERROR"))), t <= Ae.warn && (F.warn = console.warn ? console.warn.bind(console, Qt("WARN"), "color: orange") : console.log.bind(console, "\x1B[33m", Qt("WARN"))), t <= Ae.info && (F.info = console.info ? console.info.bind(console, Qt("INFO"), "color: lightblue") : console.log.bind(console, "\x1B[34m", Qt("INFO"))), t <= Ae.debug && (F.debug = console.debug ? console.debug.bind(console, Qt("DEBUG"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", Qt("DEBUG"))), t <= Ae.trace && (F.trace = console.debug ? console.debug.bind(console, Qt("TRACE"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", Qt("TRACE")));
}, "setLogLevel"), Qt = /* @__PURE__ */ p((e) => `%c${e0().format("ss.SSS")} : ${e} : `, "format");
const kn = {
  /* CLAMP */
  min: {
    r: 0,
    g: 0,
    b: 0,
    s: 0,
    l: 0,
    a: 0
  },
  max: {
    r: 255,
    g: 255,
    b: 255,
    h: 360,
    s: 100,
    l: 100,
    a: 1
  },
  clamp: {
    r: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    g: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    b: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    h: (e) => e % 360,
    s: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    l: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    a: (e) => e >= 1 ? 1 : e < 0 ? 0 : e
  },
  /* CONVERSION */
  //SOURCE: https://planetcalc.com/7779
  toLinear: (e) => {
    const t = e / 255;
    return e > 0.03928 ? Math.pow((t + 0.055) / 1.055, 2.4) : t / 12.92;
  },
  //SOURCE: https://gist.github.com/mjackson/5311256
  hue2rgb: (e, t, r) => (r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + (t - e) * 6 * r : r < 1 / 2 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e),
  hsl2rgb: ({ h: e, s: t, l: r }, i) => {
    if (!t)
      return r * 2.55;
    e /= 360, t /= 100, r /= 100;
    const n = r < 0.5 ? r * (1 + t) : r + t - r * t, a = 2 * r - n;
    switch (i) {
      case "r":
        return kn.hue2rgb(a, n, e + 1 / 3) * 255;
      case "g":
        return kn.hue2rgb(a, n, e) * 255;
      case "b":
        return kn.hue2rgb(a, n, e - 1 / 3) * 255;
    }
  },
  rgb2hsl: ({ r: e, g: t, b: r }, i) => {
    e /= 255, t /= 255, r /= 255;
    const n = Math.max(e, t, r), a = Math.min(e, t, r), s = (n + a) / 2;
    if (i === "l")
      return s * 100;
    if (n === a)
      return 0;
    const o = n - a, l = s > 0.5 ? o / (2 - n - a) : o / (n + a);
    if (i === "s")
      return l * 100;
    switch (n) {
      case e:
        return ((t - r) / o + (t < r ? 6 : 0)) * 60;
      case t:
        return ((r - e) / o + 2) * 60;
      case r:
        return ((e - t) / o + 4) * 60;
      default:
        return -1;
    }
  }
}, i0 = {
  /* API */
  clamp: (e, t, r) => t > r ? Math.min(t, Math.max(r, e)) : Math.min(r, Math.max(t, e)),
  round: (e) => Math.round(e * 1e10) / 1e10
}, n0 = {
  /* API */
  dec2hex: (e) => {
    const t = Math.round(e).toString(16);
    return t.length > 1 ? t : `0${t}`;
  }
}, st = {
  channel: kn,
  lang: i0,
  unit: n0
}, Ne = {};
for (let e = 0; e <= 255; e++)
  Ne[e] = st.unit.dec2hex(e);
const Et = {
  ALL: 0,
  RGB: 1,
  HSL: 2
};
class a0 {
  constructor() {
    this.type = Et.ALL;
  }
  /* API */
  get() {
    return this.type;
  }
  set(t) {
    if (this.type && this.type !== t)
      throw new Error("Cannot change both RGB and HSL channels at the same time");
    this.type = t;
  }
  reset() {
    this.type = Et.ALL;
  }
  is(t) {
    return this.type === t;
  }
}
class s0 {
  /* CONSTRUCTOR */
  constructor(t, r) {
    this.color = r, this.changed = !1, this.data = t, this.type = new a0();
  }
  /* API */
  set(t, r) {
    return this.color = r, this.changed = !1, this.data = t, this.type.type = Et.ALL, this;
  }
  /* HELPERS */
  _ensureHSL() {
    const t = this.data, { h: r, s: i, l: n } = t;
    r === void 0 && (t.h = st.channel.rgb2hsl(t, "h")), i === void 0 && (t.s = st.channel.rgb2hsl(t, "s")), n === void 0 && (t.l = st.channel.rgb2hsl(t, "l"));
  }
  _ensureRGB() {
    const t = this.data, { r, g: i, b: n } = t;
    r === void 0 && (t.r = st.channel.hsl2rgb(t, "r")), i === void 0 && (t.g = st.channel.hsl2rgb(t, "g")), n === void 0 && (t.b = st.channel.hsl2rgb(t, "b"));
  }
  /* GETTERS */
  get r() {
    const t = this.data, r = t.r;
    return !this.type.is(Et.HSL) && r !== void 0 ? r : (this._ensureHSL(), st.channel.hsl2rgb(t, "r"));
  }
  get g() {
    const t = this.data, r = t.g;
    return !this.type.is(Et.HSL) && r !== void 0 ? r : (this._ensureHSL(), st.channel.hsl2rgb(t, "g"));
  }
  get b() {
    const t = this.data, r = t.b;
    return !this.type.is(Et.HSL) && r !== void 0 ? r : (this._ensureHSL(), st.channel.hsl2rgb(t, "b"));
  }
  get h() {
    const t = this.data, r = t.h;
    return !this.type.is(Et.RGB) && r !== void 0 ? r : (this._ensureRGB(), st.channel.rgb2hsl(t, "h"));
  }
  get s() {
    const t = this.data, r = t.s;
    return !this.type.is(Et.RGB) && r !== void 0 ? r : (this._ensureRGB(), st.channel.rgb2hsl(t, "s"));
  }
  get l() {
    const t = this.data, r = t.l;
    return !this.type.is(Et.RGB) && r !== void 0 ? r : (this._ensureRGB(), st.channel.rgb2hsl(t, "l"));
  }
  get a() {
    return this.data.a;
  }
  /* SETTERS */
  set r(t) {
    this.type.set(Et.RGB), this.changed = !0, this.data.r = t;
  }
  set g(t) {
    this.type.set(Et.RGB), this.changed = !0, this.data.g = t;
  }
  set b(t) {
    this.type.set(Et.RGB), this.changed = !0, this.data.b = t;
  }
  set h(t) {
    this.type.set(Et.HSL), this.changed = !0, this.data.h = t;
  }
  set s(t) {
    this.type.set(Et.HSL), this.changed = !0, this.data.s = t;
  }
  set l(t) {
    this.type.set(Et.HSL), this.changed = !0, this.data.l = t;
  }
  set a(t) {
    this.changed = !0, this.data.a = t;
  }
}
const ba = new s0({ r: 0, g: 0, b: 0, a: 0 }, "transparent"), Er = {
  /* VARIABLES */
  re: /^#((?:[a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i,
  /* API */
  parse: (e) => {
    if (e.charCodeAt(0) !== 35)
      return;
    const t = e.match(Er.re);
    if (!t)
      return;
    const r = t[1], i = parseInt(r, 16), n = r.length, a = n % 4 === 0, s = n > 4, o = s ? 1 : 17, l = s ? 8 : 4, c = a ? 0 : -1, h = s ? 255 : 15;
    return ba.set({
      r: (i >> l * (c + 3) & h) * o,
      g: (i >> l * (c + 2) & h) * o,
      b: (i >> l * (c + 1) & h) * o,
      a: a ? (i & h) * o / 255 : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `#${Ne[Math.round(t)]}${Ne[Math.round(r)]}${Ne[Math.round(i)]}${Ne[Math.round(n * 255)]}` : `#${Ne[Math.round(t)]}${Ne[Math.round(r)]}${Ne[Math.round(i)]}`;
  }
}, ir = {
  /* VARIABLES */
  re: /^hsla?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(?:deg|grad|rad|turn)?)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(%)?))?\s*?\)$/i,
  hueRe: /^(.+?)(deg|grad|rad|turn)$/i,
  /* HELPERS */
  _hue2deg: (e) => {
    const t = e.match(ir.hueRe);
    if (t) {
      const [, r, i] = t;
      switch (i) {
        case "grad":
          return st.channel.clamp.h(parseFloat(r) * 0.9);
        case "rad":
          return st.channel.clamp.h(parseFloat(r) * 180 / Math.PI);
        case "turn":
          return st.channel.clamp.h(parseFloat(r) * 360);
      }
    }
    return st.channel.clamp.h(parseFloat(e));
  },
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 104 && t !== 72)
      return;
    const r = e.match(ir.re);
    if (!r)
      return;
    const [, i, n, a, s, o] = r;
    return ba.set({
      h: ir._hue2deg(i),
      s: st.channel.clamp.s(parseFloat(n)),
      l: st.channel.clamp.l(parseFloat(a)),
      a: s ? st.channel.clamp.a(o ? parseFloat(s) / 100 : parseFloat(s)) : 1
    }, e);
  },
  stringify: (e) => {
    const { h: t, s: r, l: i, a: n } = e;
    return n < 1 ? `hsla(${st.lang.round(t)}, ${st.lang.round(r)}%, ${st.lang.round(i)}%, ${n})` : `hsl(${st.lang.round(t)}, ${st.lang.round(r)}%, ${st.lang.round(i)}%)`;
  }
}, Ti = {
  /* VARIABLES */
  colors: {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyanaqua: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    transparent: "#00000000",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
  },
  /* API */
  parse: (e) => {
    e = e.toLowerCase();
    const t = Ti.colors[e];
    if (t)
      return Er.parse(t);
  },
  stringify: (e) => {
    const t = Er.stringify(e);
    for (const r in Ti.colors)
      if (Ti.colors[r] === t)
        return r;
  }
}, yi = {
  /* VARIABLES */
  re: /^rgba?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?)))?\s*?\)$/i,
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 114 && t !== 82)
      return;
    const r = e.match(yi.re);
    if (!r)
      return;
    const [, i, n, a, s, o, l, c, h] = r;
    return ba.set({
      r: st.channel.clamp.r(n ? parseFloat(i) * 2.55 : parseFloat(i)),
      g: st.channel.clamp.g(s ? parseFloat(a) * 2.55 : parseFloat(a)),
      b: st.channel.clamp.b(l ? parseFloat(o) * 2.55 : parseFloat(o)),
      a: c ? st.channel.clamp.a(h ? parseFloat(c) / 100 : parseFloat(c)) : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `rgba(${st.lang.round(t)}, ${st.lang.round(r)}, ${st.lang.round(i)}, ${st.lang.round(n)})` : `rgb(${st.lang.round(t)}, ${st.lang.round(r)}, ${st.lang.round(i)})`;
  }
}, _e = {
  /* VARIABLES */
  format: {
    keyword: Ti,
    hex: Er,
    rgb: yi,
    rgba: yi,
    hsl: ir,
    hsla: ir
  },
  /* API */
  parse: (e) => {
    if (typeof e != "string")
      return e;
    const t = Er.parse(e) || yi.parse(e) || ir.parse(e) || Ti.parse(e);
    if (t)
      return t;
    throw new Error(`Unsupported color format: "${e}"`);
  },
  stringify: (e) => !e.changed && e.color ? e.color : e.type.is(Et.HSL) || e.data.r === void 0 ? ir.stringify(e) : e.a < 1 || !Number.isInteger(e.r) || !Number.isInteger(e.g) || !Number.isInteger(e.b) ? yi.stringify(e) : Er.stringify(e)
}, Sh = (e, t) => {
  const r = _e.parse(e);
  for (const i in t)
    r[i] = st.channel.clamp[i](t[i]);
  return _e.stringify(r);
}, Bi = (e, t, r = 0, i = 1) => {
  if (typeof e != "number")
    return Sh(e, { a: t });
  const n = ba.set({
    r: st.channel.clamp.r(e),
    g: st.channel.clamp.g(t),
    b: st.channel.clamp.b(r),
    a: st.channel.clamp.a(i)
  });
  return _e.stringify(n);
}, o0 = (e) => {
  const { r: t, g: r, b: i } = _e.parse(e), n = 0.2126 * st.channel.toLinear(t) + 0.7152 * st.channel.toLinear(r) + 0.0722 * st.channel.toLinear(i);
  return st.lang.round(n);
}, l0 = (e) => o0(e) >= 0.5, Yi = (e) => !l0(e), Th = (e, t, r) => {
  const i = _e.parse(e), n = i[t], a = st.channel.clamp[t](n + r);
  return n !== a && (i[t] = a), _e.stringify(i);
}, H = (e, t) => Th(e, "l", t), et = (e, t) => Th(e, "l", -t), v = (e, t) => {
  const r = _e.parse(e), i = {};
  for (const n in t)
    t[n] && (i[n] = r[n] + t[n]);
  return Sh(e, i);
}, c0 = (e, t, r = 50) => {
  const { r: i, g: n, b: a, a: s } = _e.parse(e), { r: o, g: l, b: c, a: h } = _e.parse(t), u = r / 100, f = u * 2 - 1, d = s - h, m = ((f * d === -1 ? f : (f + d) / (1 + f * d)) + 1) / 2, y = 1 - m, x = i * m + o * y, b = n * m + l * y, C = a * m + c * y, k = s * u + h * (1 - u);
  return Bi(x, b, C, k);
}, z = (e, t = 100) => {
  const r = _e.parse(e);
  return r.r = 255 - r.r, r.g = 255 - r.g, r.b = 255 - r.b, c0(r, e, t);
};
const {
  entries: Bh,
  setPrototypeOf: jl,
  isFrozen: h0,
  getPrototypeOf: u0,
  getOwnPropertyDescriptor: f0
} = Object;
let {
  freeze: Ht,
  seal: Jt,
  create: ks
} = Object, {
  apply: vs,
  construct: Ss
} = typeof Reflect < "u" && Reflect;
Ht || (Ht = function(t) {
  return t;
});
Jt || (Jt = function(t) {
  return t;
});
vs || (vs = function(t, r) {
  for (var i = arguments.length, n = new Array(i > 2 ? i - 2 : 0), a = 2; a < i; a++)
    n[a - 2] = arguments[a];
  return t.apply(r, n);
});
Ss || (Ss = function(t) {
  for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++)
    i[n - 1] = arguments[n];
  return new t(...i);
});
const cn = jt(Array.prototype.forEach), d0 = jt(Array.prototype.lastIndexOf), Yl = jt(Array.prototype.pop), si = jt(Array.prototype.push), p0 = jt(Array.prototype.splice), vn = jt(String.prototype.toLowerCase), rs = jt(String.prototype.toString), is = jt(String.prototype.match), oi = jt(String.prototype.replace), g0 = jt(String.prototype.indexOf), m0 = jt(String.prototype.trim), ae = jt(Object.prototype.hasOwnProperty), Nt = jt(RegExp.prototype.test), li = y0(TypeError);
function jt(e) {
  return function(t) {
    t instanceof RegExp && (t.lastIndex = 0);
    for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++)
      i[n - 1] = arguments[n];
    return vs(e, t, i);
  };
}
function y0(e) {
  return function() {
    for (var t = arguments.length, r = new Array(t), i = 0; i < t; i++)
      r[i] = arguments[i];
    return Ss(e, r);
  };
}
function ot(e, t) {
  let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : vn;
  jl && jl(e, null);
  let i = t.length;
  for (; i--; ) {
    let n = t[i];
    if (typeof n == "string") {
      const a = r(n);
      a !== n && (h0(t) || (t[i] = a), n = a);
    }
    e[n] = !0;
  }
  return e;
}
function x0(e) {
  for (let t = 0; t < e.length; t++)
    ae(e, t) || (e[t] = null);
  return e;
}
function me(e) {
  const t = ks(null);
  for (const [r, i] of Bh(e))
    ae(e, r) && (Array.isArray(i) ? t[r] = x0(i) : i && typeof i == "object" && i.constructor === Object ? t[r] = me(i) : t[r] = i);
  return t;
}
function ci(e, t) {
  for (; e !== null; ) {
    const i = f0(e, t);
    if (i) {
      if (i.get)
        return jt(i.get);
      if (typeof i.value == "function")
        return jt(i.value);
    }
    e = u0(e);
  }
  function r() {
    return null;
  }
  return r;
}
const Ul = Ht(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "search", "section", "select", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), ns = Ht(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "enterkeyhint", "exportparts", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "inputmode", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "part", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), as = Ht(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), b0 = Ht(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), ss = Ht(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), C0 = Ht(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Gl = Ht(["#text"]), Xl = Ht(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "exportparts", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inert", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "part", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "slot", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), os = Ht(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "mask-type", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Vl = Ht(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), hn = Ht(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), _0 = Jt(/\{\{[\w\W]*|[\w\W]*\}\}/gm), w0 = Jt(/<%[\w\W]*|[\w\W]*%>/gm), k0 = Jt(/\$\{[\w\W]*/gm), v0 = Jt(/^data-[\-\w.\u00B7-\uFFFF]+$/), S0 = Jt(/^aria-[\-\w]+$/), Ah = Jt(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), T0 = Jt(/^(?:\w+script|data):/i), B0 = Jt(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Lh = Jt(/^html$/i), A0 = Jt(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Zl = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: S0,
  ATTR_WHITESPACE: B0,
  CUSTOM_ELEMENT: A0,
  DATA_ATTR: v0,
  DOCTYPE_NAME: Lh,
  ERB_EXPR: w0,
  IS_ALLOWED_URI: Ah,
  IS_SCRIPT_OR_DATA: T0,
  MUSTACHE_EXPR: _0,
  TMPLIT_EXPR: k0
});
const hi = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, L0 = function() {
  return typeof window > "u" ? null : window;
}, M0 = function(t, r) {
  if (typeof t != "object" || typeof t.createPolicy != "function")
    return null;
  let i = null;
  const n = "data-tt-policy-suffix";
  r && r.hasAttribute(n) && (i = r.getAttribute(n));
  const a = "dompurify" + (i ? "#" + i : "");
  try {
    return t.createPolicy(a, {
      createHTML(s) {
        return s;
      },
      createScriptURL(s) {
        return s;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + a + " could not be created."), null;
  }
}, Kl = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Mh() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : L0();
  const t = (tt) => Mh(tt);
  if (t.version = "3.3.1", t.removed = [], !e || !e.document || e.document.nodeType !== hi.document || !e.Element)
    return t.isSupported = !1, t;
  let {
    document: r
  } = e;
  const i = r, n = i.currentScript, {
    DocumentFragment: a,
    HTMLTemplateElement: s,
    Node: o,
    Element: l,
    NodeFilter: c,
    NamedNodeMap: h = e.NamedNodeMap || e.MozNamedAttrMap,
    HTMLFormElement: u,
    DOMParser: f,
    trustedTypes: d
  } = e, g = l.prototype, m = ci(g, "cloneNode"), y = ci(g, "remove"), x = ci(g, "nextSibling"), b = ci(g, "childNodes"), C = ci(g, "parentNode");
  if (typeof s == "function") {
    const tt = r.createElement("template");
    tt.content && tt.content.ownerDocument && (r = tt.content.ownerDocument);
  }
  let k, w = "";
  const {
    implementation: A,
    createNodeIterator: S,
    createDocumentFragment: D,
    getElementsByTagName: I
  } = r, {
    importNode: O
  } = i;
  let $ = Kl();
  t.isSupported = typeof Bh == "function" && typeof C == "function" && A && A.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: N,
    ERB_EXPR: R,
    TMPLIT_EXPR: B,
    DATA_ATTR: L,
    ARIA_ATTR: T,
    IS_SCRIPT_OR_DATA: E,
    ATTR_WHITESPACE: M,
    CUSTOM_ELEMENT: q
  } = Zl;
  let {
    IS_ALLOWED_URI: X
  } = Zl, K = null;
  const J = ot({}, [...Ul, ...ns, ...as, ...ss, ...Gl]);
  let Z = null;
  const ct = ot({}, [...Xl, ...os, ...Vl, ...hn]);
  let at = Object.seal(ks(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), bt = null, Ct = null;
  const Pt = Object.seal(ks(null, {
    tagCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    }
  }));
  let re = !0, yt = !0, ie = !1, Pe = !0, ne = !1, en = !0, Ke = !1, Ua = !1, Ga = !1, wr = !1, rn = !1, nn = !1, Sl = !0, Tl = !1;
  const Hm = "user-content-";
  let Xa = !0, ni = !1, kr = {}, de = null;
  const Va = ot({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Bl = null;
  const Al = ot({}, ["audio", "video", "img", "source", "image", "track"]);
  let Za = null;
  const Ll = ot({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), an = "http://www.w3.org/1998/Math/MathML", sn = "http://www.w3.org/2000/svg", Se = "http://www.w3.org/1999/xhtml";
  let vr = Se, Ka = !1, Qa = null;
  const jm = ot({}, [an, sn, Se], rs);
  let on = ot({}, ["mi", "mo", "mn", "ms", "mtext"]), ln = ot({}, ["annotation-xml"]);
  const Ym = ot({}, ["title", "style", "font", "a", "script"]);
  let ai = null;
  const Um = ["application/xhtml+xml", "text/html"], Gm = "text/html";
  let kt = null, Sr = null;
  const Xm = r.createElement("form"), Ml = function(_) {
    return _ instanceof RegExp || _ instanceof Function;
  }, Ja = function() {
    let _ = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Sr && Sr === _)) {
      if ((!_ || typeof _ != "object") && (_ = {}), _ = me(_), ai = // eslint-disable-next-line unicorn/prefer-includes
      Um.indexOf(_.PARSER_MEDIA_TYPE) === -1 ? Gm : _.PARSER_MEDIA_TYPE, kt = ai === "application/xhtml+xml" ? rs : vn, K = ae(_, "ALLOWED_TAGS") ? ot({}, _.ALLOWED_TAGS, kt) : J, Z = ae(_, "ALLOWED_ATTR") ? ot({}, _.ALLOWED_ATTR, kt) : ct, Qa = ae(_, "ALLOWED_NAMESPACES") ? ot({}, _.ALLOWED_NAMESPACES, rs) : jm, Za = ae(_, "ADD_URI_SAFE_ATTR") ? ot(me(Ll), _.ADD_URI_SAFE_ATTR, kt) : Ll, Bl = ae(_, "ADD_DATA_URI_TAGS") ? ot(me(Al), _.ADD_DATA_URI_TAGS, kt) : Al, de = ae(_, "FORBID_CONTENTS") ? ot({}, _.FORBID_CONTENTS, kt) : Va, bt = ae(_, "FORBID_TAGS") ? ot({}, _.FORBID_TAGS, kt) : me({}), Ct = ae(_, "FORBID_ATTR") ? ot({}, _.FORBID_ATTR, kt) : me({}), kr = ae(_, "USE_PROFILES") ? _.USE_PROFILES : !1, re = _.ALLOW_ARIA_ATTR !== !1, yt = _.ALLOW_DATA_ATTR !== !1, ie = _.ALLOW_UNKNOWN_PROTOCOLS || !1, Pe = _.ALLOW_SELF_CLOSE_IN_ATTR !== !1, ne = _.SAFE_FOR_TEMPLATES || !1, en = _.SAFE_FOR_XML !== !1, Ke = _.WHOLE_DOCUMENT || !1, wr = _.RETURN_DOM || !1, rn = _.RETURN_DOM_FRAGMENT || !1, nn = _.RETURN_TRUSTED_TYPE || !1, Ga = _.FORCE_BODY || !1, Sl = _.SANITIZE_DOM !== !1, Tl = _.SANITIZE_NAMED_PROPS || !1, Xa = _.KEEP_CONTENT !== !1, ni = _.IN_PLACE || !1, X = _.ALLOWED_URI_REGEXP || Ah, vr = _.NAMESPACE || Se, on = _.MATHML_TEXT_INTEGRATION_POINTS || on, ln = _.HTML_INTEGRATION_POINTS || ln, at = _.CUSTOM_ELEMENT_HANDLING || {}, _.CUSTOM_ELEMENT_HANDLING && Ml(_.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (at.tagNameCheck = _.CUSTOM_ELEMENT_HANDLING.tagNameCheck), _.CUSTOM_ELEMENT_HANDLING && Ml(_.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (at.attributeNameCheck = _.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), _.CUSTOM_ELEMENT_HANDLING && typeof _.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (at.allowCustomizedBuiltInElements = _.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), ne && (yt = !1), rn && (wr = !0), kr && (K = ot({}, Gl), Z = [], kr.html === !0 && (ot(K, Ul), ot(Z, Xl)), kr.svg === !0 && (ot(K, ns), ot(Z, os), ot(Z, hn)), kr.svgFilters === !0 && (ot(K, as), ot(Z, os), ot(Z, hn)), kr.mathMl === !0 && (ot(K, ss), ot(Z, Vl), ot(Z, hn))), _.ADD_TAGS && (typeof _.ADD_TAGS == "function" ? Pt.tagCheck = _.ADD_TAGS : (K === J && (K = me(K)), ot(K, _.ADD_TAGS, kt))), _.ADD_ATTR && (typeof _.ADD_ATTR == "function" ? Pt.attributeCheck = _.ADD_ATTR : (Z === ct && (Z = me(Z)), ot(Z, _.ADD_ATTR, kt))), _.ADD_URI_SAFE_ATTR && ot(Za, _.ADD_URI_SAFE_ATTR, kt), _.FORBID_CONTENTS && (de === Va && (de = me(de)), ot(de, _.FORBID_CONTENTS, kt)), _.ADD_FORBID_CONTENTS && (de === Va && (de = me(de)), ot(de, _.ADD_FORBID_CONTENTS, kt)), Xa && (K["#text"] = !0), Ke && ot(K, ["html", "head", "body"]), K.table && (ot(K, ["tbody"]), delete bt.tbody), _.TRUSTED_TYPES_POLICY) {
        if (typeof _.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw li('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof _.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw li('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        k = _.TRUSTED_TYPES_POLICY, w = k.createHTML("");
      } else
        k === void 0 && (k = M0(d, n)), k !== null && typeof w == "string" && (w = k.createHTML(""));
      Ht && Ht(_), Sr = _;
    }
  }, $l = ot({}, [...ns, ...as, ...b0]), El = ot({}, [...ss, ...C0]), Vm = function(_) {
    let P = C(_);
    (!P || !P.tagName) && (P = {
      namespaceURI: vr,
      tagName: "template"
    });
    const V = vn(_.tagName), gt = vn(P.tagName);
    return Qa[_.namespaceURI] ? _.namespaceURI === sn ? P.namespaceURI === Se ? V === "svg" : P.namespaceURI === an ? V === "svg" && (gt === "annotation-xml" || on[gt]) : !!$l[V] : _.namespaceURI === an ? P.namespaceURI === Se ? V === "math" : P.namespaceURI === sn ? V === "math" && ln[gt] : !!El[V] : _.namespaceURI === Se ? P.namespaceURI === sn && !ln[gt] || P.namespaceURI === an && !on[gt] ? !1 : !El[V] && (Ym[V] || !$l[V]) : !!(ai === "application/xhtml+xml" && Qa[_.namespaceURI]) : !1;
  }, pe = function(_) {
    si(t.removed, {
      element: _
    });
    try {
      C(_).removeChild(_);
    } catch {
      y(_);
    }
  }, Qe = function(_, P) {
    try {
      si(t.removed, {
        attribute: P.getAttributeNode(_),
        from: P
      });
    } catch {
      si(t.removed, {
        attribute: null,
        from: P
      });
    }
    if (P.removeAttribute(_), _ === "is")
      if (wr || rn)
        try {
          pe(P);
        } catch {
        }
      else
        try {
          P.setAttribute(_, "");
        } catch {
        }
  }, Fl = function(_) {
    let P = null, V = null;
    if (Ga)
      _ = "<remove></remove>" + _;
    else {
      const _t = is(_, /^[\r\n\t ]+/);
      V = _t && _t[0];
    }
    ai === "application/xhtml+xml" && vr === Se && (_ = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + _ + "</body></html>");
    const gt = k ? k.createHTML(_) : _;
    if (vr === Se)
      try {
        P = new f().parseFromString(gt, ai);
      } catch {
      }
    if (!P || !P.documentElement) {
      P = A.createDocument(vr, "template", null);
      try {
        P.documentElement.innerHTML = Ka ? w : gt;
      } catch {
      }
    }
    const $t = P.body || P.documentElement;
    return _ && V && $t.insertBefore(r.createTextNode(V), $t.childNodes[0] || null), vr === Se ? I.call(P, Ke ? "html" : "body")[0] : Ke ? P.documentElement : $t;
  }, Dl = function(_) {
    return S.call(
      _.ownerDocument || _,
      _,
      // eslint-disable-next-line no-bitwise
      c.SHOW_ELEMENT | c.SHOW_COMMENT | c.SHOW_TEXT | c.SHOW_PROCESSING_INSTRUCTION | c.SHOW_CDATA_SECTION,
      null
    );
  }, ts = function(_) {
    return _ instanceof u && (typeof _.nodeName != "string" || typeof _.textContent != "string" || typeof _.removeChild != "function" || !(_.attributes instanceof h) || typeof _.removeAttribute != "function" || typeof _.setAttribute != "function" || typeof _.namespaceURI != "string" || typeof _.insertBefore != "function" || typeof _.hasChildNodes != "function");
  }, Ol = function(_) {
    return typeof o == "function" && _ instanceof o;
  };
  function Te(tt, _, P) {
    cn(tt, (V) => {
      V.call(t, _, P, Sr);
    });
  }
  const Rl = function(_) {
    let P = null;
    if (Te($.beforeSanitizeElements, _, null), ts(_))
      return pe(_), !0;
    const V = kt(_.nodeName);
    if (Te($.uponSanitizeElement, _, {
      tagName: V,
      allowedTags: K
    }), en && _.hasChildNodes() && !Ol(_.firstElementChild) && Nt(/<[/\w!]/g, _.innerHTML) && Nt(/<[/\w!]/g, _.textContent) || _.nodeType === hi.progressingInstruction || en && _.nodeType === hi.comment && Nt(/<[/\w]/g, _.data))
      return pe(_), !0;
    if (!(Pt.tagCheck instanceof Function && Pt.tagCheck(V)) && (!K[V] || bt[V])) {
      if (!bt[V] && Pl(V) && (at.tagNameCheck instanceof RegExp && Nt(at.tagNameCheck, V) || at.tagNameCheck instanceof Function && at.tagNameCheck(V)))
        return !1;
      if (Xa && !de[V]) {
        const gt = C(_) || _.parentNode, $t = b(_) || _.childNodes;
        if ($t && gt) {
          const _t = $t.length;
          for (let Yt = _t - 1; Yt >= 0; --Yt) {
            const Be = m($t[Yt], !0);
            Be.__removalCount = (_.__removalCount || 0) + 1, gt.insertBefore(Be, x(_));
          }
        }
      }
      return pe(_), !0;
    }
    return _ instanceof l && !Vm(_) || (V === "noscript" || V === "noembed" || V === "noframes") && Nt(/<\/no(script|embed|frames)/i, _.innerHTML) ? (pe(_), !0) : (ne && _.nodeType === hi.text && (P = _.textContent, cn([N, R, B], (gt) => {
      P = oi(P, gt, " ");
    }), _.textContent !== P && (si(t.removed, {
      element: _.cloneNode()
    }), _.textContent = P)), Te($.afterSanitizeElements, _, null), !1);
  }, Il = function(_, P, V) {
    if (Sl && (P === "id" || P === "name") && (V in r || V in Xm))
      return !1;
    if (!(yt && !Ct[P] && Nt(L, P))) {
      if (!(re && Nt(T, P))) {
        if (!(Pt.attributeCheck instanceof Function && Pt.attributeCheck(P, _))) {
          if (!Z[P] || Ct[P]) {
            if (
              // First condition does a very basic check if a) it's basically a valid custom element tagname AND
              // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
              // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
              !(Pl(_) && (at.tagNameCheck instanceof RegExp && Nt(at.tagNameCheck, _) || at.tagNameCheck instanceof Function && at.tagNameCheck(_)) && (at.attributeNameCheck instanceof RegExp && Nt(at.attributeNameCheck, P) || at.attributeNameCheck instanceof Function && at.attributeNameCheck(P, _)) || // Alternative, second condition checks if it's an `is`-attribute, AND
              // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
              P === "is" && at.allowCustomizedBuiltInElements && (at.tagNameCheck instanceof RegExp && Nt(at.tagNameCheck, V) || at.tagNameCheck instanceof Function && at.tagNameCheck(V)))
            ) return !1;
          } else if (!Za[P]) {
            if (!Nt(X, oi(V, M, ""))) {
              if (!((P === "src" || P === "xlink:href" || P === "href") && _ !== "script" && g0(V, "data:") === 0 && Bl[_])) {
                if (!(ie && !Nt(E, oi(V, M, "")))) {
                  if (V)
                    return !1;
                }
              }
            }
          }
        }
      }
    }
    return !0;
  }, Pl = function(_) {
    return _ !== "annotation-xml" && is(_, q);
  }, Nl = function(_) {
    Te($.beforeSanitizeAttributes, _, null);
    const {
      attributes: P
    } = _;
    if (!P || ts(_))
      return;
    const V = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: Z,
      forceKeepAttr: void 0
    };
    let gt = P.length;
    for (; gt--; ) {
      const $t = P[gt], {
        name: _t,
        namespaceURI: Yt,
        value: Be
      } = $t, Tr = kt(_t), es = Be;
      let At = _t === "value" ? es : m0(es);
      if (V.attrName = Tr, V.attrValue = At, V.keepAttr = !0, V.forceKeepAttr = void 0, Te($.uponSanitizeAttribute, _, V), At = V.attrValue, Tl && (Tr === "id" || Tr === "name") && (Qe(_t, _), At = Hm + At), en && Nt(/((--!?|])>)|<\/(style|title|textarea)/i, At)) {
        Qe(_t, _);
        continue;
      }
      if (Tr === "attributename" && is(At, "href")) {
        Qe(_t, _);
        continue;
      }
      if (V.forceKeepAttr)
        continue;
      if (!V.keepAttr) {
        Qe(_t, _);
        continue;
      }
      if (!Pe && Nt(/\/>/i, At)) {
        Qe(_t, _);
        continue;
      }
      ne && cn([N, R, B], (Wl) => {
        At = oi(At, Wl, " ");
      });
      const zl = kt(_.nodeName);
      if (!Il(zl, Tr, At)) {
        Qe(_t, _);
        continue;
      }
      if (k && typeof d == "object" && typeof d.getAttributeType == "function" && !Yt)
        switch (d.getAttributeType(zl, Tr)) {
          case "TrustedHTML": {
            At = k.createHTML(At);
            break;
          }
          case "TrustedScriptURL": {
            At = k.createScriptURL(At);
            break;
          }
        }
      if (At !== es)
        try {
          Yt ? _.setAttributeNS(Yt, _t, At) : _.setAttribute(_t, At), ts(_) ? pe(_) : Yl(t.removed);
        } catch {
          Qe(_t, _);
        }
    }
    Te($.afterSanitizeAttributes, _, null);
  }, Zm = function tt(_) {
    let P = null;
    const V = Dl(_);
    for (Te($.beforeSanitizeShadowDOM, _, null); P = V.nextNode(); )
      Te($.uponSanitizeShadowNode, P, null), Rl(P), Nl(P), P.content instanceof a && tt(P.content);
    Te($.afterSanitizeShadowDOM, _, null);
  };
  return t.sanitize = function(tt) {
    let _ = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, P = null, V = null, gt = null, $t = null;
    if (Ka = !tt, Ka && (tt = "<!-->"), typeof tt != "string" && !Ol(tt))
      if (typeof tt.toString == "function") {
        if (tt = tt.toString(), typeof tt != "string")
          throw li("dirty is not a string, aborting");
      } else
        throw li("toString is not a function");
    if (!t.isSupported)
      return tt;
    if (Ua || Ja(_), t.removed = [], typeof tt == "string" && (ni = !1), ni) {
      if (tt.nodeName) {
        const Be = kt(tt.nodeName);
        if (!K[Be] || bt[Be])
          throw li("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (tt instanceof o)
      P = Fl("<!---->"), V = P.ownerDocument.importNode(tt, !0), V.nodeType === hi.element && V.nodeName === "BODY" || V.nodeName === "HTML" ? P = V : P.appendChild(V);
    else {
      if (!wr && !ne && !Ke && // eslint-disable-next-line unicorn/prefer-includes
      tt.indexOf("<") === -1)
        return k && nn ? k.createHTML(tt) : tt;
      if (P = Fl(tt), !P)
        return wr ? null : nn ? w : "";
    }
    P && Ga && pe(P.firstChild);
    const _t = Dl(ni ? tt : P);
    for (; gt = _t.nextNode(); )
      Rl(gt), Nl(gt), gt.content instanceof a && Zm(gt.content);
    if (ni)
      return tt;
    if (wr) {
      if (rn)
        for ($t = D.call(P.ownerDocument); P.firstChild; )
          $t.appendChild(P.firstChild);
      else
        $t = P;
      return (Z.shadowroot || Z.shadowrootmode) && ($t = O.call(i, $t, !0)), $t;
    }
    let Yt = Ke ? P.outerHTML : P.innerHTML;
    return Ke && K["!doctype"] && P.ownerDocument && P.ownerDocument.doctype && P.ownerDocument.doctype.name && Nt(Lh, P.ownerDocument.doctype.name) && (Yt = "<!DOCTYPE " + P.ownerDocument.doctype.name + `>
` + Yt), ne && cn([N, R, B], (Be) => {
      Yt = oi(Yt, Be, " ");
    }), k && nn ? k.createHTML(Yt) : Yt;
  }, t.setConfig = function() {
    let tt = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Ja(tt), Ua = !0;
  }, t.clearConfig = function() {
    Sr = null, Ua = !1;
  }, t.isValidAttribute = function(tt, _, P) {
    Sr || Ja({});
    const V = kt(tt), gt = kt(_);
    return Il(V, gt, P);
  }, t.addHook = function(tt, _) {
    typeof _ == "function" && si($[tt], _);
  }, t.removeHook = function(tt, _) {
    if (_ !== void 0) {
      const P = d0($[tt], _);
      return P === -1 ? void 0 : p0($[tt], P, 1)[0];
    }
    return Yl($[tt]);
  }, t.removeHooks = function(tt) {
    $[tt] = [];
  }, t.removeAllHooks = function() {
    $ = Kl();
  }, t;
}
var Hr = Mh(), $h = /^-{3}\s*[\n\r](.*?)[\n\r]-{3}\s*[\n\r]+/s, Ai = /%{2}{\s*(?:(\w+)\s*:|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, $0 = /\s*%%.*\n/gm, Or, Eh = (Or = class extends Error {
  constructor(t) {
    super(t), this.name = "UnknownDiagramError";
  }
}, p(Or, "UnknownDiagramError"), Or), hr = {}, vo = /* @__PURE__ */ p(function(e, t) {
  e = e.replace($h, "").replace(Ai, "").replace($0, `
`);
  for (const [r, { detector: i }] of Object.entries(hr))
    if (i(e, t))
      return r;
  throw new Eh(
    `No diagram type detected matching given configuration for text: ${e}`
  );
}, "detectType"), Ts = /* @__PURE__ */ p((...e) => {
  for (const { id: t, detector: r, loader: i } of e)
    Fh(t, r, i);
}, "registerLazyLoadedDiagrams"), Fh = /* @__PURE__ */ p((e, t, r) => {
  hr[e] && F.warn(`Detector with key ${e} already exists. Overwriting.`), hr[e] = { detector: t, loader: r }, F.debug(`Detector with key ${e} added${r ? " with loader" : ""}`);
}, "addDetector"), E0 = /* @__PURE__ */ p((e) => hr[e].loader, "getDiagramLoader"), Bs = /* @__PURE__ */ p((e, t, { depth: r = 2, clobber: i = !1 } = {}) => {
  const n = { depth: r, clobber: i };
  return Array.isArray(t) && !Array.isArray(e) ? (t.forEach((a) => Bs(e, a, n)), e) : Array.isArray(t) && Array.isArray(e) ? (t.forEach((a) => {
    e.includes(a) || e.push(a);
  }), e) : e === void 0 || r <= 0 ? e != null && typeof e == "object" && typeof t == "object" ? Object.assign(e, t) : t : (t !== void 0 && typeof e == "object" && typeof t == "object" && Object.keys(t).forEach((a) => {
    typeof t[a] == "object" && (e[a] === void 0 || typeof e[a] == "object") ? (e[a] === void 0 && (e[a] = Array.isArray(t[a]) ? [] : {}), e[a] = Bs(e[a], t[a], { depth: r - 1, clobber: i })) : (i || typeof e[a] != "object" && typeof t[a] != "object") && (e[a] = t[a]);
  }), e);
}, "assignWithDepth"), St = Bs, Ca = "#ffffff", _a = "#f2f2f2", zt = /* @__PURE__ */ p((e, t) => t ? v(e, { s: -40, l: 10 }) : v(e, { s: -40, l: -10 }), "mkBorder"), Rr, F0 = (Rr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#fff4dd", this.noteBkgColor = "#fff5ad", this.noteTextColor = "#333", this.THEME_COLOR_LIMIT = 12, this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px";
  }
  updateColors() {
    if (this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333"), this.secondaryColor = this.secondaryColor || v(this.primaryColor, { h: -120 }), this.tertiaryColor = this.tertiaryColor || v(this.primaryColor, { h: 180, l: 5 }), this.primaryBorderColor = this.primaryBorderColor || zt(this.primaryColor, this.darkMode), this.secondaryBorderColor = this.secondaryBorderColor || zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = this.tertiaryBorderColor || zt(this.tertiaryColor, this.darkMode), this.noteBorderColor = this.noteBorderColor || zt(this.noteBkgColor, this.darkMode), this.noteBkgColor = this.noteBkgColor || "#fff5ad", this.noteTextColor = this.noteTextColor || "#333", this.secondaryTextColor = this.secondaryTextColor || z(this.secondaryColor), this.tertiaryTextColor = this.tertiaryTextColor || z(this.tertiaryColor), this.lineColor = this.lineColor || z(this.background), this.arrowheadColor = this.arrowheadColor || z(this.background), this.textColor = this.textColor || this.primaryTextColor, this.border2 = this.border2 || this.tertiaryBorderColor, this.nodeBkg = this.nodeBkg || this.primaryColor, this.mainBkg = this.mainBkg || this.primaryColor, this.nodeBorder = this.nodeBorder || this.primaryBorderColor, this.clusterBkg = this.clusterBkg || this.tertiaryColor, this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor, this.defaultLinkColor = this.defaultLinkColor || this.lineColor, this.titleColor = this.titleColor || this.tertiaryTextColor, this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? et(this.secondaryColor, 30) : this.secondaryColor), this.nodeTextColor = this.nodeTextColor || this.primaryTextColor, this.actorBorder = this.actorBorder || this.primaryBorderColor, this.actorBkg = this.actorBkg || this.mainBkg, this.actorTextColor = this.actorTextColor || this.primaryTextColor, this.actorLineColor = this.actorLineColor || this.actorBorder, this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg, this.signalColor = this.signalColor || this.textColor, this.signalTextColor = this.signalTextColor || this.textColor, this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder, this.labelTextColor = this.labelTextColor || this.actorTextColor, this.loopTextColor = this.loopTextColor || this.actorTextColor, this.activationBorderColor = this.activationBorderColor || et(this.secondaryColor, 10), this.activationBkgColor = this.activationBkgColor || this.secondaryColor, this.sequenceNumberColor = this.sequenceNumberColor || z(this.lineColor), this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor, this.altSectionBkgColor = this.altSectionBkgColor || "white", this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor, this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor, this.excludeBkgColor = this.excludeBkgColor || "#eeeeee", this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor, this.taskBkgColor = this.taskBkgColor || this.primaryColor, this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor, this.activeTaskBkgColor = this.activeTaskBkgColor || H(this.primaryColor, 23), this.gridColor = this.gridColor || "lightgrey", this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey", this.doneTaskBorderColor = this.doneTaskBorderColor || "grey", this.critBorderColor = this.critBorderColor || "#ff8888", this.critBkgColor = this.critBkgColor || "red", this.todayLineColor = this.todayLineColor || "red", this.vertLineColor = this.vertLineColor || "navy", this.taskTextColor = this.taskTextColor || this.textColor, this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor, this.taskTextLightColor = this.taskTextLightColor || this.textColor, this.taskTextColor = this.taskTextColor || this.primaryTextColor, this.taskTextDarkColor = this.taskTextDarkColor || this.textColor, this.taskTextClickableColor = this.taskTextClickableColor || "#003163", this.personBorder = this.personBorder || this.primaryBorderColor, this.personBkg = this.personBkg || this.mainBkg, this.darkMode ? (this.rowOdd = this.rowOdd || et(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || et(this.mainBkg, 10)) : (this.rowOdd = this.rowOdd || H(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || H(this.mainBkg, 5)), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || this.tertiaryColor, this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.specialStateColor = this.lineColor, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || v(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || v(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || v(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || v(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || v(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || v(this.primaryColor, { h: 210, l: 150 }), this.cScale9 = this.cScale9 || v(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || v(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || v(this.primaryColor, { h: 330 }), this.darkMode)
      for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
        this["cScale" + r] = et(this["cScale" + r], 75);
    else
      for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
        this["cScale" + r] = et(this["cScale" + r], 25);
    for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
      this["cScaleInv" + r] = this["cScaleInv" + r] || z(this["cScale" + r]);
    for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
      this.darkMode ? this["cScalePeer" + r] = this["cScalePeer" + r] || H(this["cScale" + r], 10) : this["cScalePeer" + r] = this["cScalePeer" + r] || et(this["cScale" + r], 10);
    this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
    for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
      this["cScaleLabel" + r] = this["cScaleLabel" + r] || this.scaleLabelColor;
    const t = this.darkMode ? -4 : -1;
    for (let r = 0; r < 5; r++)
      this["surface" + r] = this["surface" + r] || v(this.mainBkg, { h: 180, s: -15, l: t * (5 + r * 3) }), this["surfacePeer" + r] = this["surfacePeer" + r] || v(this.mainBkg, { h: 180, s: -15, l: t * (8 + r * 3) });
    this.classText = this.classText || this.textColor, this.fillType0 = this.fillType0 || this.primaryColor, this.fillType1 = this.fillType1 || this.secondaryColor, this.fillType2 = this.fillType2 || v(this.primaryColor, { h: 64 }), this.fillType3 = this.fillType3 || v(this.secondaryColor, { h: 64 }), this.fillType4 = this.fillType4 || v(this.primaryColor, { h: -64 }), this.fillType5 = this.fillType5 || v(this.secondaryColor, { h: -64 }), this.fillType6 = this.fillType6 || v(this.primaryColor, { h: 128 }), this.fillType7 = this.fillType7 || v(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || v(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || v(this.secondaryColor, { l: -10 }), this.pie6 = this.pie6 || v(this.tertiaryColor, { l: -10 }), this.pie7 = this.pie7 || v(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || v(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || v(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || v(this.primaryColor, { h: 60, l: -20 }), this.pie11 = this.pie11 || v(this.primaryColor, { h: -60, l: -20 }), this.pie12 = this.pie12 || v(this.primaryColor, { h: 120, l: -10 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.archEdgeColor = this.archEdgeColor || "#777", this.archEdgeArrowColor = this.archEdgeArrowColor || "#777", this.archEdgeWidth = this.archEdgeWidth || "3", this.archGroupBorderColor = this.archGroupBorderColor || "#000", this.archGroupBorderWidth = this.archGroupBorderWidth || "2px", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || v(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || v(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || v(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || v(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || v(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || v(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Yi(this.quadrant1Fill) ? H(this.quadrant1Fill) : et(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? et(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || v(this.primaryColor, { h: -30 }), this.git4 = this.git4 || v(this.primaryColor, { h: -60 }), this.git5 = this.git5 || v(this.primaryColor, { h: -90 }), this.git6 = this.git6 || v(this.primaryColor, { h: 60 }), this.git7 = this.git7 || v(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = H(this.git0, 25), this.git1 = H(this.git1, 25), this.git2 = H(this.git2, 25), this.git3 = H(this.git3, 25), this.git4 = H(this.git4, 25), this.git5 = H(this.git5, 25), this.git6 = H(this.git6, 25), this.git7 = H(this.git7, 25)) : (this.git0 = et(this.git0, 25), this.git1 = et(this.git1, 25), this.git2 = et(this.git2, 25), this.git3 = et(this.git3, 25), this.git4 = et(this.git4, 25), this.git5 = et(this.git5, 25), this.git6 = et(this.git6, 25), this.git7 = et(this.git7, 25)), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor, this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor, this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor, this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ca, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || _a;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(Rr, "Theme"), Rr), D0 = /* @__PURE__ */ p((e) => {
  const t = new F0();
  return t.calculate(e), t;
}, "getThemeVariables"), Ir, O0 = (Ir = class {
  constructor() {
    this.background = "#333", this.primaryColor = "#1f2020", this.secondaryColor = H(this.primaryColor, 16), this.tertiaryColor = v(this.primaryColor, { h: -160 }), this.primaryBorderColor = z(this.background), this.secondaryBorderColor = zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = zt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.tertiaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.mainBkg = "#1f2020", this.secondBkg = "calculated", this.mainContrastColor = "lightgrey", this.darkTextColor = H(z("#323D47"), 10), this.lineColor = "calculated", this.border1 = "#ccc", this.border2 = Bi(255, 255, 255, 0.25), this.arrowheadColor = "calculated", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "#181818", this.textColor = "#ccc", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#F9FFFE", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "calculated", this.activationBkgColor = "calculated", this.sequenceNumberColor = "black", this.sectionBkgColor = et("#EAE8D9", 30), this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "#EAE8D9", this.excludeBkgColor = et(this.sectionBkgColor, 10), this.taskBorderColor = Bi(255, 255, 255, 70), this.taskBkgColor = "calculated", this.taskTextColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = Bi(255, 255, 255, 50), this.activeTaskBkgColor = "#81B1DB", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "grey", this.critBorderColor = "#E83737", this.critBkgColor = "#E83737", this.taskTextDarkColor = "calculated", this.todayLineColor = "#DB5757", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || H(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || et(this.mainBkg, 10), this.labelColor = "calculated", this.errorBkgColor = "#a44141", this.errorTextColor = "#ddd";
  }
  updateColors() {
    this.secondBkg = H(this.mainBkg, 16), this.lineColor = this.mainContrastColor, this.arrowheadColor = this.mainContrastColor, this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.edgeLabelBackground = H(this.labelBackground, 25), this.actorBorder = this.border1, this.actorBkg = this.mainBkg, this.actorTextColor = this.mainContrastColor, this.actorLineColor = this.actorBorder, this.signalColor = this.mainContrastColor, this.signalTextColor = this.mainContrastColor, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.mainContrastColor, this.loopTextColor = this.mainContrastColor, this.noteBorderColor = this.secondaryBorderColor, this.noteBkgColor = this.secondBkg, this.noteTextColor = this.secondaryTextColor, this.activationBorderColor = this.border1, this.activationBkgColor = this.secondBkg, this.altSectionBkgColor = this.background, this.taskBkgColor = H(this.mainBkg, 23), this.taskTextColor = this.darkTextColor, this.taskTextLightColor = this.mainContrastColor, this.taskTextOutsideColor = this.taskTextLightColor, this.gridColor = this.mainContrastColor, this.doneTaskBkgColor = this.mainContrastColor, this.taskTextDarkColor = this.darkTextColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#555", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#f4f4f4", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = v(this.primaryColor, { h: 64 }), this.fillType3 = v(this.secondaryColor, { h: 64 }), this.fillType4 = v(this.primaryColor, { h: -64 }), this.fillType5 = v(this.secondaryColor, { h: -64 }), this.fillType6 = v(this.primaryColor, { h: 128 }), this.fillType7 = v(this.secondaryColor, { h: 128 }), this.cScale1 = this.cScale1 || "#0b0000", this.cScale2 = this.cScale2 || "#4d1037", this.cScale3 = this.cScale3 || "#3f5258", this.cScale4 = this.cScale4 || "#4f2f1b", this.cScale5 = this.cScale5 || "#6e0a0a", this.cScale6 = this.cScale6 || "#3b0048", this.cScale7 = this.cScale7 || "#995a01", this.cScale8 = this.cScale8 || "#154706", this.cScale9 = this.cScale9 || "#161722", this.cScale10 = this.cScale10 || "#00296f", this.cScale11 = this.cScale11 || "#01629c", this.cScale12 = this.cScale12 || "#010029", this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || v(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || v(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || v(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || v(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || v(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || v(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || v(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || v(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || v(this.primaryColor, { h: 330 });
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleInv" + t] = this["cScaleInv" + t] || z(this["cScale" + t]);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScalePeer" + t] = this["cScalePeer" + t] || H(this["cScale" + t], 10);
    for (let t = 0; t < 5; t++)
      this["surface" + t] = this["surface" + t] || v(this.mainBkg, { h: 30, s: -30, l: -(-10 + t * 4) }), this["surfacePeer" + t] = this["surfacePeer" + t] || v(this.mainBkg, { h: 30, s: -30, l: -(-7 + t * 4) });
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleLabel" + t] = this["cScaleLabel" + t] || this.scaleLabelColor;
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["pie" + t] = this["cScale" + t];
    this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || v(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || v(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || v(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || v(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || v(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || v(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Yi(this.quadrant1Fill) ? H(this.quadrant1Fill) : et(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#3498db,#2ecc71,#e74c3c,#f1c40f,#bdc3c7,#ffffff,#34495e,#9b59b6,#1abc9c,#e67e22"
    }, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.background
    }, this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.classText = this.primaryTextColor, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? et(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = H(this.secondaryColor, 20), this.git1 = H(this.pie2 || this.secondaryColor, 20), this.git2 = H(this.pie3 || this.tertiaryColor, 20), this.git3 = H(this.pie4 || v(this.primaryColor, { h: -30 }), 20), this.git4 = H(this.pie5 || v(this.primaryColor, { h: -60 }), 20), this.git5 = H(this.pie6 || v(this.primaryColor, { h: -90 }), 10), this.git6 = H(this.pie7 || v(this.primaryColor, { h: 60 }), 10), this.git7 = H(this.pie8 || v(this.primaryColor, { h: 120 }), 20), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || z(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || z(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || H(this.background, 12), this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || H(this.background, 2), this.nodeBorder = this.nodeBorder || "#999";
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(Ir, "Theme"), Ir), R0 = /* @__PURE__ */ p((e) => {
  const t = new O0();
  return t.calculate(e), t;
}, "getThemeVariables"), Pr, I0 = (Pr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#ECECFF", this.secondaryColor = v(this.primaryColor, { h: 120 }), this.secondaryColor = "#ffffde", this.tertiaryColor = v(this.primaryColor, { h: -160 }), this.primaryBorderColor = zt(this.primaryColor, this.darkMode), this.secondaryBorderColor = zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = zt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.tertiaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.background = "white", this.mainBkg = "#ECECFF", this.secondBkg = "#ffffde", this.lineColor = "#333333", this.border1 = "#9370DB", this.border2 = "#aaaa33", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "rgba(232,232,232, 0.8)", this.textColor = "#333", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = this.taskTextDarkColor, this.taskTextClickableColor = "calculated", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBorderColor = "calculated", this.critBkgColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.sectionBkgColor = Bi(102, 102, 255, 0.49), this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#fff400", this.taskBorderColor = "#534fbc", this.taskBkgColor = "#8a90dd", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "#534fbc", this.activeTaskBkgColor = "#bfc7ff", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "navy", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = "calculated", this.rowEven = "calculated", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222", this.updateColors();
  }
  updateColors() {
    this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || v(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || v(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || v(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || v(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || v(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || v(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || v(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || v(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || v(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || et(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || et(this.tertiaryColor, 40);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScale" + t] = et(this["cScale" + t], 10), this["cScalePeer" + t] = this["cScalePeer" + t] || et(this["cScale" + t], 25);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleInv" + t] = this["cScaleInv" + t] || v(this["cScale" + t], { h: 180 });
    for (let t = 0; t < 5; t++)
      this["surface" + t] = this["surface" + t] || v(this.mainBkg, { h: 30, l: -(5 + t * 5) }), this["surfacePeer" + t] = this["surfacePeer" + t] || v(this.mainBkg, { h: 30, l: -(7 + t * 5) });
    if (this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor, this.labelTextColor !== "calculated") {
      this.cScaleLabel0 = this.cScaleLabel0 || z(this.labelTextColor), this.cScaleLabel3 = this.cScaleLabel3 || z(this.labelTextColor);
      for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
        this["cScaleLabel" + t] = this["cScaleLabel" + t] || this.labelTextColor;
    }
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.textColor, this.edgeLabelBackground = this.labelBackground, this.actorBorder = H(this.border1, 23), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.signalColor = this.textColor, this.signalTextColor = this.textColor, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || H(this.primaryColor, 75) || "#ffffff", this.rowEven = this.rowEven || H(this.primaryColor, 1), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = v(this.primaryColor, { h: 64 }), this.fillType3 = v(this.secondaryColor, { h: 64 }), this.fillType4 = v(this.primaryColor, { h: -64 }), this.fillType5 = v(this.secondaryColor, { h: -64 }), this.fillType6 = v(this.primaryColor, { h: 128 }), this.fillType7 = v(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || v(this.tertiaryColor, { l: -40 }), this.pie4 = this.pie4 || v(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || v(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || v(this.tertiaryColor, { l: -20 }), this.pie7 = this.pie7 || v(this.primaryColor, { h: 60, l: -20 }), this.pie8 = this.pie8 || v(this.primaryColor, { h: -60, l: -40 }), this.pie9 = this.pie9 || v(this.primaryColor, { h: 120, l: -40 }), this.pie10 = this.pie10 || v(this.primaryColor, { h: 60, l: -40 }), this.pie11 = this.pie11 || v(this.primaryColor, { h: -90, l: -40 }), this.pie12 = this.pie12 || v(this.primaryColor, { h: 120, l: -30 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || v(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || v(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || v(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || v(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || v(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || v(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Yi(this.quadrant1Fill) ? H(this.quadrant1Fill) : et(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#ECECFF,#8493A6,#FFC3A0,#DCDDE1,#B8E994,#D1A36F,#C3CDE6,#FFB6C1,#496078,#F8F3E3"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.labelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || v(this.primaryColor, { h: -30 }), this.git4 = this.git4 || v(this.primaryColor, { h: -60 }), this.git5 = this.git5 || v(this.primaryColor, { h: -90 }), this.git6 = this.git6 || v(this.primaryColor, { h: 60 }), this.git7 = this.git7 || v(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = H(this.git0, 25), this.git1 = H(this.git1, 25), this.git2 = H(this.git2, 25), this.git3 = H(this.git3, 25), this.git4 = H(this.git4, 25), this.git5 = H(this.git5, 25), this.git6 = H(this.git6, 25), this.git7 = H(this.git7, 25)) : (this.git0 = et(this.git0, 25), this.git1 = et(this.git1, 25), this.git2 = et(this.git2, 25), this.git3 = et(this.git3, 25), this.git4 = et(this.git4, 25), this.git5 = et(this.git5, 25), this.git6 = et(this.git6, 25), this.git7 = et(this.git7, 25)), this.gitInv0 = this.gitInv0 || et(z(this.git0), 25), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || z(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || z(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ca, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || _a;
  }
  calculate(t) {
    if (Object.keys(this).forEach((i) => {
      this[i] === "calculated" && (this[i] = void 0);
    }), typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(Pr, "Theme"), Pr), P0 = /* @__PURE__ */ p((e) => {
  const t = new I0();
  return t.calculate(e), t;
}, "getThemeVariables"), Nr, N0 = (Nr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#cde498", this.secondaryColor = "#cdffb2", this.background = "white", this.mainBkg = "#cde498", this.secondBkg = "#cdffb2", this.lineColor = "green", this.border1 = "#13540c", this.border2 = "#6eaa49", this.arrowheadColor = "green", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.tertiaryColor = H("#cde498", 10), this.primaryBorderColor = zt(this.primaryColor, this.darkMode), this.secondaryBorderColor = zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = zt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.primaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#333", this.edgeLabelBackground = "#e8e8e8", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "#333", this.signalTextColor = "#333", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "#326932", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "#6eaa49", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#6eaa49", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "#487e3a", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    this.actorBorder = et(this.mainBkg, 20), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || v(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || v(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || v(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || v(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || v(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || v(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || v(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || v(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || v(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || et(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || et(this.tertiaryColor, 40);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScale" + t] = et(this["cScale" + t], 10), this["cScalePeer" + t] = this["cScalePeer" + t] || et(this["cScale" + t], 25);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleInv" + t] = this["cScaleInv" + t] || v(this["cScale" + t], { h: 180 });
    this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleLabel" + t] = this["cScaleLabel" + t] || this.scaleLabelColor;
    for (let t = 0; t < 5; t++)
      this["surface" + t] = this["surface" + t] || v(this.mainBkg, { h: 30, s: -30, l: -(5 + t * 5) }), this["surfacePeer" + t] = this["surfacePeer" + t] || v(this.mainBkg, { h: 30, s: -30, l: -(8 + t * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.taskBorderColor = this.border1, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || H(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || H(this.mainBkg, 20), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = v(this.primaryColor, { h: 64 }), this.fillType3 = v(this.secondaryColor, { h: 64 }), this.fillType4 = v(this.primaryColor, { h: -64 }), this.fillType5 = v(this.secondaryColor, { h: -64 }), this.fillType6 = v(this.primaryColor, { h: 128 }), this.fillType7 = v(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || v(this.primaryColor, { l: -30 }), this.pie5 = this.pie5 || v(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || v(this.tertiaryColor, { h: 40, l: -40 }), this.pie7 = this.pie7 || v(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || v(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || v(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || v(this.primaryColor, { h: 60, l: -50 }), this.pie11 = this.pie11 || v(this.primaryColor, { h: -60, l: -50 }), this.pie12 = this.pie12 || v(this.primaryColor, { h: 120, l: -50 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || v(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || v(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || v(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || v(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || v(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || v(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Yi(this.quadrant1Fill) ? H(this.quadrant1Fill) : et(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.mainBkg
    }, this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#CDE498,#FF6B6B,#A0D2DB,#D7BDE2,#F0F0F0,#FFC3A0,#7FD8BE,#FF9A8B,#FAF3E0,#FFF176"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || v(this.primaryColor, { h: -30 }), this.git4 = this.git4 || v(this.primaryColor, { h: -60 }), this.git5 = this.git5 || v(this.primaryColor, { h: -90 }), this.git6 = this.git6 || v(this.primaryColor, { h: 60 }), this.git7 = this.git7 || v(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = H(this.git0, 25), this.git1 = H(this.git1, 25), this.git2 = H(this.git2, 25), this.git3 = H(this.git3, 25), this.git4 = H(this.git4, 25), this.git5 = H(this.git5, 25), this.git6 = H(this.git6, 25), this.git7 = H(this.git7, 25)) : (this.git0 = et(this.git0, 25), this.git1 = et(this.git1, 25), this.git2 = et(this.git2, 25), this.git3 = et(this.git3, 25), this.git4 = et(this.git4, 25), this.git5 = et(this.git5, 25), this.git6 = et(this.git6, 25), this.git7 = et(this.git7, 25)), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || z(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || z(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ca, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || _a;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(Nr, "Theme"), Nr), z0 = /* @__PURE__ */ p((e) => {
  const t = new N0();
  return t.calculate(e), t;
}, "getThemeVariables"), zr, W0 = (zr = class {
  constructor() {
    this.primaryColor = "#eee", this.contrast = "#707070", this.secondaryColor = H(this.contrast, 55), this.background = "#ffffff", this.tertiaryColor = v(this.primaryColor, { h: -160 }), this.primaryBorderColor = zt(this.primaryColor, this.darkMode), this.secondaryBorderColor = zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = zt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.tertiaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.mainBkg = "#eee", this.secondBkg = "calculated", this.lineColor = "#666", this.border1 = "#999", this.border2 = "calculated", this.note = "#ffa", this.text = "#333", this.critical = "#d42", this.done = "#bbb", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "white", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = this.actorBorder, this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "calculated", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBkgColor = "calculated", this.critBorderColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || H(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || "#f4f4f4", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    this.secondBkg = H(this.contrast, 55), this.border2 = this.contrast, this.actorBorder = H(this.border1, 23), this.actorBkg = this.mainBkg, this.actorTextColor = this.text, this.actorLineColor = this.actorBorder, this.signalColor = this.text, this.signalTextColor = this.text, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.text, this.loopTextColor = this.text, this.noteBorderColor = "#999", this.noteBkgColor = "#666", this.noteTextColor = "#fff", this.cScale0 = this.cScale0 || "#555", this.cScale1 = this.cScale1 || "#F4F4F4", this.cScale2 = this.cScale2 || "#555", this.cScale3 = this.cScale3 || "#BBB", this.cScale4 = this.cScale4 || "#777", this.cScale5 = this.cScale5 || "#999", this.cScale6 = this.cScale6 || "#DDD", this.cScale7 = this.cScale7 || "#FFF", this.cScale8 = this.cScale8 || "#DDD", this.cScale9 = this.cScale9 || "#BBB", this.cScale10 = this.cScale10 || "#999", this.cScale11 = this.cScale11 || "#777";
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleInv" + t] = this["cScaleInv" + t] || z(this["cScale" + t]);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this.darkMode ? this["cScalePeer" + t] = this["cScalePeer" + t] || H(this["cScale" + t], 10) : this["cScalePeer" + t] = this["cScalePeer" + t] || et(this["cScale" + t], 10);
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.cScaleLabel0 = this.cScaleLabel0 || this.cScale1, this.cScaleLabel2 = this.cScaleLabel2 || this.cScale1;
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleLabel" + t] = this["cScaleLabel" + t] || this.scaleLabelColor;
    for (let t = 0; t < 5; t++)
      this["surface" + t] = this["surface" + t] || v(this.mainBkg, { l: -(5 + t * 5) }), this["surfacePeer" + t] = this["surfacePeer" + t] || v(this.mainBkg, { l: -(8 + t * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.text, this.sectionBkgColor = H(this.contrast, 30), this.sectionBkgColor2 = H(this.contrast, 30), this.taskBorderColor = et(this.contrast, 10), this.taskBkgColor = this.contrast, this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = this.text, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.gridColor = H(this.border1, 30), this.doneTaskBkgColor = this.done, this.doneTaskBorderColor = this.lineColor, this.critBkgColor = this.critical, this.critBorderColor = et(this.critBkgColor, 10), this.todayLineColor = this.critBkgColor, this.vertLineColor = this.critBkgColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || "#000", this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f4f4f4", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.stateBorder = this.stateBorder || "#000", this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#222", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = v(this.primaryColor, { h: 64 }), this.fillType3 = v(this.secondaryColor, { h: 64 }), this.fillType4 = v(this.primaryColor, { h: -64 }), this.fillType5 = v(this.secondaryColor, { h: -64 }), this.fillType6 = v(this.primaryColor, { h: 128 }), this.fillType7 = v(this.secondaryColor, { h: 128 });
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["pie" + t] = this["cScale" + t];
    this.pie12 = this.pie0, this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || v(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || v(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || v(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || v(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || v(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || v(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Yi(this.quadrant1Fill) ? H(this.quadrant1Fill) : et(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#EEE,#6BB8E4,#8ACB88,#C7ACD6,#E8DCC2,#FFB2A8,#FFF380,#7E8D91,#FFD8B1,#FAF3E0"
    }, this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = et(this.pie1, 25) || this.primaryColor, this.git1 = this.pie2 || this.secondaryColor, this.git2 = this.pie3 || this.tertiaryColor, this.git3 = this.pie4 || v(this.primaryColor, { h: -30 }), this.git4 = this.pie5 || v(this.primaryColor, { h: -60 }), this.git5 = this.pie6 || v(this.primaryColor, { h: -90 }), this.git6 = this.pie7 || v(this.primaryColor, { h: 60 }), this.git7 = this.pie8 || v(this.primaryColor, { h: 120 }), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.branchLabelColor = this.branchLabelColor || this.labelTextColor, this.gitBranchLabel0 = this.branchLabelColor, this.gitBranchLabel1 = "white", this.gitBranchLabel2 = this.branchLabelColor, this.gitBranchLabel3 = "white", this.gitBranchLabel4 = this.branchLabelColor, this.gitBranchLabel5 = this.branchLabelColor, this.gitBranchLabel6 = this.branchLabelColor, this.gitBranchLabel7 = this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ca, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || _a;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(zr, "Theme"), zr), q0 = /* @__PURE__ */ p((e) => {
  const t = new W0();
  return t.calculate(e), t;
}, "getThemeVariables"), Ee = {
  base: {
    getThemeVariables: D0
  },
  dark: {
    getThemeVariables: R0
  },
  default: {
    getThemeVariables: P0
  },
  forest: {
    getThemeVariables: z0
  },
  neutral: {
    getThemeVariables: q0
  }
}, ge = {
  flowchart: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    subGraphTitleMargin: {
      top: 0,
      bottom: 0
    },
    diagramPadding: 8,
    htmlLabels: !0,
    nodeSpacing: 50,
    rankSpacing: 50,
    curve: "basis",
    padding: 15,
    defaultRenderer: "dagre-wrapper",
    wrappingWidth: 200,
    inheritDir: !1
  },
  sequence: {
    useMaxWidth: !0,
    hideUnusedParticipants: !1,
    activationWidth: 10,
    diagramMarginX: 50,
    diagramMarginY: 10,
    actorMargin: 50,
    width: 150,
    height: 65,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    mirrorActors: !0,
    forceMenus: !1,
    bottomMarginAdj: 1,
    rightAngles: !1,
    showSequenceNumbers: !1,
    actorFontSize: 14,
    actorFontFamily: '"Open Sans", sans-serif',
    actorFontWeight: 400,
    noteFontSize: 14,
    noteFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    noteFontWeight: 400,
    noteAlign: "center",
    messageFontSize: 16,
    messageFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    messageFontWeight: 400,
    wrap: !1,
    wrapPadding: 10,
    labelBoxWidth: 50,
    labelBoxHeight: 20
  },
  gantt: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    barHeight: 20,
    barGap: 4,
    topPadding: 50,
    rightPadding: 75,
    leftPadding: 75,
    gridLineStartPadding: 35,
    fontSize: 11,
    sectionFontSize: 11,
    numberSectionStyles: 4,
    axisFormat: "%Y-%m-%d",
    topAxis: !1,
    displayMode: "",
    weekday: "sunday"
  },
  journey: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    maxLabelWidth: 360,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    titleColor: "",
    titleFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    titleFontSize: "4ex"
  },
  class: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    arrowMarkerAbsolute: !1,
    dividerMargin: 10,
    padding: 5,
    textHeight: 10,
    defaultRenderer: "dagre-wrapper",
    htmlLabels: !1,
    hideEmptyMembersBox: !1
  },
  state: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    dividerMargin: 10,
    sizeUnit: 5,
    padding: 8,
    textHeight: 10,
    titleShift: -15,
    noteMargin: 10,
    forkWidth: 70,
    forkHeight: 7,
    miniPadding: 2,
    fontSizeFactor: 5.02,
    fontSize: 24,
    labelHeight: 16,
    edgeLengthFactor: "20",
    compositTitleSize: 35,
    radius: 5,
    defaultRenderer: "dagre-wrapper"
  },
  er: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 20,
    layoutDirection: "TB",
    minEntityWidth: 100,
    minEntityHeight: 75,
    entityPadding: 15,
    nodeSpacing: 140,
    rankSpacing: 80,
    stroke: "gray",
    fill: "honeydew",
    fontSize: 12
  },
  pie: {
    useMaxWidth: !0,
    textPosition: 0.75
  },
  quadrantChart: {
    useMaxWidth: !0,
    chartWidth: 500,
    chartHeight: 500,
    titleFontSize: 20,
    titlePadding: 10,
    quadrantPadding: 5,
    xAxisLabelPadding: 5,
    yAxisLabelPadding: 5,
    xAxisLabelFontSize: 16,
    yAxisLabelFontSize: 16,
    quadrantLabelFontSize: 16,
    quadrantTextTopPadding: 5,
    pointTextPadding: 5,
    pointLabelFontSize: 12,
    pointRadius: 5,
    xAxisPosition: "top",
    yAxisPosition: "left",
    quadrantInternalBorderStrokeWidth: 1,
    quadrantExternalBorderStrokeWidth: 2
  },
  xyChart: {
    useMaxWidth: !0,
    width: 700,
    height: 500,
    titleFontSize: 20,
    titlePadding: 10,
    showDataLabel: !1,
    showTitle: !0,
    xAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    yAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    chartOrientation: "vertical",
    plotReservedSpacePercent: 50
  },
  requirement: {
    useMaxWidth: !0,
    rect_fill: "#f9f9f9",
    text_color: "#333",
    rect_border_size: "0.5px",
    rect_border_color: "#bbb",
    rect_min_width: 200,
    rect_min_height: 200,
    fontSize: 14,
    rect_padding: 10,
    line_height: 20
  },
  mindmap: {
    useMaxWidth: !0,
    padding: 10,
    maxNodeWidth: 200,
    layoutAlgorithm: "cose-bilkent"
  },
  kanban: {
    useMaxWidth: !0,
    padding: 8,
    sectionWidth: 200,
    ticketBaseUrl: ""
  },
  timeline: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    disableMulticolor: !1
  },
  gitGraph: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 8,
    nodeLabel: {
      width: 75,
      height: 100,
      x: -25,
      y: 0
    },
    mainBranchName: "main",
    mainBranchOrder: 0,
    showCommitLabel: !0,
    showBranches: !0,
    rotateCommitLabel: !0,
    parallelCommits: !1,
    arrowMarkerAbsolute: !1
  },
  c4: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    c4ShapeMargin: 50,
    c4ShapePadding: 20,
    width: 216,
    height: 60,
    boxMargin: 10,
    c4ShapeInRow: 4,
    nextLinePaddingX: 0,
    c4BoundaryInRow: 2,
    personFontSize: 14,
    personFontFamily: '"Open Sans", sans-serif',
    personFontWeight: "normal",
    external_personFontSize: 14,
    external_personFontFamily: '"Open Sans", sans-serif',
    external_personFontWeight: "normal",
    systemFontSize: 14,
    systemFontFamily: '"Open Sans", sans-serif',
    systemFontWeight: "normal",
    external_systemFontSize: 14,
    external_systemFontFamily: '"Open Sans", sans-serif',
    external_systemFontWeight: "normal",
    system_dbFontSize: 14,
    system_dbFontFamily: '"Open Sans", sans-serif',
    system_dbFontWeight: "normal",
    external_system_dbFontSize: 14,
    external_system_dbFontFamily: '"Open Sans", sans-serif',
    external_system_dbFontWeight: "normal",
    system_queueFontSize: 14,
    system_queueFontFamily: '"Open Sans", sans-serif',
    system_queueFontWeight: "normal",
    external_system_queueFontSize: 14,
    external_system_queueFontFamily: '"Open Sans", sans-serif',
    external_system_queueFontWeight: "normal",
    boundaryFontSize: 14,
    boundaryFontFamily: '"Open Sans", sans-serif',
    boundaryFontWeight: "normal",
    messageFontSize: 12,
    messageFontFamily: '"Open Sans", sans-serif',
    messageFontWeight: "normal",
    containerFontSize: 14,
    containerFontFamily: '"Open Sans", sans-serif',
    containerFontWeight: "normal",
    external_containerFontSize: 14,
    external_containerFontFamily: '"Open Sans", sans-serif',
    external_containerFontWeight: "normal",
    container_dbFontSize: 14,
    container_dbFontFamily: '"Open Sans", sans-serif',
    container_dbFontWeight: "normal",
    external_container_dbFontSize: 14,
    external_container_dbFontFamily: '"Open Sans", sans-serif',
    external_container_dbFontWeight: "normal",
    container_queueFontSize: 14,
    container_queueFontFamily: '"Open Sans", sans-serif',
    container_queueFontWeight: "normal",
    external_container_queueFontSize: 14,
    external_container_queueFontFamily: '"Open Sans", sans-serif',
    external_container_queueFontWeight: "normal",
    componentFontSize: 14,
    componentFontFamily: '"Open Sans", sans-serif',
    componentFontWeight: "normal",
    external_componentFontSize: 14,
    external_componentFontFamily: '"Open Sans", sans-serif',
    external_componentFontWeight: "normal",
    component_dbFontSize: 14,
    component_dbFontFamily: '"Open Sans", sans-serif',
    component_dbFontWeight: "normal",
    external_component_dbFontSize: 14,
    external_component_dbFontFamily: '"Open Sans", sans-serif',
    external_component_dbFontWeight: "normal",
    component_queueFontSize: 14,
    component_queueFontFamily: '"Open Sans", sans-serif',
    component_queueFontWeight: "normal",
    external_component_queueFontSize: 14,
    external_component_queueFontFamily: '"Open Sans", sans-serif',
    external_component_queueFontWeight: "normal",
    wrap: !0,
    wrapPadding: 10,
    person_bg_color: "#08427B",
    person_border_color: "#073B6F",
    external_person_bg_color: "#686868",
    external_person_border_color: "#8A8A8A",
    system_bg_color: "#1168BD",
    system_border_color: "#3C7FC0",
    system_db_bg_color: "#1168BD",
    system_db_border_color: "#3C7FC0",
    system_queue_bg_color: "#1168BD",
    system_queue_border_color: "#3C7FC0",
    external_system_bg_color: "#999999",
    external_system_border_color: "#8A8A8A",
    external_system_db_bg_color: "#999999",
    external_system_db_border_color: "#8A8A8A",
    external_system_queue_bg_color: "#999999",
    external_system_queue_border_color: "#8A8A8A",
    container_bg_color: "#438DD5",
    container_border_color: "#3C7FC0",
    container_db_bg_color: "#438DD5",
    container_db_border_color: "#3C7FC0",
    container_queue_bg_color: "#438DD5",
    container_queue_border_color: "#3C7FC0",
    external_container_bg_color: "#B3B3B3",
    external_container_border_color: "#A6A6A6",
    external_container_db_bg_color: "#B3B3B3",
    external_container_db_border_color: "#A6A6A6",
    external_container_queue_bg_color: "#B3B3B3",
    external_container_queue_border_color: "#A6A6A6",
    component_bg_color: "#85BBF0",
    component_border_color: "#78A8D8",
    component_db_bg_color: "#85BBF0",
    component_db_border_color: "#78A8D8",
    component_queue_bg_color: "#85BBF0",
    component_queue_border_color: "#78A8D8",
    external_component_bg_color: "#CCCCCC",
    external_component_border_color: "#BFBFBF",
    external_component_db_bg_color: "#CCCCCC",
    external_component_db_border_color: "#BFBFBF",
    external_component_queue_bg_color: "#CCCCCC",
    external_component_queue_border_color: "#BFBFBF"
  },
  sankey: {
    useMaxWidth: !0,
    width: 600,
    height: 400,
    linkColor: "gradient",
    nodeAlignment: "justify",
    showValues: !0,
    prefix: "",
    suffix: ""
  },
  block: {
    useMaxWidth: !0,
    padding: 8
  },
  packet: {
    useMaxWidth: !0,
    rowHeight: 32,
    bitWidth: 32,
    bitsPerRow: 32,
    showBits: !0,
    paddingX: 5,
    paddingY: 5
  },
  architecture: {
    useMaxWidth: !0,
    padding: 40,
    iconSize: 80,
    fontSize: 16
  },
  radar: {
    useMaxWidth: !0,
    width: 600,
    height: 600,
    marginTop: 50,
    marginRight: 50,
    marginBottom: 50,
    marginLeft: 50,
    axisScaleFactor: 1,
    axisLabelFactor: 1.05,
    curveTension: 0.17
  },
  theme: "default",
  look: "classic",
  handDrawnSeed: 0,
  layout: "dagre",
  maxTextSize: 5e4,
  maxEdges: 500,
  darkMode: !1,
  fontFamily: '"trebuchet ms", verdana, arial, sans-serif;',
  logLevel: 5,
  securityLevel: "strict",
  startOnLoad: !0,
  arrowMarkerAbsolute: !1,
  secure: [
    "secure",
    "securityLevel",
    "startOnLoad",
    "maxTextSize",
    "suppressErrorRendering",
    "maxEdges"
  ],
  legacyMathML: !1,
  forceLegacyMathML: !1,
  deterministicIds: !1,
  fontSize: 16,
  markdownAutoWrap: !0,
  suppressErrorRendering: !1
}, Dh = {
  ...ge,
  // Set, even though they're `undefined` so that `configKeys` finds these keys
  // TODO: Should we replace these with `null` so that they can go in the JSON Schema?
  deterministicIDSeed: void 0,
  elk: {
    // mergeEdges is needed here to be considered
    mergeEdges: !1,
    nodePlacementStrategy: "BRANDES_KOEPF",
    forceNodeModelOrder: !1,
    considerModelOrder: "NODES_AND_EDGES"
  },
  themeCSS: void 0,
  // add non-JSON default config values
  themeVariables: Ee.default.getThemeVariables(),
  sequence: {
    ...ge.sequence,
    messageFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont"),
    noteFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.noteFontFamily,
        fontSize: this.noteFontSize,
        fontWeight: this.noteFontWeight
      };
    }, "noteFont"),
    actorFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.actorFontFamily,
        fontSize: this.actorFontSize,
        fontWeight: this.actorFontWeight
      };
    }, "actorFont")
  },
  class: {
    hideEmptyMembersBox: !1
  },
  gantt: {
    ...ge.gantt,
    tickInterval: void 0,
    useWidth: void 0
    // can probably be removed since `configKeys` already includes this
  },
  c4: {
    ...ge.c4,
    useWidth: void 0,
    personFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.personFontFamily,
        fontSize: this.personFontSize,
        fontWeight: this.personFontWeight
      };
    }, "personFont"),
    flowchart: {
      ...ge.flowchart,
      inheritDir: !1
      // default to legacy behavior
    },
    external_personFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_personFontFamily,
        fontSize: this.external_personFontSize,
        fontWeight: this.external_personFontWeight
      };
    }, "external_personFont"),
    systemFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.systemFontFamily,
        fontSize: this.systemFontSize,
        fontWeight: this.systemFontWeight
      };
    }, "systemFont"),
    external_systemFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_systemFontFamily,
        fontSize: this.external_systemFontSize,
        fontWeight: this.external_systemFontWeight
      };
    }, "external_systemFont"),
    system_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.system_dbFontFamily,
        fontSize: this.system_dbFontSize,
        fontWeight: this.system_dbFontWeight
      };
    }, "system_dbFont"),
    external_system_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_system_dbFontFamily,
        fontSize: this.external_system_dbFontSize,
        fontWeight: this.external_system_dbFontWeight
      };
    }, "external_system_dbFont"),
    system_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.system_queueFontFamily,
        fontSize: this.system_queueFontSize,
        fontWeight: this.system_queueFontWeight
      };
    }, "system_queueFont"),
    external_system_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_system_queueFontFamily,
        fontSize: this.external_system_queueFontSize,
        fontWeight: this.external_system_queueFontWeight
      };
    }, "external_system_queueFont"),
    containerFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.containerFontFamily,
        fontSize: this.containerFontSize,
        fontWeight: this.containerFontWeight
      };
    }, "containerFont"),
    external_containerFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_containerFontFamily,
        fontSize: this.external_containerFontSize,
        fontWeight: this.external_containerFontWeight
      };
    }, "external_containerFont"),
    container_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.container_dbFontFamily,
        fontSize: this.container_dbFontSize,
        fontWeight: this.container_dbFontWeight
      };
    }, "container_dbFont"),
    external_container_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_container_dbFontFamily,
        fontSize: this.external_container_dbFontSize,
        fontWeight: this.external_container_dbFontWeight
      };
    }, "external_container_dbFont"),
    container_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.container_queueFontFamily,
        fontSize: this.container_queueFontSize,
        fontWeight: this.container_queueFontWeight
      };
    }, "container_queueFont"),
    external_container_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_container_queueFontFamily,
        fontSize: this.external_container_queueFontSize,
        fontWeight: this.external_container_queueFontWeight
      };
    }, "external_container_queueFont"),
    componentFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.componentFontFamily,
        fontSize: this.componentFontSize,
        fontWeight: this.componentFontWeight
      };
    }, "componentFont"),
    external_componentFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_componentFontFamily,
        fontSize: this.external_componentFontSize,
        fontWeight: this.external_componentFontWeight
      };
    }, "external_componentFont"),
    component_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.component_dbFontFamily,
        fontSize: this.component_dbFontSize,
        fontWeight: this.component_dbFontWeight
      };
    }, "component_dbFont"),
    external_component_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_component_dbFontFamily,
        fontSize: this.external_component_dbFontSize,
        fontWeight: this.external_component_dbFontWeight
      };
    }, "external_component_dbFont"),
    component_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.component_queueFontFamily,
        fontSize: this.component_queueFontSize,
        fontWeight: this.component_queueFontWeight
      };
    }, "component_queueFont"),
    external_component_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_component_queueFontFamily,
        fontSize: this.external_component_queueFontSize,
        fontWeight: this.external_component_queueFontWeight
      };
    }, "external_component_queueFont"),
    boundaryFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.boundaryFontFamily,
        fontSize: this.boundaryFontSize,
        fontWeight: this.boundaryFontWeight
      };
    }, "boundaryFont"),
    messageFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont")
  },
  pie: {
    ...ge.pie,
    useWidth: 984
  },
  xyChart: {
    ...ge.xyChart,
    useWidth: void 0
  },
  requirement: {
    ...ge.requirement,
    useWidth: void 0
  },
  packet: {
    ...ge.packet
  },
  radar: {
    ...ge.radar
  },
  treemap: {
    useMaxWidth: !0,
    padding: 10,
    diagramPadding: 8,
    showValues: !0,
    nodeWidth: 100,
    nodeHeight: 40,
    borderWidth: 1,
    valueFontSize: 12,
    labelFontSize: 14,
    valueFormat: ","
  }
}, Oh = /* @__PURE__ */ p((e, t = "") => Object.keys(e).reduce((r, i) => Array.isArray(e[i]) ? r : typeof e[i] == "object" && e[i] !== null ? [...r, t + i, ...Oh(e[i], "")] : [...r, t + i], []), "keyify"), H0 = new Set(Oh(Dh, "")), Rh = Dh, In = /* @__PURE__ */ p((e) => {
  if (F.debug("sanitizeDirective called with", e), !(typeof e != "object" || e == null)) {
    if (Array.isArray(e)) {
      e.forEach((t) => In(t));
      return;
    }
    for (const t of Object.keys(e)) {
      if (F.debug("Checking key", t), t.startsWith("__") || t.includes("proto") || t.includes("constr") || !H0.has(t) || e[t] == null) {
        F.debug("sanitize deleting key: ", t), delete e[t];
        continue;
      }
      if (typeof e[t] == "object") {
        F.debug("sanitizing object", t), In(e[t]);
        continue;
      }
      const r = ["themeCSS", "fontFamily", "altFontFamily"];
      for (const i of r)
        t.includes(i) && (F.debug("sanitizing css option", t), e[t] = j0(e[t]));
    }
    if (e.themeVariables)
      for (const t of Object.keys(e.themeVariables)) {
        const r = e.themeVariables[t];
        r?.match && !r.match(/^[\d "#%(),.;A-Za-z]+$/) && (e.themeVariables[t] = "");
      }
    F.debug("After sanitization", e);
  }
}, "sanitizeDirective"), j0 = /* @__PURE__ */ p((e) => {
  let t = 0, r = 0;
  for (const i of e) {
    if (t < r)
      return "{ /* ERROR: Unbalanced CSS */ }";
    i === "{" ? t++ : i === "}" && r++;
  }
  return t !== r ? "{ /* ERROR: Unbalanced CSS */ }" : e;
}, "sanitizeCss"), jr = Object.freeze(Rh), Gt = St({}, jr), Pn, ur = [], Li = St({}, jr), wa = /* @__PURE__ */ p((e, t) => {
  let r = St({}, e), i = {};
  for (const n of t)
    Nh(n), i = St(i, n);
  if (r = St(r, i), i.theme && i.theme in Ee) {
    const n = St({}, Pn), a = St(
      n.themeVariables || {},
      i.themeVariables
    );
    r.theme && r.theme in Ee && (r.themeVariables = Ee[r.theme].getThemeVariables(a));
  }
  return Li = r, zh(Li), Li;
}, "updateCurrentConfig"), Y0 = /* @__PURE__ */ p((e) => (Gt = St({}, jr), Gt = St(Gt, e), e.theme && Ee[e.theme] && (Gt.themeVariables = Ee[e.theme].getThemeVariables(e.themeVariables)), wa(Gt, ur), Gt), "setSiteConfig"), U0 = /* @__PURE__ */ p((e) => {
  Pn = St({}, e);
}, "saveConfigFromInitialize"), G0 = /* @__PURE__ */ p((e) => (Gt = St(Gt, e), wa(Gt, ur), Gt), "updateSiteConfig"), Ih = /* @__PURE__ */ p(() => St({}, Gt), "getSiteConfig"), Ph = /* @__PURE__ */ p((e) => (zh(e), St(Li, e), Dt()), "setConfig"), Dt = /* @__PURE__ */ p(() => St({}, Li), "getConfig"), Nh = /* @__PURE__ */ p((e) => {
  e && (["secure", ...Gt.secure ?? []].forEach((t) => {
    Object.hasOwn(e, t) && (F.debug(`Denied attempt to modify a secure key ${t}`, e[t]), delete e[t]);
  }), Object.keys(e).forEach((t) => {
    t.startsWith("__") && delete e[t];
  }), Object.keys(e).forEach((t) => {
    typeof e[t] == "string" && (e[t].includes("<") || e[t].includes(">") || e[t].includes("url(data:")) && delete e[t], typeof e[t] == "object" && Nh(e[t]);
  }));
}, "sanitize"), X0 = /* @__PURE__ */ p((e) => {
  In(e), e.fontFamily && !e.themeVariables?.fontFamily && (e.themeVariables = {
    ...e.themeVariables,
    fontFamily: e.fontFamily
  }), ur.push(e), wa(Gt, ur);
}, "addDirective"), Nn = /* @__PURE__ */ p((e = Gt) => {
  ur = [], wa(e, ur);
}, "reset"), V0 = {
  LAZY_LOAD_DEPRECATED: "The configuration options lazyLoadedDiagrams and loadExternalDiagramsAtStartup are deprecated. Please use registerExternalDiagrams instead."
}, Ql = {}, Z0 = /* @__PURE__ */ p((e) => {
  Ql[e] || (F.warn(V0[e]), Ql[e] = !0);
}, "issueWarning"), zh = /* @__PURE__ */ p((e) => {
  e && (e.lazyLoadedDiagrams || e.loadExternalDiagramsAtStartup) && Z0("LAZY_LOAD_DEPRECATED");
}, "checkConfig"), UA = /* @__PURE__ */ p(() => {
  let e = {};
  Pn && (e = St(e, Pn));
  for (const t of ur)
    e = St(e, t);
  return e;
}, "getUserDefinedConfig"), Ui = /<br\s*\/?>/gi, K0 = /* @__PURE__ */ p((e) => e ? Hh(e).replace(/\\n/g, "#br#").split("#br#") : [""], "getRows"), Q0 = /* @__PURE__ */ (() => {
  let e = !1;
  return () => {
    e || (Wh(), e = !0);
  };
})();
function Wh() {
  const e = "data-temp-href-target";
  Hr.addHook("beforeSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute("target") && t.setAttribute(e, t.getAttribute("target") ?? "");
  }), Hr.addHook("afterSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute(e) && (t.setAttribute("target", t.getAttribute(e) ?? ""), t.removeAttribute(e), t.getAttribute("target") === "_blank" && t.setAttribute("rel", "noopener"));
  });
}
p(Wh, "setupDompurifyHooks");
var qh = /* @__PURE__ */ p((e) => (Q0(), Hr.sanitize(e)), "removeScript"), Jl = /* @__PURE__ */ p((e, t) => {
  if (t.flowchart?.htmlLabels !== !1) {
    const r = t.securityLevel;
    r === "antiscript" || r === "strict" ? e = qh(e) : r !== "loose" && (e = Hh(e), e = e.replace(/</g, "&lt;").replace(/>/g, "&gt;"), e = e.replace(/=/g, "&equals;"), e = ry(e));
  }
  return e;
}, "sanitizeMore"), te = /* @__PURE__ */ p((e, t) => e && (t.dompurifyConfig ? e = Hr.sanitize(Jl(e, t), t.dompurifyConfig).toString() : e = Hr.sanitize(Jl(e, t), {
  FORBID_TAGS: ["style"]
}).toString(), e), "sanitizeText"), J0 = /* @__PURE__ */ p((e, t) => typeof e == "string" ? te(e, t) : e.flat().map((r) => te(r, t)), "sanitizeTextOrArray"), ty = /* @__PURE__ */ p((e) => Ui.test(e), "hasBreaks"), ey = /* @__PURE__ */ p((e) => e.split(Ui), "splitBreaks"), ry = /* @__PURE__ */ p((e) => e.replace(/#br#/g, "<br/>"), "placeholderToBreak"), Hh = /* @__PURE__ */ p((e) => e.replace(Ui, "#br#"), "breakToPlaceholder"), iy = /* @__PURE__ */ p((e) => {
  let t = "";
  return e && (t = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, t = CSS.escape(t)), t;
}, "getUrl"), Bt = /* @__PURE__ */ p((e) => !(e === !1 || ["false", "null", "0"].includes(String(e).trim().toLowerCase())), "evaluate"), ny = /* @__PURE__ */ p(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.max(...t);
}, "getMax"), ay = /* @__PURE__ */ p(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.min(...t);
}, "getMin"), tc = /* @__PURE__ */ p(function(e) {
  const t = e.split(/(,)/), r = [];
  for (let i = 0; i < t.length; i++) {
    let n = t[i];
    if (n === "," && i > 0 && i + 1 < t.length) {
      const a = t[i - 1], s = t[i + 1];
      sy(a, s) && (n = a + "," + s, i++, r.pop());
    }
    r.push(oy(n));
  }
  return r.join("");
}, "parseGenericTypes"), As = /* @__PURE__ */ p((e, t) => Math.max(0, e.split(t).length - 1), "countOccurrence"), sy = /* @__PURE__ */ p((e, t) => {
  const r = As(e, "~"), i = As(t, "~");
  return r === 1 && i === 1;
}, "shouldCombineSets"), oy = /* @__PURE__ */ p((e) => {
  const t = As(e, "~");
  let r = !1;
  if (t <= 1)
    return e;
  t % 2 !== 0 && e.startsWith("~") && (e = e.substring(1), r = !0);
  const i = [...e];
  let n = i.indexOf("~"), a = i.lastIndexOf("~");
  for (; n !== -1 && a !== -1 && n !== a; )
    i[n] = "<", i[a] = ">", n = i.indexOf("~"), a = i.lastIndexOf("~");
  return r && i.unshift("~"), i.join("");
}, "processSet"), ec = /* @__PURE__ */ p(() => window.MathMLElement !== void 0, "isMathMLSupported"), Ls = /\$\$(.*)\$\$/g, Yr = /* @__PURE__ */ p((e) => (e.match(Ls)?.length ?? 0) > 0, "hasKatex"), GA = /* @__PURE__ */ p(async (e, t) => {
  const r = document.createElement("div");
  r.innerHTML = await So(e, t), r.id = "katex-temp", r.style.visibility = "hidden", r.style.position = "absolute", r.style.top = "0", document.querySelector("body")?.insertAdjacentElement("beforeend", r);
  const n = { width: r.clientWidth, height: r.clientHeight };
  return r.remove(), n;
}, "calculateMathMLDimensions"), ly = /* @__PURE__ */ p(async (e, t) => {
  if (!Yr(e))
    return e;
  if (!(ec() || t.legacyMathML || t.forceLegacyMathML))
    return e.replace(Ls, "MathML is unsupported in this environment.");
  {
    const { default: r } = await import("./katex-DNob3HGn.js"), i = t.forceLegacyMathML || !ec() && t.legacyMathML ? "htmlAndMathml" : "mathml";
    return e.split(Ui).map(
      (n) => Yr(n) ? `<div style="display: flex; align-items: center; justify-content: center; white-space: nowrap;">${n}</div>` : `<div>${n}</div>`
    ).join("").replace(
      Ls,
      (n, a) => r.renderToString(a, {
        throwOnError: !0,
        displayMode: !0,
        output: i
      }).replace(/\n/g, " ").replace(/<annotation.*<\/annotation>/g, "")
    );
  }
}, "renderKatexUnsanitized"), So = /* @__PURE__ */ p(async (e, t) => te(await ly(e, t), t), "renderKatexSanitized"), Qr = {
  getRows: K0,
  sanitizeText: te,
  sanitizeTextOrArray: J0,
  hasBreaks: ty,
  splitBreaks: ey,
  lineBreakRegex: Ui,
  removeScript: qh,
  getUrl: iy,
  evaluate: Bt,
  getMax: ny,
  getMin: ay
}, cy = /* @__PURE__ */ p(function(e, t) {
  for (let r of t)
    e.attr(r[0], r[1]);
}, "d3Attrs"), hy = /* @__PURE__ */ p(function(e, t, r) {
  let i = /* @__PURE__ */ new Map();
  return r ? (i.set("width", "100%"), i.set("style", `max-width: ${t}px;`)) : (i.set("height", e), i.set("width", t)), i;
}, "calculateSvgSizeAttrs"), jh = /* @__PURE__ */ p(function(e, t, r, i) {
  const n = hy(t, r, i);
  cy(e, n);
}, "configureSvgSize"), uy = /* @__PURE__ */ p(function(e, t, r, i) {
  const n = t.node().getBBox(), a = n.width, s = n.height;
  F.info(`SVG bounds: ${a}x${s}`, n);
  let o = 0, l = 0;
  F.info(`Graph bounds: ${o}x${l}`, e), o = a + r * 2, l = s + r * 2, F.info(`Calculated bounds: ${o}x${l}`), jh(t, l, o, i);
  const c = `${n.x - r} ${n.y - r} ${n.width + 2 * r} ${n.height + 2 * r}`;
  t.attr("viewBox", c);
}, "setupGraphViewbox"), Sn = {}, fy = /* @__PURE__ */ p((e, t, r) => {
  let i = "";
  return e in Sn && Sn[e] ? i = Sn[e](r) : F.warn(`No theme found for ${e}`), ` & {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
    fill: ${r.textColor}
  }
  @keyframes edge-animation-frame {
    from {
      stroke-dashoffset: 0;
    }
  }
  @keyframes dash {
    to {
      stroke-dashoffset: 0;
    }
  }
  & .edge-animation-slow {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 50s linear infinite;
    stroke-linecap: round;
  }
  & .edge-animation-fast {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 20s linear infinite;
    stroke-linecap: round;
  }
  /* Classes common for multiple diagrams */

  & .error-icon {
    fill: ${r.errorBkgColor};
  }
  & .error-text {
    fill: ${r.errorTextColor};
    stroke: ${r.errorTextColor};
  }

  & .edge-thickness-normal {
    stroke-width: 1px;
  }
  & .edge-thickness-thick {
    stroke-width: 3.5px
  }
  & .edge-pattern-solid {
    stroke-dasharray: 0;
  }
  & .edge-thickness-invisible {
    stroke-width: 0;
    fill: none;
  }
  & .edge-pattern-dashed{
    stroke-dasharray: 3;
  }
  .edge-pattern-dotted {
    stroke-dasharray: 2;
  }

  & .marker {
    fill: ${r.lineColor};
    stroke: ${r.lineColor};
  }
  & .marker.cross {
    stroke: ${r.lineColor};
  }

  & svg {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
  }
   & p {
    margin: 0
   }

  ${i}

  ${t}
`;
}, "getStyles"), dy = /* @__PURE__ */ p((e, t) => {
  t !== void 0 && (Sn[e] = t);
}, "addStylesForDiagram"), py = fy, Yh = {};
r0(Yh, {
  clear: () => gy,
  getAccDescription: () => by,
  getAccTitle: () => yy,
  getDiagramTitle: () => _y,
  setAccDescription: () => xy,
  setAccTitle: () => my,
  setDiagramTitle: () => Cy
});
var To = "", Bo = "", Ao = "", Lo = /* @__PURE__ */ p((e) => te(e, Dt()), "sanitizeText"), gy = /* @__PURE__ */ p(() => {
  To = "", Ao = "", Bo = "";
}, "clear"), my = /* @__PURE__ */ p((e) => {
  To = Lo(e).replace(/^\s+/g, "");
}, "setAccTitle"), yy = /* @__PURE__ */ p(() => To, "getAccTitle"), xy = /* @__PURE__ */ p((e) => {
  Ao = Lo(e).replace(/\n\s+/g, `
`);
}, "setAccDescription"), by = /* @__PURE__ */ p(() => Ao, "getAccDescription"), Cy = /* @__PURE__ */ p((e) => {
  Bo = Lo(e);
}, "setDiagramTitle"), _y = /* @__PURE__ */ p(() => Bo, "getDiagramTitle"), rc = F, wy = ko, ft = Dt, XA = Ph, VA = jr, Mo = /* @__PURE__ */ p((e) => te(e, ft()), "sanitizeText"), ky = uy, vy = /* @__PURE__ */ p(() => Yh, "getCommonDb"), zn = {}, Wn = /* @__PURE__ */ p((e, t, r) => {
  zn[e] && rc.warn(`Diagram with id ${e} already registered. Overwriting.`), zn[e] = t, r && Fh(e, r), dy(e, t.styles), t.injectUtils?.(
    rc,
    wy,
    ft,
    Mo,
    ky,
    vy(),
    () => {
    }
  );
}, "registerDiagram"), Ms = /* @__PURE__ */ p((e) => {
  if (e in zn)
    return zn[e];
  throw new Sy(e);
}, "getDiagram"), Wr, Sy = (Wr = class extends Error {
  constructor(t) {
    super(`Diagram ${t} not found.`);
  }
}, p(Wr, "DiagramNotFoundError"), Wr), Ty = { value: () => {
} };
function Uh() {
  for (var e = 0, t = arguments.length, r = {}, i; e < t; ++e) {
    if (!(i = arguments[e] + "") || i in r || /[\s.]/.test(i)) throw new Error("illegal type: " + i);
    r[i] = [];
  }
  return new Tn(r);
}
function Tn(e) {
  this._ = e;
}
function By(e, t) {
  return e.trim().split(/^|\s+/).map(function(r) {
    var i = "", n = r.indexOf(".");
    if (n >= 0 && (i = r.slice(n + 1), r = r.slice(0, n)), r && !t.hasOwnProperty(r)) throw new Error("unknown type: " + r);
    return { type: r, name: i };
  });
}
Tn.prototype = Uh.prototype = {
  constructor: Tn,
  on: function(e, t) {
    var r = this._, i = By(e + "", r), n, a = -1, s = i.length;
    if (arguments.length < 2) {
      for (; ++a < s; ) if ((n = (e = i[a]).type) && (n = Ay(r[n], e.name))) return n;
      return;
    }
    if (t != null && typeof t != "function") throw new Error("invalid callback: " + t);
    for (; ++a < s; )
      if (n = (e = i[a]).type) r[n] = ic(r[n], e.name, t);
      else if (t == null) for (n in r) r[n] = ic(r[n], e.name, null);
    return this;
  },
  copy: function() {
    var e = {}, t = this._;
    for (var r in t) e[r] = t[r].slice();
    return new Tn(e);
  },
  call: function(e, t) {
    if ((n = arguments.length - 2) > 0) for (var r = new Array(n), i = 0, n, a; i < n; ++i) r[i] = arguments[i + 2];
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (a = this._[e], i = 0, n = a.length; i < n; ++i) a[i].value.apply(t, r);
  },
  apply: function(e, t, r) {
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (var i = this._[e], n = 0, a = i.length; n < a; ++n) i[n].value.apply(t, r);
  }
};
function Ay(e, t) {
  for (var r = 0, i = e.length, n; r < i; ++r)
    if ((n = e[r]).name === t)
      return n.value;
}
function ic(e, t, r) {
  for (var i = 0, n = e.length; i < n; ++i)
    if (e[i].name === t) {
      e[i] = Ty, e = e.slice(0, i).concat(e.slice(i + 1));
      break;
    }
  return r != null && e.push({ name: t, value: r }), e;
}
var $s = "http://www.w3.org/1999/xhtml";
const nc = {
  svg: "http://www.w3.org/2000/svg",
  xhtml: $s,
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
};
function ka(e) {
  var t = e += "", r = t.indexOf(":");
  return r >= 0 && (t = e.slice(0, r)) !== "xmlns" && (e = e.slice(r + 1)), nc.hasOwnProperty(t) ? { space: nc[t], local: e } : e;
}
function Ly(e) {
  return function() {
    var t = this.ownerDocument, r = this.namespaceURI;
    return r === $s && t.documentElement.namespaceURI === $s ? t.createElement(e) : t.createElementNS(r, e);
  };
}
function My(e) {
  return function() {
    return this.ownerDocument.createElementNS(e.space, e.local);
  };
}
function Gh(e) {
  var t = ka(e);
  return (t.local ? My : Ly)(t);
}
function $y() {
}
function $o(e) {
  return e == null ? $y : function() {
    return this.querySelector(e);
  };
}
function Ey(e) {
  typeof e != "function" && (e = $o(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], s = a.length, o = i[n] = new Array(s), l, c, h = 0; h < s; ++h)
      (l = a[h]) && (c = e.call(l, l.__data__, h, a)) && ("__data__" in l && (c.__data__ = l.__data__), o[h] = c);
  return new Kt(i, this._parents);
}
function Fy(e) {
  return e == null ? [] : Array.isArray(e) ? e : Array.from(e);
}
function Dy() {
  return [];
}
function Xh(e) {
  return e == null ? Dy : function() {
    return this.querySelectorAll(e);
  };
}
function Oy(e) {
  return function() {
    return Fy(e.apply(this, arguments));
  };
}
function Ry(e) {
  typeof e == "function" ? e = Oy(e) : e = Xh(e);
  for (var t = this._groups, r = t.length, i = [], n = [], a = 0; a < r; ++a)
    for (var s = t[a], o = s.length, l, c = 0; c < o; ++c)
      (l = s[c]) && (i.push(e.call(l, l.__data__, c, s)), n.push(l));
  return new Kt(i, n);
}
function Vh(e) {
  return function() {
    return this.matches(e);
  };
}
function Zh(e) {
  return function(t) {
    return t.matches(e);
  };
}
var Iy = Array.prototype.find;
function Py(e) {
  return function() {
    return Iy.call(this.children, e);
  };
}
function Ny() {
  return this.firstElementChild;
}
function zy(e) {
  return this.select(e == null ? Ny : Py(typeof e == "function" ? e : Zh(e)));
}
var Wy = Array.prototype.filter;
function qy() {
  return Array.from(this.children);
}
function Hy(e) {
  return function() {
    return Wy.call(this.children, e);
  };
}
function jy(e) {
  return this.selectAll(e == null ? qy : Hy(typeof e == "function" ? e : Zh(e)));
}
function Yy(e) {
  typeof e != "function" && (e = Vh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], s = a.length, o = i[n] = [], l, c = 0; c < s; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && o.push(l);
  return new Kt(i, this._parents);
}
function Kh(e) {
  return new Array(e.length);
}
function Uy() {
  return new Kt(this._enter || this._groups.map(Kh), this._parents);
}
function qn(e, t) {
  this.ownerDocument = e.ownerDocument, this.namespaceURI = e.namespaceURI, this._next = null, this._parent = e, this.__data__ = t;
}
qn.prototype = {
  constructor: qn,
  appendChild: function(e) {
    return this._parent.insertBefore(e, this._next);
  },
  insertBefore: function(e, t) {
    return this._parent.insertBefore(e, t);
  },
  querySelector: function(e) {
    return this._parent.querySelector(e);
  },
  querySelectorAll: function(e) {
    return this._parent.querySelectorAll(e);
  }
};
function Gy(e) {
  return function() {
    return e;
  };
}
function Xy(e, t, r, i, n, a) {
  for (var s = 0, o, l = t.length, c = a.length; s < c; ++s)
    (o = t[s]) ? (o.__data__ = a[s], i[s] = o) : r[s] = new qn(e, a[s]);
  for (; s < l; ++s)
    (o = t[s]) && (n[s] = o);
}
function Vy(e, t, r, i, n, a, s) {
  var o, l, c = /* @__PURE__ */ new Map(), h = t.length, u = a.length, f = new Array(h), d;
  for (o = 0; o < h; ++o)
    (l = t[o]) && (f[o] = d = s.call(l, l.__data__, o, t) + "", c.has(d) ? n[o] = l : c.set(d, l));
  for (o = 0; o < u; ++o)
    d = s.call(e, a[o], o, a) + "", (l = c.get(d)) ? (i[o] = l, l.__data__ = a[o], c.delete(d)) : r[o] = new qn(e, a[o]);
  for (o = 0; o < h; ++o)
    (l = t[o]) && c.get(f[o]) === l && (n[o] = l);
}
function Zy(e) {
  return e.__data__;
}
function Ky(e, t) {
  if (!arguments.length) return Array.from(this, Zy);
  var r = t ? Vy : Xy, i = this._parents, n = this._groups;
  typeof e != "function" && (e = Gy(e));
  for (var a = n.length, s = new Array(a), o = new Array(a), l = new Array(a), c = 0; c < a; ++c) {
    var h = i[c], u = n[c], f = u.length, d = Qy(e.call(h, h && h.__data__, c, i)), g = d.length, m = o[c] = new Array(g), y = s[c] = new Array(g), x = l[c] = new Array(f);
    r(h, u, m, y, x, d, t);
    for (var b = 0, C = 0, k, w; b < g; ++b)
      if (k = m[b]) {
        for (b >= C && (C = b + 1); !(w = y[C]) && ++C < g; ) ;
        k._next = w || null;
      }
  }
  return s = new Kt(s, i), s._enter = o, s._exit = l, s;
}
function Qy(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function Jy() {
  return new Kt(this._exit || this._groups.map(Kh), this._parents);
}
function tx(e, t, r) {
  var i = this.enter(), n = this, a = this.exit();
  return typeof e == "function" ? (i = e(i), i && (i = i.selection())) : i = i.append(e + ""), t != null && (n = t(n), n && (n = n.selection())), r == null ? a.remove() : r(a), i && n ? i.merge(n).order() : n;
}
function ex(e) {
  for (var t = e.selection ? e.selection() : e, r = this._groups, i = t._groups, n = r.length, a = i.length, s = Math.min(n, a), o = new Array(n), l = 0; l < s; ++l)
    for (var c = r[l], h = i[l], u = c.length, f = o[l] = new Array(u), d, g = 0; g < u; ++g)
      (d = c[g] || h[g]) && (f[g] = d);
  for (; l < n; ++l)
    o[l] = r[l];
  return new Kt(o, this._parents);
}
function rx() {
  for (var e = this._groups, t = -1, r = e.length; ++t < r; )
    for (var i = e[t], n = i.length - 1, a = i[n], s; --n >= 0; )
      (s = i[n]) && (a && s.compareDocumentPosition(a) ^ 4 && a.parentNode.insertBefore(s, a), a = s);
  return this;
}
function ix(e) {
  e || (e = nx);
  function t(u, f) {
    return u && f ? e(u.__data__, f.__data__) : !u - !f;
  }
  for (var r = this._groups, i = r.length, n = new Array(i), a = 0; a < i; ++a) {
    for (var s = r[a], o = s.length, l = n[a] = new Array(o), c, h = 0; h < o; ++h)
      (c = s[h]) && (l[h] = c);
    l.sort(t);
  }
  return new Kt(n, this._parents).order();
}
function nx(e, t) {
  return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function ax() {
  var e = arguments[0];
  return arguments[0] = this, e.apply(null, arguments), this;
}
function sx() {
  return Array.from(this);
}
function ox() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length; n < a; ++n) {
      var s = i[n];
      if (s) return s;
    }
  return null;
}
function lx() {
  let e = 0;
  for (const t of this) ++e;
  return e;
}
function cx() {
  return !this.node();
}
function hx(e) {
  for (var t = this._groups, r = 0, i = t.length; r < i; ++r)
    for (var n = t[r], a = 0, s = n.length, o; a < s; ++a)
      (o = n[a]) && e.call(o, o.__data__, a, n);
  return this;
}
function ux(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function fx(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function dx(e, t) {
  return function() {
    this.setAttribute(e, t);
  };
}
function px(e, t) {
  return function() {
    this.setAttributeNS(e.space, e.local, t);
  };
}
function gx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttribute(e) : this.setAttribute(e, r);
  };
}
function mx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttributeNS(e.space, e.local) : this.setAttributeNS(e.space, e.local, r);
  };
}
function yx(e, t) {
  var r = ka(e);
  if (arguments.length < 2) {
    var i = this.node();
    return r.local ? i.getAttributeNS(r.space, r.local) : i.getAttribute(r);
  }
  return this.each((t == null ? r.local ? fx : ux : typeof t == "function" ? r.local ? mx : gx : r.local ? px : dx)(r, t));
}
function Qh(e) {
  return e.ownerDocument && e.ownerDocument.defaultView || e.document && e || e.defaultView;
}
function xx(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function bx(e, t, r) {
  return function() {
    this.style.setProperty(e, t, r);
  };
}
function Cx(e, t, r) {
  return function() {
    var i = t.apply(this, arguments);
    i == null ? this.style.removeProperty(e) : this.style.setProperty(e, i, r);
  };
}
function _x(e, t, r) {
  return arguments.length > 1 ? this.each((t == null ? xx : typeof t == "function" ? Cx : bx)(e, t, r ?? "")) : Ur(this.node(), e);
}
function Ur(e, t) {
  return e.style.getPropertyValue(t) || Qh(e).getComputedStyle(e, null).getPropertyValue(t);
}
function wx(e) {
  return function() {
    delete this[e];
  };
}
function kx(e, t) {
  return function() {
    this[e] = t;
  };
}
function vx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? delete this[e] : this[e] = r;
  };
}
function Sx(e, t) {
  return arguments.length > 1 ? this.each((t == null ? wx : typeof t == "function" ? vx : kx)(e, t)) : this.node()[e];
}
function Jh(e) {
  return e.trim().split(/^|\s+/);
}
function Eo(e) {
  return e.classList || new tu(e);
}
function tu(e) {
  this._node = e, this._names = Jh(e.getAttribute("class") || "");
}
tu.prototype = {
  add: function(e) {
    var t = this._names.indexOf(e);
    t < 0 && (this._names.push(e), this._node.setAttribute("class", this._names.join(" ")));
  },
  remove: function(e) {
    var t = this._names.indexOf(e);
    t >= 0 && (this._names.splice(t, 1), this._node.setAttribute("class", this._names.join(" ")));
  },
  contains: function(e) {
    return this._names.indexOf(e) >= 0;
  }
};
function eu(e, t) {
  for (var r = Eo(e), i = -1, n = t.length; ++i < n; ) r.add(t[i]);
}
function ru(e, t) {
  for (var r = Eo(e), i = -1, n = t.length; ++i < n; ) r.remove(t[i]);
}
function Tx(e) {
  return function() {
    eu(this, e);
  };
}
function Bx(e) {
  return function() {
    ru(this, e);
  };
}
function Ax(e, t) {
  return function() {
    (t.apply(this, arguments) ? eu : ru)(this, e);
  };
}
function Lx(e, t) {
  var r = Jh(e + "");
  if (arguments.length < 2) {
    for (var i = Eo(this.node()), n = -1, a = r.length; ++n < a; ) if (!i.contains(r[n])) return !1;
    return !0;
  }
  return this.each((typeof t == "function" ? Ax : t ? Tx : Bx)(r, t));
}
function Mx() {
  this.textContent = "";
}
function $x(e) {
  return function() {
    this.textContent = e;
  };
}
function Ex(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.textContent = t ?? "";
  };
}
function Fx(e) {
  return arguments.length ? this.each(e == null ? Mx : (typeof e == "function" ? Ex : $x)(e)) : this.node().textContent;
}
function Dx() {
  this.innerHTML = "";
}
function Ox(e) {
  return function() {
    this.innerHTML = e;
  };
}
function Rx(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.innerHTML = t ?? "";
  };
}
function Ix(e) {
  return arguments.length ? this.each(e == null ? Dx : (typeof e == "function" ? Rx : Ox)(e)) : this.node().innerHTML;
}
function Px() {
  this.nextSibling && this.parentNode.appendChild(this);
}
function Nx() {
  return this.each(Px);
}
function zx() {
  this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function Wx() {
  return this.each(zx);
}
function qx(e) {
  var t = typeof e == "function" ? e : Gh(e);
  return this.select(function() {
    return this.appendChild(t.apply(this, arguments));
  });
}
function Hx() {
  return null;
}
function jx(e, t) {
  var r = typeof e == "function" ? e : Gh(e), i = t == null ? Hx : typeof t == "function" ? t : $o(t);
  return this.select(function() {
    return this.insertBefore(r.apply(this, arguments), i.apply(this, arguments) || null);
  });
}
function Yx() {
  var e = this.parentNode;
  e && e.removeChild(this);
}
function Ux() {
  return this.each(Yx);
}
function Gx() {
  var e = this.cloneNode(!1), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Xx() {
  var e = this.cloneNode(!0), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Vx(e) {
  return this.select(e ? Xx : Gx);
}
function Zx(e) {
  return arguments.length ? this.property("__data__", e) : this.node().__data__;
}
function Kx(e) {
  return function(t) {
    e.call(this, t, this.__data__);
  };
}
function Qx(e) {
  return e.trim().split(/^|\s+/).map(function(t) {
    var r = "", i = t.indexOf(".");
    return i >= 0 && (r = t.slice(i + 1), t = t.slice(0, i)), { type: t, name: r };
  });
}
function Jx(e) {
  return function() {
    var t = this.__on;
    if (t) {
      for (var r = 0, i = -1, n = t.length, a; r < n; ++r)
        a = t[r], (!e.type || a.type === e.type) && a.name === e.name ? this.removeEventListener(a.type, a.listener, a.options) : t[++i] = a;
      ++i ? t.length = i : delete this.__on;
    }
  };
}
function tb(e, t, r) {
  return function() {
    var i = this.__on, n, a = Kx(t);
    if (i) {
      for (var s = 0, o = i.length; s < o; ++s)
        if ((n = i[s]).type === e.type && n.name === e.name) {
          this.removeEventListener(n.type, n.listener, n.options), this.addEventListener(n.type, n.listener = a, n.options = r), n.value = t;
          return;
        }
    }
    this.addEventListener(e.type, a, r), n = { type: e.type, name: e.name, value: t, listener: a, options: r }, i ? i.push(n) : this.__on = [n];
  };
}
function eb(e, t, r) {
  var i = Qx(e + ""), n, a = i.length, s;
  if (arguments.length < 2) {
    var o = this.node().__on;
    if (o) {
      for (var l = 0, c = o.length, h; l < c; ++l)
        for (n = 0, h = o[l]; n < a; ++n)
          if ((s = i[n]).type === h.type && s.name === h.name)
            return h.value;
    }
    return;
  }
  for (o = t ? tb : Jx, n = 0; n < a; ++n) this.each(o(i[n], t, r));
  return this;
}
function iu(e, t, r) {
  var i = Qh(e), n = i.CustomEvent;
  typeof n == "function" ? n = new n(t, r) : (n = i.document.createEvent("Event"), r ? (n.initEvent(t, r.bubbles, r.cancelable), n.detail = r.detail) : n.initEvent(t, !1, !1)), e.dispatchEvent(n);
}
function rb(e, t) {
  return function() {
    return iu(this, e, t);
  };
}
function ib(e, t) {
  return function() {
    return iu(this, e, t.apply(this, arguments));
  };
}
function nb(e, t) {
  return this.each((typeof t == "function" ? ib : rb)(e, t));
}
function* ab() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length, s; n < a; ++n)
      (s = i[n]) && (yield s);
}
var nu = [null];
function Kt(e, t) {
  this._groups = e, this._parents = t;
}
function Gi() {
  return new Kt([[document.documentElement]], nu);
}
function sb() {
  return this;
}
Kt.prototype = Gi.prototype = {
  constructor: Kt,
  select: Ey,
  selectAll: Ry,
  selectChild: zy,
  selectChildren: jy,
  filter: Yy,
  data: Ky,
  enter: Uy,
  exit: Jy,
  join: tx,
  merge: ex,
  selection: sb,
  order: rx,
  sort: ix,
  call: ax,
  nodes: sx,
  node: ox,
  size: lx,
  empty: cx,
  each: hx,
  attr: yx,
  style: _x,
  property: Sx,
  classed: Lx,
  text: Fx,
  html: Ix,
  raise: Nx,
  lower: Wx,
  append: qx,
  insert: jx,
  remove: Ux,
  clone: Vx,
  datum: Zx,
  on: eb,
  dispatch: nb,
  [Symbol.iterator]: ab
};
function ht(e) {
  return typeof e == "string" ? new Kt([[document.querySelector(e)]], [document.documentElement]) : new Kt([[e]], nu);
}
function Fo(e, t, r) {
  e.prototype = t.prototype = r, r.constructor = e;
}
function au(e, t) {
  var r = Object.create(e.prototype);
  for (var i in t) r[i] = t[i];
  return r;
}
function Xi() {
}
var Ei = 0.7, Hn = 1 / Ei, Fr = "\\s*([+-]?\\d+)\\s*", Fi = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", Ce = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", ob = /^#([0-9a-f]{3,8})$/, lb = new RegExp(`^rgb\\(${Fr},${Fr},${Fr}\\)$`), cb = new RegExp(`^rgb\\(${Ce},${Ce},${Ce}\\)$`), hb = new RegExp(`^rgba\\(${Fr},${Fr},${Fr},${Fi}\\)$`), ub = new RegExp(`^rgba\\(${Ce},${Ce},${Ce},${Fi}\\)$`), fb = new RegExp(`^hsl\\(${Fi},${Ce},${Ce}\\)$`), db = new RegExp(`^hsla\\(${Fi},${Ce},${Ce},${Fi}\\)$`), ac = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
};
Fo(Xi, Di, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: sc,
  // Deprecated! Use color.formatHex.
  formatHex: sc,
  formatHex8: pb,
  formatHsl: gb,
  formatRgb: oc,
  toString: oc
});
function sc() {
  return this.rgb().formatHex();
}
function pb() {
  return this.rgb().formatHex8();
}
function gb() {
  return su(this).formatHsl();
}
function oc() {
  return this.rgb().formatRgb();
}
function Di(e) {
  var t, r;
  return e = (e + "").trim().toLowerCase(), (t = ob.exec(e)) ? (r = t[1].length, t = parseInt(t[1], 16), r === 6 ? lc(t) : r === 3 ? new Vt(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : r === 8 ? un(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : r === 4 ? un(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = lb.exec(e)) ? new Vt(t[1], t[2], t[3], 1) : (t = cb.exec(e)) ? new Vt(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = hb.exec(e)) ? un(t[1], t[2], t[3], t[4]) : (t = ub.exec(e)) ? un(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = fb.exec(e)) ? uc(t[1], t[2] / 100, t[3] / 100, 1) : (t = db.exec(e)) ? uc(t[1], t[2] / 100, t[3] / 100, t[4]) : ac.hasOwnProperty(e) ? lc(ac[e]) : e === "transparent" ? new Vt(NaN, NaN, NaN, 0) : null;
}
function lc(e) {
  return new Vt(e >> 16 & 255, e >> 8 & 255, e & 255, 1);
}
function un(e, t, r, i) {
  return i <= 0 && (e = t = r = NaN), new Vt(e, t, r, i);
}
function mb(e) {
  return e instanceof Xi || (e = Di(e)), e ? (e = e.rgb(), new Vt(e.r, e.g, e.b, e.opacity)) : new Vt();
}
function Es(e, t, r, i) {
  return arguments.length === 1 ? mb(e) : new Vt(e, t, r, i ?? 1);
}
function Vt(e, t, r, i) {
  this.r = +e, this.g = +t, this.b = +r, this.opacity = +i;
}
Fo(Vt, Es, au(Xi, {
  brighter(e) {
    return e = e == null ? Hn : Math.pow(Hn, e), new Vt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Ei : Math.pow(Ei, e), new Vt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  rgb() {
    return this;
  },
  clamp() {
    return new Vt(lr(this.r), lr(this.g), lr(this.b), jn(this.opacity));
  },
  displayable() {
    return -0.5 <= this.r && this.r < 255.5 && -0.5 <= this.g && this.g < 255.5 && -0.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
  },
  hex: cc,
  // Deprecated! Use color.formatHex.
  formatHex: cc,
  formatHex8: yb,
  formatRgb: hc,
  toString: hc
}));
function cc() {
  return `#${nr(this.r)}${nr(this.g)}${nr(this.b)}`;
}
function yb() {
  return `#${nr(this.r)}${nr(this.g)}${nr(this.b)}${nr((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function hc() {
  const e = jn(this.opacity);
  return `${e === 1 ? "rgb(" : "rgba("}${lr(this.r)}, ${lr(this.g)}, ${lr(this.b)}${e === 1 ? ")" : `, ${e})`}`;
}
function jn(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function lr(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function nr(e) {
  return e = lr(e), (e < 16 ? "0" : "") + e.toString(16);
}
function uc(e, t, r, i) {
  return i <= 0 ? e = t = r = NaN : r <= 0 || r >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new le(e, t, r, i);
}
function su(e) {
  if (e instanceof le) return new le(e.h, e.s, e.l, e.opacity);
  if (e instanceof Xi || (e = Di(e)), !e) return new le();
  if (e instanceof le) return e;
  e = e.rgb();
  var t = e.r / 255, r = e.g / 255, i = e.b / 255, n = Math.min(t, r, i), a = Math.max(t, r, i), s = NaN, o = a - n, l = (a + n) / 2;
  return o ? (t === a ? s = (r - i) / o + (r < i) * 6 : r === a ? s = (i - t) / o + 2 : s = (t - r) / o + 4, o /= l < 0.5 ? a + n : 2 - a - n, s *= 60) : o = l > 0 && l < 1 ? 0 : s, new le(s, o, l, e.opacity);
}
function xb(e, t, r, i) {
  return arguments.length === 1 ? su(e) : new le(e, t, r, i ?? 1);
}
function le(e, t, r, i) {
  this.h = +e, this.s = +t, this.l = +r, this.opacity = +i;
}
Fo(le, xb, au(Xi, {
  brighter(e) {
    return e = e == null ? Hn : Math.pow(Hn, e), new le(this.h, this.s, this.l * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Ei : Math.pow(Ei, e), new le(this.h, this.s, this.l * e, this.opacity);
  },
  rgb() {
    var e = this.h % 360 + (this.h < 0) * 360, t = isNaN(e) || isNaN(this.s) ? 0 : this.s, r = this.l, i = r + (r < 0.5 ? r : 1 - r) * t, n = 2 * r - i;
    return new Vt(
      ls(e >= 240 ? e - 240 : e + 120, n, i),
      ls(e, n, i),
      ls(e < 120 ? e + 240 : e - 120, n, i),
      this.opacity
    );
  },
  clamp() {
    return new le(fc(this.h), fn(this.s), fn(this.l), jn(this.opacity));
  },
  displayable() {
    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
  },
  formatHsl() {
    const e = jn(this.opacity);
    return `${e === 1 ? "hsl(" : "hsla("}${fc(this.h)}, ${fn(this.s) * 100}%, ${fn(this.l) * 100}%${e === 1 ? ")" : `, ${e})`}`;
  }
}));
function fc(e) {
  return e = (e || 0) % 360, e < 0 ? e + 360 : e;
}
function fn(e) {
  return Math.max(0, Math.min(1, e || 0));
}
function ls(e, t, r) {
  return (e < 60 ? t + (r - t) * e / 60 : e < 180 ? r : e < 240 ? t + (r - t) * (240 - e) / 60 : t) * 255;
}
const Do = (e) => () => e;
function ou(e, t) {
  return function(r) {
    return e + r * t;
  };
}
function bb(e, t, r) {
  return e = Math.pow(e, r), t = Math.pow(t, r) - e, r = 1 / r, function(i) {
    return Math.pow(e + i * t, r);
  };
}
function ZA(e, t) {
  var r = t - e;
  return r ? ou(e, r > 180 || r < -180 ? r - 360 * Math.round(r / 360) : r) : Do(isNaN(e) ? t : e);
}
function Cb(e) {
  return (e = +e) == 1 ? lu : function(t, r) {
    return r - t ? bb(t, r, e) : Do(isNaN(t) ? r : t);
  };
}
function lu(e, t) {
  var r = t - e;
  return r ? ou(e, r) : Do(isNaN(e) ? t : e);
}
const dc = (function e(t) {
  var r = Cb(t);
  function i(n, a) {
    var s = r((n = Es(n)).r, (a = Es(a)).r), o = r(n.g, a.g), l = r(n.b, a.b), c = lu(n.opacity, a.opacity);
    return function(h) {
      return n.r = s(h), n.g = o(h), n.b = l(h), n.opacity = c(h), n + "";
    };
  }
  return i.gamma = e, i;
})(1);
function ze(e, t) {
  return e = +e, t = +t, function(r) {
    return e * (1 - r) + t * r;
  };
}
var Fs = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, cs = new RegExp(Fs.source, "g");
function _b(e) {
  return function() {
    return e;
  };
}
function wb(e) {
  return function(t) {
    return e(t) + "";
  };
}
function kb(e, t) {
  var r = Fs.lastIndex = cs.lastIndex = 0, i, n, a, s = -1, o = [], l = [];
  for (e = e + "", t = t + ""; (i = Fs.exec(e)) && (n = cs.exec(t)); )
    (a = n.index) > r && (a = t.slice(r, a), o[s] ? o[s] += a : o[++s] = a), (i = i[0]) === (n = n[0]) ? o[s] ? o[s] += n : o[++s] = n : (o[++s] = null, l.push({ i: s, x: ze(i, n) })), r = cs.lastIndex;
  return r < t.length && (a = t.slice(r), o[s] ? o[s] += a : o[++s] = a), o.length < 2 ? l[0] ? wb(l[0].x) : _b(t) : (t = l.length, function(c) {
    for (var h = 0, u; h < t; ++h) o[(u = l[h]).i] = u.x(c);
    return o.join("");
  });
}
var pc = 180 / Math.PI, Ds = {
  translateX: 0,
  translateY: 0,
  rotate: 0,
  skewX: 0,
  scaleX: 1,
  scaleY: 1
};
function cu(e, t, r, i, n, a) {
  var s, o, l;
  return (s = Math.sqrt(e * e + t * t)) && (e /= s, t /= s), (l = e * r + t * i) && (r -= e * l, i -= t * l), (o = Math.sqrt(r * r + i * i)) && (r /= o, i /= o, l /= o), e * i < t * r && (e = -e, t = -t, l = -l, s = -s), {
    translateX: n,
    translateY: a,
    rotate: Math.atan2(t, e) * pc,
    skewX: Math.atan(l) * pc,
    scaleX: s,
    scaleY: o
  };
}
var dn;
function vb(e) {
  const t = new (typeof DOMMatrix == "function" ? DOMMatrix : WebKitCSSMatrix)(e + "");
  return t.isIdentity ? Ds : cu(t.a, t.b, t.c, t.d, t.e, t.f);
}
function Sb(e) {
  return e == null || (dn || (dn = document.createElementNS("http://www.w3.org/2000/svg", "g")), dn.setAttribute("transform", e), !(e = dn.transform.baseVal.consolidate())) ? Ds : (e = e.matrix, cu(e.a, e.b, e.c, e.d, e.e, e.f));
}
function hu(e, t, r, i) {
  function n(c) {
    return c.length ? c.pop() + " " : "";
  }
  function a(c, h, u, f, d, g) {
    if (c !== u || h !== f) {
      var m = d.push("translate(", null, t, null, r);
      g.push({ i: m - 4, x: ze(c, u) }, { i: m - 2, x: ze(h, f) });
    } else (u || f) && d.push("translate(" + u + t + f + r);
  }
  function s(c, h, u, f) {
    c !== h ? (c - h > 180 ? h += 360 : h - c > 180 && (c += 360), f.push({ i: u.push(n(u) + "rotate(", null, i) - 2, x: ze(c, h) })) : h && u.push(n(u) + "rotate(" + h + i);
  }
  function o(c, h, u, f) {
    c !== h ? f.push({ i: u.push(n(u) + "skewX(", null, i) - 2, x: ze(c, h) }) : h && u.push(n(u) + "skewX(" + h + i);
  }
  function l(c, h, u, f, d, g) {
    if (c !== u || h !== f) {
      var m = d.push(n(d) + "scale(", null, ",", null, ")");
      g.push({ i: m - 4, x: ze(c, u) }, { i: m - 2, x: ze(h, f) });
    } else (u !== 1 || f !== 1) && d.push(n(d) + "scale(" + u + "," + f + ")");
  }
  return function(c, h) {
    var u = [], f = [];
    return c = e(c), h = e(h), a(c.translateX, c.translateY, h.translateX, h.translateY, u, f), s(c.rotate, h.rotate, u, f), o(c.skewX, h.skewX, u, f), l(c.scaleX, c.scaleY, h.scaleX, h.scaleY, u, f), c = h = null, function(d) {
      for (var g = -1, m = f.length, y; ++g < m; ) u[(y = f[g]).i] = y.x(d);
      return u.join("");
    };
  };
}
var Tb = hu(vb, "px, ", "px)", "deg)"), Bb = hu(Sb, ", ", ")", ")"), Gr = 0, xi = 0, ui = 0, uu = 1e3, Yn, bi, Un = 0, fr = 0, va = 0, Oi = typeof performance == "object" && performance.now ? performance : Date, fu = typeof window == "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(e) {
  setTimeout(e, 17);
};
function Oo() {
  return fr || (fu(Ab), fr = Oi.now() + va);
}
function Ab() {
  fr = 0;
}
function Gn() {
  this._call = this._time = this._next = null;
}
Gn.prototype = du.prototype = {
  constructor: Gn,
  restart: function(e, t, r) {
    if (typeof e != "function") throw new TypeError("callback is not a function");
    r = (r == null ? Oo() : +r) + (t == null ? 0 : +t), !this._next && bi !== this && (bi ? bi._next = this : Yn = this, bi = this), this._call = e, this._time = r, Os();
  },
  stop: function() {
    this._call && (this._call = null, this._time = 1 / 0, Os());
  }
};
function du(e, t, r) {
  var i = new Gn();
  return i.restart(e, t, r), i;
}
function Lb() {
  Oo(), ++Gr;
  for (var e = Yn, t; e; )
    (t = fr - e._time) >= 0 && e._call.call(void 0, t), e = e._next;
  --Gr;
}
function gc() {
  fr = (Un = Oi.now()) + va, Gr = xi = 0;
  try {
    Lb();
  } finally {
    Gr = 0, $b(), fr = 0;
  }
}
function Mb() {
  var e = Oi.now(), t = e - Un;
  t > uu && (va -= t, Un = e);
}
function $b() {
  for (var e, t = Yn, r, i = 1 / 0; t; )
    t._call ? (i > t._time && (i = t._time), e = t, t = t._next) : (r = t._next, t._next = null, t = e ? e._next = r : Yn = r);
  bi = e, Os(i);
}
function Os(e) {
  if (!Gr) {
    xi && (xi = clearTimeout(xi));
    var t = e - fr;
    t > 24 ? (e < 1 / 0 && (xi = setTimeout(gc, e - Oi.now() - va)), ui && (ui = clearInterval(ui))) : (ui || (Un = Oi.now(), ui = setInterval(Mb, uu)), Gr = 1, fu(gc));
  }
}
function mc(e, t, r) {
  var i = new Gn();
  return t = t == null ? 0 : +t, i.restart((n) => {
    i.stop(), e(n + t);
  }, t, r), i;
}
var Eb = Uh("start", "end", "cancel", "interrupt"), Fb = [], pu = 0, yc = 1, Rs = 2, Bn = 3, xc = 4, Is = 5, An = 6;
function Sa(e, t, r, i, n, a) {
  var s = e.__transition;
  if (!s) e.__transition = {};
  else if (r in s) return;
  Db(e, r, {
    name: t,
    index: i,
    // For context during callback.
    group: n,
    // For context during callback.
    on: Eb,
    tween: Fb,
    time: a.time,
    delay: a.delay,
    duration: a.duration,
    ease: a.ease,
    timer: null,
    state: pu
  });
}
function Ro(e, t) {
  var r = fe(e, t);
  if (r.state > pu) throw new Error("too late; already scheduled");
  return r;
}
function ke(e, t) {
  var r = fe(e, t);
  if (r.state > Bn) throw new Error("too late; already running");
  return r;
}
function fe(e, t) {
  var r = e.__transition;
  if (!r || !(r = r[t])) throw new Error("transition not found");
  return r;
}
function Db(e, t, r) {
  var i = e.__transition, n;
  i[t] = r, r.timer = du(a, 0, r.time);
  function a(c) {
    r.state = yc, r.timer.restart(s, r.delay, r.time), r.delay <= c && s(c - r.delay);
  }
  function s(c) {
    var h, u, f, d;
    if (r.state !== yc) return l();
    for (h in i)
      if (d = i[h], d.name === r.name) {
        if (d.state === Bn) return mc(s);
        d.state === xc ? (d.state = An, d.timer.stop(), d.on.call("interrupt", e, e.__data__, d.index, d.group), delete i[h]) : +h < t && (d.state = An, d.timer.stop(), d.on.call("cancel", e, e.__data__, d.index, d.group), delete i[h]);
      }
    if (mc(function() {
      r.state === Bn && (r.state = xc, r.timer.restart(o, r.delay, r.time), o(c));
    }), r.state = Rs, r.on.call("start", e, e.__data__, r.index, r.group), r.state === Rs) {
      for (r.state = Bn, n = new Array(f = r.tween.length), h = 0, u = -1; h < f; ++h)
        (d = r.tween[h].value.call(e, e.__data__, r.index, r.group)) && (n[++u] = d);
      n.length = u + 1;
    }
  }
  function o(c) {
    for (var h = c < r.duration ? r.ease.call(null, c / r.duration) : (r.timer.restart(l), r.state = Is, 1), u = -1, f = n.length; ++u < f; )
      n[u].call(e, h);
    r.state === Is && (r.on.call("end", e, e.__data__, r.index, r.group), l());
  }
  function l() {
    r.state = An, r.timer.stop(), delete i[t];
    for (var c in i) return;
    delete e.__transition;
  }
}
function Ob(e, t) {
  var r = e.__transition, i, n, a = !0, s;
  if (r) {
    t = t == null ? null : t + "";
    for (s in r) {
      if ((i = r[s]).name !== t) {
        a = !1;
        continue;
      }
      n = i.state > Rs && i.state < Is, i.state = An, i.timer.stop(), i.on.call(n ? "interrupt" : "cancel", e, e.__data__, i.index, i.group), delete r[s];
    }
    a && delete e.__transition;
  }
}
function Rb(e) {
  return this.each(function() {
    Ob(this, e);
  });
}
function Ib(e, t) {
  var r, i;
  return function() {
    var n = ke(this, e), a = n.tween;
    if (a !== r) {
      i = r = a;
      for (var s = 0, o = i.length; s < o; ++s)
        if (i[s].name === t) {
          i = i.slice(), i.splice(s, 1);
          break;
        }
    }
    n.tween = i;
  };
}
function Pb(e, t, r) {
  var i, n;
  if (typeof r != "function") throw new Error();
  return function() {
    var a = ke(this, e), s = a.tween;
    if (s !== i) {
      n = (i = s).slice();
      for (var o = { name: t, value: r }, l = 0, c = n.length; l < c; ++l)
        if (n[l].name === t) {
          n[l] = o;
          break;
        }
      l === c && n.push(o);
    }
    a.tween = n;
  };
}
function Nb(e, t) {
  var r = this._id;
  if (e += "", arguments.length < 2) {
    for (var i = fe(this.node(), r).tween, n = 0, a = i.length, s; n < a; ++n)
      if ((s = i[n]).name === e)
        return s.value;
    return null;
  }
  return this.each((t == null ? Ib : Pb)(r, e, t));
}
function Io(e, t, r) {
  var i = e._id;
  return e.each(function() {
    var n = ke(this, i);
    (n.value || (n.value = {}))[t] = r.apply(this, arguments);
  }), function(n) {
    return fe(n, i).value[t];
  };
}
function gu(e, t) {
  var r;
  return (typeof t == "number" ? ze : t instanceof Di ? dc : (r = Di(t)) ? (t = r, dc) : kb)(e, t);
}
function zb(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function Wb(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function qb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var s = this.getAttribute(e);
    return s === n ? null : s === i ? a : a = t(i = s, r);
  };
}
function Hb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var s = this.getAttributeNS(e.space, e.local);
    return s === n ? null : s === i ? a : a = t(i = s, r);
  };
}
function jb(e, t, r) {
  var i, n, a;
  return function() {
    var s, o = r(this), l;
    return o == null ? void this.removeAttribute(e) : (s = this.getAttribute(e), l = o + "", s === l ? null : s === i && l === n ? a : (n = l, a = t(i = s, o)));
  };
}
function Yb(e, t, r) {
  var i, n, a;
  return function() {
    var s, o = r(this), l;
    return o == null ? void this.removeAttributeNS(e.space, e.local) : (s = this.getAttributeNS(e.space, e.local), l = o + "", s === l ? null : s === i && l === n ? a : (n = l, a = t(i = s, o)));
  };
}
function Ub(e, t) {
  var r = ka(e), i = r === "transform" ? Bb : gu;
  return this.attrTween(e, typeof t == "function" ? (r.local ? Yb : jb)(r, i, Io(this, "attr." + e, t)) : t == null ? (r.local ? Wb : zb)(r) : (r.local ? Hb : qb)(r, i, t));
}
function Gb(e, t) {
  return function(r) {
    this.setAttribute(e, t.call(this, r));
  };
}
function Xb(e, t) {
  return function(r) {
    this.setAttributeNS(e.space, e.local, t.call(this, r));
  };
}
function Vb(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Xb(e, a)), r;
  }
  return n._value = t, n;
}
function Zb(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Gb(e, a)), r;
  }
  return n._value = t, n;
}
function Kb(e, t) {
  var r = "attr." + e;
  if (arguments.length < 2) return (r = this.tween(r)) && r._value;
  if (t == null) return this.tween(r, null);
  if (typeof t != "function") throw new Error();
  var i = ka(e);
  return this.tween(r, (i.local ? Vb : Zb)(i, t));
}
function Qb(e, t) {
  return function() {
    Ro(this, e).delay = +t.apply(this, arguments);
  };
}
function Jb(e, t) {
  return t = +t, function() {
    Ro(this, e).delay = t;
  };
}
function t1(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? Qb : Jb)(t, e)) : fe(this.node(), t).delay;
}
function e1(e, t) {
  return function() {
    ke(this, e).duration = +t.apply(this, arguments);
  };
}
function r1(e, t) {
  return t = +t, function() {
    ke(this, e).duration = t;
  };
}
function i1(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? e1 : r1)(t, e)) : fe(this.node(), t).duration;
}
function n1(e, t) {
  if (typeof t != "function") throw new Error();
  return function() {
    ke(this, e).ease = t;
  };
}
function a1(e) {
  var t = this._id;
  return arguments.length ? this.each(n1(t, e)) : fe(this.node(), t).ease;
}
function s1(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    if (typeof r != "function") throw new Error();
    ke(this, e).ease = r;
  };
}
function o1(e) {
  if (typeof e != "function") throw new Error();
  return this.each(s1(this._id, e));
}
function l1(e) {
  typeof e != "function" && (e = Vh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], s = a.length, o = i[n] = [], l, c = 0; c < s; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && o.push(l);
  return new De(i, this._parents, this._name, this._id);
}
function c1(e) {
  if (e._id !== this._id) throw new Error();
  for (var t = this._groups, r = e._groups, i = t.length, n = r.length, a = Math.min(i, n), s = new Array(i), o = 0; o < a; ++o)
    for (var l = t[o], c = r[o], h = l.length, u = s[o] = new Array(h), f, d = 0; d < h; ++d)
      (f = l[d] || c[d]) && (u[d] = f);
  for (; o < i; ++o)
    s[o] = t[o];
  return new De(s, this._parents, this._name, this._id);
}
function h1(e) {
  return (e + "").trim().split(/^|\s+/).every(function(t) {
    var r = t.indexOf(".");
    return r >= 0 && (t = t.slice(0, r)), !t || t === "start";
  });
}
function u1(e, t, r) {
  var i, n, a = h1(t) ? Ro : ke;
  return function() {
    var s = a(this, e), o = s.on;
    o !== i && (n = (i = o).copy()).on(t, r), s.on = n;
  };
}
function f1(e, t) {
  var r = this._id;
  return arguments.length < 2 ? fe(this.node(), r).on.on(e) : this.each(u1(r, e, t));
}
function d1(e) {
  return function() {
    var t = this.parentNode;
    for (var r in this.__transition) if (+r !== e) return;
    t && t.removeChild(this);
  };
}
function p1() {
  return this.on("end.remove", d1(this._id));
}
function g1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = $o(e));
  for (var i = this._groups, n = i.length, a = new Array(n), s = 0; s < n; ++s)
    for (var o = i[s], l = o.length, c = a[s] = new Array(l), h, u, f = 0; f < l; ++f)
      (h = o[f]) && (u = e.call(h, h.__data__, f, o)) && ("__data__" in h && (u.__data__ = h.__data__), c[f] = u, Sa(c[f], t, r, f, c, fe(h, r)));
  return new De(a, this._parents, t, r);
}
function m1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = Xh(e));
  for (var i = this._groups, n = i.length, a = [], s = [], o = 0; o < n; ++o)
    for (var l = i[o], c = l.length, h, u = 0; u < c; ++u)
      if (h = l[u]) {
        for (var f = e.call(h, h.__data__, u, l), d, g = fe(h, r), m = 0, y = f.length; m < y; ++m)
          (d = f[m]) && Sa(d, t, r, m, f, g);
        a.push(f), s.push(h);
      }
  return new De(a, s, t, r);
}
var y1 = Gi.prototype.constructor;
function x1() {
  return new y1(this._groups, this._parents);
}
function b1(e, t) {
  var r, i, n;
  return function() {
    var a = Ur(this, e), s = (this.style.removeProperty(e), Ur(this, e));
    return a === s ? null : a === r && s === i ? n : n = t(r = a, i = s);
  };
}
function mu(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function C1(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var s = Ur(this, e);
    return s === n ? null : s === i ? a : a = t(i = s, r);
  };
}
function _1(e, t, r) {
  var i, n, a;
  return function() {
    var s = Ur(this, e), o = r(this), l = o + "";
    return o == null && (l = o = (this.style.removeProperty(e), Ur(this, e))), s === l ? null : s === i && l === n ? a : (n = l, a = t(i = s, o));
  };
}
function w1(e, t) {
  var r, i, n, a = "style." + t, s = "end." + a, o;
  return function() {
    var l = ke(this, e), c = l.on, h = l.value[a] == null ? o || (o = mu(t)) : void 0;
    (c !== r || n !== h) && (i = (r = c).copy()).on(s, n = h), l.on = i;
  };
}
function k1(e, t, r) {
  var i = (e += "") == "transform" ? Tb : gu;
  return t == null ? this.styleTween(e, b1(e, i)).on("end.style." + e, mu(e)) : typeof t == "function" ? this.styleTween(e, _1(e, i, Io(this, "style." + e, t))).each(w1(this._id, e)) : this.styleTween(e, C1(e, i, t), r).on("end.style." + e, null);
}
function v1(e, t, r) {
  return function(i) {
    this.style.setProperty(e, t.call(this, i), r);
  };
}
function S1(e, t, r) {
  var i, n;
  function a() {
    var s = t.apply(this, arguments);
    return s !== n && (i = (n = s) && v1(e, s, r)), i;
  }
  return a._value = t, a;
}
function T1(e, t, r) {
  var i = "style." + (e += "");
  if (arguments.length < 2) return (i = this.tween(i)) && i._value;
  if (t == null) return this.tween(i, null);
  if (typeof t != "function") throw new Error();
  return this.tween(i, S1(e, t, r ?? ""));
}
function B1(e) {
  return function() {
    this.textContent = e;
  };
}
function A1(e) {
  return function() {
    var t = e(this);
    this.textContent = t ?? "";
  };
}
function L1(e) {
  return this.tween("text", typeof e == "function" ? A1(Io(this, "text", e)) : B1(e == null ? "" : e + ""));
}
function M1(e) {
  return function(t) {
    this.textContent = e.call(this, t);
  };
}
function $1(e) {
  var t, r;
  function i() {
    var n = e.apply(this, arguments);
    return n !== r && (t = (r = n) && M1(n)), t;
  }
  return i._value = e, i;
}
function E1(e) {
  var t = "text";
  if (arguments.length < 1) return (t = this.tween(t)) && t._value;
  if (e == null) return this.tween(t, null);
  if (typeof e != "function") throw new Error();
  return this.tween(t, $1(e));
}
function F1() {
  for (var e = this._name, t = this._id, r = yu(), i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var s = i[a], o = s.length, l, c = 0; c < o; ++c)
      if (l = s[c]) {
        var h = fe(l, t);
        Sa(l, e, r, c, s, {
          time: h.time + h.delay + h.duration,
          delay: 0,
          duration: h.duration,
          ease: h.ease
        });
      }
  return new De(i, this._parents, e, r);
}
function D1() {
  var e, t, r = this, i = r._id, n = r.size();
  return new Promise(function(a, s) {
    var o = { value: s }, l = { value: function() {
      --n === 0 && a();
    } };
    r.each(function() {
      var c = ke(this, i), h = c.on;
      h !== e && (t = (e = h).copy(), t._.cancel.push(o), t._.interrupt.push(o), t._.end.push(l)), c.on = t;
    }), n === 0 && a();
  });
}
var O1 = 0;
function De(e, t, r, i) {
  this._groups = e, this._parents = t, this._name = r, this._id = i;
}
function yu() {
  return ++O1;
}
var Le = Gi.prototype;
De.prototype = {
  constructor: De,
  select: g1,
  selectAll: m1,
  selectChild: Le.selectChild,
  selectChildren: Le.selectChildren,
  filter: l1,
  merge: c1,
  selection: x1,
  transition: F1,
  call: Le.call,
  nodes: Le.nodes,
  node: Le.node,
  size: Le.size,
  empty: Le.empty,
  each: Le.each,
  on: f1,
  attr: Ub,
  attrTween: Kb,
  style: k1,
  styleTween: T1,
  text: L1,
  textTween: E1,
  remove: p1,
  tween: Nb,
  delay: t1,
  duration: i1,
  ease: a1,
  easeVarying: o1,
  end: D1,
  [Symbol.iterator]: Le[Symbol.iterator]
};
function R1(e) {
  return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2;
}
var I1 = {
  time: null,
  // Set on use.
  delay: 0,
  duration: 250,
  ease: R1
};
function P1(e, t) {
  for (var r; !(r = e.__transition) || !(r = r[t]); )
    if (!(e = e.parentNode))
      throw new Error(`transition ${t} not found`);
  return r;
}
function N1(e) {
  var t, r;
  e instanceof De ? (t = e._id, e = e._name) : (t = yu(), (r = I1).time = Oo(), e = e == null ? null : e + "");
  for (var i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var s = i[a], o = s.length, l, c = 0; c < o; ++c)
      (l = s[c]) && Sa(l, e, t, c, s, r || P1(l, t));
  return new De(i, this._parents, e, t);
}
Gi.prototype.interrupt = Rb;
Gi.prototype.transition = N1;
const Ps = Math.PI, Ns = 2 * Ps, tr = 1e-6, z1 = Ns - tr;
function xu(e) {
  this._ += e[0];
  for (let t = 1, r = e.length; t < r; ++t)
    this._ += arguments[t] + e[t];
}
function W1(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw new Error(`invalid digits: ${e}`);
  if (t > 15) return xu;
  const r = 10 ** t;
  return function(i) {
    this._ += i[0];
    for (let n = 1, a = i.length; n < a; ++n)
      this._ += Math.round(arguments[n] * r) / r + i[n];
  };
}
class q1 {
  constructor(t) {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null, this._ = "", this._append = t == null ? xu : W1(t);
  }
  moveTo(t, r) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}`;
  }
  closePath() {
    this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append`Z`);
  }
  lineTo(t, r) {
    this._append`L${this._x1 = +t},${this._y1 = +r}`;
  }
  quadraticCurveTo(t, r, i, n) {
    this._append`Q${+t},${+r},${this._x1 = +i},${this._y1 = +n}`;
  }
  bezierCurveTo(t, r, i, n, a, s) {
    this._append`C${+t},${+r},${+i},${+n},${this._x1 = +a},${this._y1 = +s}`;
  }
  arcTo(t, r, i, n, a) {
    if (t = +t, r = +r, i = +i, n = +n, a = +a, a < 0) throw new Error(`negative radius: ${a}`);
    let s = this._x1, o = this._y1, l = i - t, c = n - r, h = s - t, u = o - r, f = h * h + u * u;
    if (this._x1 === null)
      this._append`M${this._x1 = t},${this._y1 = r}`;
    else if (f > tr) if (!(Math.abs(u * l - c * h) > tr) || !a)
      this._append`L${this._x1 = t},${this._y1 = r}`;
    else {
      let d = i - s, g = n - o, m = l * l + c * c, y = d * d + g * g, x = Math.sqrt(m), b = Math.sqrt(f), C = a * Math.tan((Ps - Math.acos((m + f - y) / (2 * x * b))) / 2), k = C / b, w = C / x;
      Math.abs(k - 1) > tr && this._append`L${t + k * h},${r + k * u}`, this._append`A${a},${a},0,0,${+(u * d > h * g)},${this._x1 = t + w * l},${this._y1 = r + w * c}`;
    }
  }
  arc(t, r, i, n, a, s) {
    if (t = +t, r = +r, i = +i, s = !!s, i < 0) throw new Error(`negative radius: ${i}`);
    let o = i * Math.cos(n), l = i * Math.sin(n), c = t + o, h = r + l, u = 1 ^ s, f = s ? n - a : a - n;
    this._x1 === null ? this._append`M${c},${h}` : (Math.abs(this._x1 - c) > tr || Math.abs(this._y1 - h) > tr) && this._append`L${c},${h}`, i && (f < 0 && (f = f % Ns + Ns), f > z1 ? this._append`A${i},${i},0,1,${u},${t - o},${r - l}A${i},${i},0,1,${u},${this._x1 = c},${this._y1 = h}` : f > tr && this._append`A${i},${i},0,${+(f >= Ps)},${u},${this._x1 = t + i * Math.cos(a)},${this._y1 = r + i * Math.sin(a)}`);
  }
  rect(t, r, i, n) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}h${i = +i}v${+n}h${-i}Z`;
  }
  toString() {
    return this._;
  }
}
function Br(e) {
  return function() {
    return e;
  };
}
const KA = Math.abs, QA = Math.atan2, JA = Math.cos, tL = Math.max, eL = Math.min, rL = Math.sin, iL = Math.sqrt, bc = 1e-12, Po = Math.PI, Cc = Po / 2, nL = 2 * Po;
function aL(e) {
  return e > 1 ? 0 : e < -1 ? Po : Math.acos(e);
}
function sL(e) {
  return e >= 1 ? Cc : e <= -1 ? -Cc : Math.asin(e);
}
function H1(e) {
  let t = 3;
  return e.digits = function(r) {
    if (!arguments.length) return t;
    if (r == null)
      t = null;
    else {
      const i = Math.floor(r);
      if (!(i >= 0)) throw new RangeError(`invalid digits: ${r}`);
      t = i;
    }
    return e;
  }, () => new q1(t);
}
function j1(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function bu(e) {
  this._context = e;
}
bu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      // falls through
      default:
        this._context.lineTo(e, t);
        break;
    }
  }
};
function Xn(e) {
  return new bu(e);
}
function Y1(e) {
  return e[0];
}
function U1(e) {
  return e[1];
}
function G1(e, t) {
  var r = Br(!0), i = null, n = Xn, a = null, s = H1(o);
  e = typeof e == "function" ? e : e === void 0 ? Y1 : Br(e), t = typeof t == "function" ? t : t === void 0 ? U1 : Br(t);
  function o(l) {
    var c, h = (l = j1(l)).length, u, f = !1, d;
    for (i == null && (a = n(d = s())), c = 0; c <= h; ++c)
      !(c < h && r(u = l[c], c, l)) === f && ((f = !f) ? a.lineStart() : a.lineEnd()), f && a.point(+e(u, c, l), +t(u, c, l));
    if (d) return a = null, d + "" || null;
  }
  return o.x = function(l) {
    return arguments.length ? (e = typeof l == "function" ? l : Br(+l), o) : e;
  }, o.y = function(l) {
    return arguments.length ? (t = typeof l == "function" ? l : Br(+l), o) : t;
  }, o.defined = function(l) {
    return arguments.length ? (r = typeof l == "function" ? l : Br(!!l), o) : r;
  }, o.curve = function(l) {
    return arguments.length ? (n = l, i != null && (a = n(i)), o) : n;
  }, o.context = function(l) {
    return arguments.length ? (l == null ? i = a = null : a = n(i = l), o) : i;
  }, o;
}
class Cu {
  constructor(t, r) {
    this._context = t, this._x = r;
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  }
  point(t, r) {
    switch (t = +t, r = +r, this._point) {
      case 0: {
        this._point = 1, this._line ? this._context.lineTo(t, r) : this._context.moveTo(t, r);
        break;
      }
      case 1:
        this._point = 2;
      // falls through
      default: {
        this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + t) / 2, this._y0, this._x0, r, t, r) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + r) / 2, t, this._y0, t, r);
        break;
      }
    }
    this._x0 = t, this._y0 = r;
  }
}
function _u(e) {
  return new Cu(e, !0);
}
function wu(e) {
  return new Cu(e, !1);
}
function He() {
}
function Vn(e, t, r) {
  e._context.bezierCurveTo(
    (2 * e._x0 + e._x1) / 3,
    (2 * e._y0 + e._y1) / 3,
    (e._x0 + 2 * e._x1) / 3,
    (e._y0 + 2 * e._y1) / 3,
    (e._x0 + 4 * e._x1 + t) / 6,
    (e._y0 + 4 * e._y1 + r) / 6
  );
}
function Ta(e) {
  this._context = e;
}
Ta.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 3:
        Vn(this, this._x1, this._y1);
      // falls through
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
      // falls through
      default:
        Vn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Ln(e) {
  return new Ta(e);
}
function ku(e) {
  this._context = e;
}
ku.prototype = {
  areaStart: He,
  areaEnd: He,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x2, this._y2), this._context.closePath();
        break;
      }
      case 2: {
        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x2 = e, this._y2 = t;
        break;
      case 1:
        this._point = 2, this._x3 = e, this._y3 = t;
        break;
      case 2:
        this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
        break;
      default:
        Vn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function X1(e) {
  return new ku(e);
}
function vu(e) {
  this._context = e;
}
vu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        var r = (this._x0 + 4 * this._x1 + e) / 6, i = (this._y0 + 4 * this._y1 + t) / 6;
        this._line ? this._context.lineTo(r, i) : this._context.moveTo(r, i);
        break;
      case 3:
        this._point = 4;
      // falls through
      default:
        Vn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function V1(e) {
  return new vu(e);
}
function Su(e, t) {
  this._basis = new Ta(e), this._beta = t;
}
Su.prototype = {
  lineStart: function() {
    this._x = [], this._y = [], this._basis.lineStart();
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length - 1;
    if (r > 0)
      for (var i = e[0], n = t[0], a = e[r] - i, s = t[r] - n, o = -1, l; ++o <= r; )
        l = o / r, this._basis.point(
          this._beta * e[o] + (1 - this._beta) * (i + l * a),
          this._beta * t[o] + (1 - this._beta) * (n + l * s)
        );
    this._x = this._y = null, this._basis.lineEnd();
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
const Z1 = (function e(t) {
  function r(i) {
    return t === 1 ? new Ta(i) : new Su(i, t);
  }
  return r.beta = function(i) {
    return e(+i);
  }, r;
})(0.85);
function Zn(e, t, r) {
  e._context.bezierCurveTo(
    e._x1 + e._k * (e._x2 - e._x0),
    e._y1 + e._k * (e._y2 - e._y0),
    e._x2 + e._k * (e._x1 - t),
    e._y2 + e._k * (e._y1 - r),
    e._x2,
    e._y2
  );
}
function No(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
No.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        Zn(this, this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2, this._x1 = e, this._y1 = t;
        break;
      case 2:
        this._point = 3;
      // falls through
      default:
        Zn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Tu = (function e(t) {
  function r(i) {
    return new No(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
})(0);
function zo(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
zo.prototype = {
  areaStart: He,
  areaEnd: He,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        Zn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const K1 = (function e(t) {
  function r(i) {
    return new zo(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
})(0);
function Wo(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Wo.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      // falls through
      default:
        Zn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Q1 = (function e(t) {
  function r(i) {
    return new Wo(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
})(0);
function qo(e, t, r) {
  var i = e._x1, n = e._y1, a = e._x2, s = e._y2;
  if (e._l01_a > bc) {
    var o = 2 * e._l01_2a + 3 * e._l01_a * e._l12_a + e._l12_2a, l = 3 * e._l01_a * (e._l01_a + e._l12_a);
    i = (i * o - e._x0 * e._l12_2a + e._x2 * e._l01_2a) / l, n = (n * o - e._y0 * e._l12_2a + e._y2 * e._l01_2a) / l;
  }
  if (e._l23_a > bc) {
    var c = 2 * e._l23_2a + 3 * e._l23_a * e._l12_a + e._l12_2a, h = 3 * e._l23_a * (e._l23_a + e._l12_a);
    a = (a * c + e._x1 * e._l23_2a - t * e._l12_2a) / h, s = (s * c + e._y1 * e._l23_2a - r * e._l12_2a) / h;
  }
  e._context.bezierCurveTo(i, n, a, s, e._x2, e._y2);
}
function Bu(e, t) {
  this._context = e, this._alpha = t;
}
Bu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        this.point(this._x2, this._y2);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
      // falls through
      default:
        qo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Au = (function e(t) {
  function r(i) {
    return t ? new Bu(i, t) : new No(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
})(0.5);
function Lu(e, t) {
  this._context = e, this._alpha = t;
}
Lu.prototype = {
  areaStart: He,
  areaEnd: He,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        qo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const J1 = (function e(t) {
  function r(i) {
    return t ? new Lu(i, t) : new zo(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
})(0.5);
function Mu(e, t) {
  this._context = e, this._alpha = t;
}
Mu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      // falls through
      default:
        qo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const t2 = (function e(t) {
  function r(i) {
    return t ? new Mu(i, t) : new Wo(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
})(0.5);
function $u(e) {
  this._context = e;
}
$u.prototype = {
  areaStart: He,
  areaEnd: He,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    this._point && this._context.closePath();
  },
  point: function(e, t) {
    e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t));
  }
};
function e2(e) {
  return new $u(e);
}
function _c(e) {
  return e < 0 ? -1 : 1;
}
function wc(e, t, r) {
  var i = e._x1 - e._x0, n = t - e._x1, a = (e._y1 - e._y0) / (i || n < 0 && -0), s = (r - e._y1) / (n || i < 0 && -0), o = (a * n + s * i) / (i + n);
  return (_c(a) + _c(s)) * Math.min(Math.abs(a), Math.abs(s), 0.5 * Math.abs(o)) || 0;
}
function kc(e, t) {
  var r = e._x1 - e._x0;
  return r ? (3 * (e._y1 - e._y0) / r - t) / 2 : t;
}
function hs(e, t, r) {
  var i = e._x0, n = e._y0, a = e._x1, s = e._y1, o = (a - i) / 3;
  e._context.bezierCurveTo(i + o, n + o * t, a - o, s - o * r, a, s);
}
function Kn(e) {
  this._context = e;
}
Kn.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        hs(this, this._t0, kc(this, this._t0));
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    var r = NaN;
    if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
      switch (this._point) {
        case 0:
          this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
          break;
        case 1:
          this._point = 2;
          break;
        case 2:
          this._point = 3, hs(this, kc(this, r = wc(this, e, t)), r);
          break;
        default:
          hs(this, this._t0, r = wc(this, e, t));
          break;
      }
      this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = r;
    }
  }
};
function Eu(e) {
  this._context = new Fu(e);
}
(Eu.prototype = Object.create(Kn.prototype)).point = function(e, t) {
  Kn.prototype.point.call(this, t, e);
};
function Fu(e) {
  this._context = e;
}
Fu.prototype = {
  moveTo: function(e, t) {
    this._context.moveTo(t, e);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(e, t) {
    this._context.lineTo(t, e);
  },
  bezierCurveTo: function(e, t, r, i, n, a) {
    this._context.bezierCurveTo(t, e, i, r, a, n);
  }
};
function Du(e) {
  return new Kn(e);
}
function Ou(e) {
  return new Eu(e);
}
function Ru(e) {
  this._context = e;
}
Ru.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = [], this._y = [];
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length;
    if (r)
      if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), r === 2)
        this._context.lineTo(e[1], t[1]);
      else
        for (var i = vc(e), n = vc(t), a = 0, s = 1; s < r; ++a, ++s)
          this._context.bezierCurveTo(i[0][a], n[0][a], i[1][a], n[1][a], e[s], t[s]);
    (this._line || this._line !== 0 && r === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null;
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
function vc(e) {
  var t, r = e.length - 1, i, n = new Array(r), a = new Array(r), s = new Array(r);
  for (n[0] = 0, a[0] = 2, s[0] = e[0] + 2 * e[1], t = 1; t < r - 1; ++t) n[t] = 1, a[t] = 4, s[t] = 4 * e[t] + 2 * e[t + 1];
  for (n[r - 1] = 2, a[r - 1] = 7, s[r - 1] = 8 * e[r - 1] + e[r], t = 1; t < r; ++t) i = n[t] / a[t - 1], a[t] -= i, s[t] -= i * s[t - 1];
  for (n[r - 1] = s[r - 1] / a[r - 1], t = r - 2; t >= 0; --t) n[t] = (s[t] - n[t + 1]) / a[t];
  for (a[r - 1] = (e[r] + n[r - 1]) / 2, t = 0; t < r - 1; ++t) a[t] = 2 * e[t + 1] - n[t + 1];
  return [n, a];
}
function Iu(e) {
  return new Ru(e);
}
function Ba(e, t) {
  this._context = e, this._t = t;
}
Ba.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = this._y = NaN, this._point = 0;
  },
  lineEnd: function() {
    0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line);
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      // falls through
      default: {
        if (this._t <= 0)
          this._context.lineTo(this._x, t), this._context.lineTo(e, t);
        else {
          var r = this._x * (1 - this._t) + e * this._t;
          this._context.lineTo(r, this._y), this._context.lineTo(r, t);
        }
        break;
      }
    }
    this._x = e, this._y = t;
  }
};
function Pu(e) {
  return new Ba(e, 0.5);
}
function Nu(e) {
  return new Ba(e, 0);
}
function zu(e) {
  return new Ba(e, 1);
}
function Ci(e, t, r) {
  this.k = e, this.x = t, this.y = r;
}
Ci.prototype = {
  constructor: Ci,
  scale: function(e) {
    return e === 1 ? this : new Ci(this.k * e, this.x, this.y);
  },
  translate: function(e, t) {
    return e === 0 & t === 0 ? this : new Ci(this.k, this.x + this.k * e, this.y + this.k * t);
  },
  apply: function(e) {
    return [e[0] * this.k + this.x, e[1] * this.k + this.y];
  },
  applyX: function(e) {
    return e * this.k + this.x;
  },
  applyY: function(e) {
    return e * this.k + this.y;
  },
  invert: function(e) {
    return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k];
  },
  invertX: function(e) {
    return (e - this.x) / this.k;
  },
  invertY: function(e) {
    return (e - this.y) / this.k;
  },
  rescaleX: function(e) {
    return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e));
  },
  rescaleY: function(e) {
    return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e));
  },
  toString: function() {
    return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")";
  }
};
Ci.prototype;
var r2 = /* @__PURE__ */ p((e) => {
  const { securityLevel: t } = ft();
  let r = ht("body");
  if (t === "sandbox") {
    const a = ht(`#i${e}`).node()?.contentDocument ?? document;
    r = ht(a.body);
  }
  return r.select(`#${e}`);
}, "selectSvgElement");
function Ho(e) {
  return typeof e > "u" || e === null;
}
p(Ho, "isNothing");
function Wu(e) {
  return typeof e == "object" && e !== null;
}
p(Wu, "isObject");
function qu(e) {
  return Array.isArray(e) ? e : Ho(e) ? [] : [e];
}
p(qu, "toArray");
function Hu(e, t) {
  var r, i, n, a;
  if (t)
    for (a = Object.keys(t), r = 0, i = a.length; r < i; r += 1)
      n = a[r], e[n] = t[n];
  return e;
}
p(Hu, "extend");
function ju(e, t) {
  var r = "", i;
  for (i = 0; i < t; i += 1)
    r += e;
  return r;
}
p(ju, "repeat");
function Yu(e) {
  return e === 0 && Number.NEGATIVE_INFINITY === 1 / e;
}
p(Yu, "isNegativeZero");
var i2 = Ho, n2 = Wu, a2 = qu, s2 = ju, o2 = Yu, l2 = Hu, Tt = {
  isNothing: i2,
  isObject: n2,
  toArray: a2,
  repeat: s2,
  isNegativeZero: o2,
  extend: l2
};
function jo(e, t) {
  var r = "", i = e.reason || "(unknown reason)";
  return e.mark ? (e.mark.name && (r += 'in "' + e.mark.name + '" '), r += "(" + (e.mark.line + 1) + ":" + (e.mark.column + 1) + ")", !t && e.mark.snippet && (r += `

` + e.mark.snippet), i + " " + r) : i;
}
p(jo, "formatError");
function Xr(e, t) {
  Error.call(this), this.name = "YAMLException", this.reason = e, this.mark = t, this.message = jo(this, !1), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack || "";
}
p(Xr, "YAMLException$1");
Xr.prototype = Object.create(Error.prototype);
Xr.prototype.constructor = Xr;
Xr.prototype.toString = /* @__PURE__ */ p(function(t) {
  return this.name + ": " + jo(this, t);
}, "toString");
var Xt = Xr;
function Mn(e, t, r, i, n) {
  var a = "", s = "", o = Math.floor(n / 2) - 1;
  return i - t > o && (a = " ... ", t = i - o + a.length), r - i > o && (s = " ...", r = i + o - s.length), {
    str: a + e.slice(t, r).replace(/\t/g, "→") + s,
    pos: i - t + a.length
    // relative position
  };
}
p(Mn, "getLine");
function $n(e, t) {
  return Tt.repeat(" ", t - e.length) + e;
}
p($n, "padStart");
function Uu(e, t) {
  if (t = Object.create(t || null), !e.buffer) return null;
  t.maxLength || (t.maxLength = 79), typeof t.indent != "number" && (t.indent = 1), typeof t.linesBefore != "number" && (t.linesBefore = 3), typeof t.linesAfter != "number" && (t.linesAfter = 2);
  for (var r = /\r?\n|\r|\0/g, i = [0], n = [], a, s = -1; a = r.exec(e.buffer); )
    n.push(a.index), i.push(a.index + a[0].length), e.position <= a.index && s < 0 && (s = i.length - 2);
  s < 0 && (s = i.length - 1);
  var o = "", l, c, h = Math.min(e.line + t.linesAfter, n.length).toString().length, u = t.maxLength - (t.indent + h + 3);
  for (l = 1; l <= t.linesBefore && !(s - l < 0); l++)
    c = Mn(
      e.buffer,
      i[s - l],
      n[s - l],
      e.position - (i[s] - i[s - l]),
      u
    ), o = Tt.repeat(" ", t.indent) + $n((e.line - l + 1).toString(), h) + " | " + c.str + `
` + o;
  for (c = Mn(e.buffer, i[s], n[s], e.position, u), o += Tt.repeat(" ", t.indent) + $n((e.line + 1).toString(), h) + " | " + c.str + `
`, o += Tt.repeat("-", t.indent + h + 3 + c.pos) + `^
`, l = 1; l <= t.linesAfter && !(s + l >= n.length); l++)
    c = Mn(
      e.buffer,
      i[s + l],
      n[s + l],
      e.position - (i[s] - i[s + l]),
      u
    ), o += Tt.repeat(" ", t.indent) + $n((e.line + l + 1).toString(), h) + " | " + c.str + `
`;
  return o.replace(/\n$/, "");
}
p(Uu, "makeSnippet");
var c2 = Uu, h2 = [
  "kind",
  "multi",
  "resolve",
  "construct",
  "instanceOf",
  "predicate",
  "represent",
  "representName",
  "defaultStyle",
  "styleAliases"
], u2 = [
  "scalar",
  "sequence",
  "mapping"
];
function Gu(e) {
  var t = {};
  return e !== null && Object.keys(e).forEach(function(r) {
    e[r].forEach(function(i) {
      t[String(i)] = r;
    });
  }), t;
}
p(Gu, "compileStyleAliases");
function Xu(e, t) {
  if (t = t || {}, Object.keys(t).forEach(function(r) {
    if (h2.indexOf(r) === -1)
      throw new Xt('Unknown option "' + r + '" is met in definition of "' + e + '" YAML type.');
  }), this.options = t, this.tag = e, this.kind = t.kind || null, this.resolve = t.resolve || function() {
    return !0;
  }, this.construct = t.construct || function(r) {
    return r;
  }, this.instanceOf = t.instanceOf || null, this.predicate = t.predicate || null, this.represent = t.represent || null, this.representName = t.representName || null, this.defaultStyle = t.defaultStyle || null, this.multi = t.multi || !1, this.styleAliases = Gu(t.styleAliases || null), u2.indexOf(this.kind) === -1)
    throw new Xt('Unknown kind "' + this.kind + '" is specified for "' + e + '" YAML type.');
}
p(Xu, "Type$1");
var Ot = Xu;
function zs(e, t) {
  var r = [];
  return e[t].forEach(function(i) {
    var n = r.length;
    r.forEach(function(a, s) {
      a.tag === i.tag && a.kind === i.kind && a.multi === i.multi && (n = s);
    }), r[n] = i;
  }), r;
}
p(zs, "compileList");
function Vu() {
  var e = {
    scalar: {},
    sequence: {},
    mapping: {},
    fallback: {},
    multi: {
      scalar: [],
      sequence: [],
      mapping: [],
      fallback: []
    }
  }, t, r;
  function i(n) {
    n.multi ? (e.multi[n.kind].push(n), e.multi.fallback.push(n)) : e[n.kind][n.tag] = e.fallback[n.tag] = n;
  }
  for (p(i, "collectType"), t = 0, r = arguments.length; t < r; t += 1)
    arguments[t].forEach(i);
  return e;
}
p(Vu, "compileMap");
function Qn(e) {
  return this.extend(e);
}
p(Qn, "Schema$1");
Qn.prototype.extend = /* @__PURE__ */ p(function(t) {
  var r = [], i = [];
  if (t instanceof Ot)
    i.push(t);
  else if (Array.isArray(t))
    i = i.concat(t);
  else if (t && (Array.isArray(t.implicit) || Array.isArray(t.explicit)))
    t.implicit && (r = r.concat(t.implicit)), t.explicit && (i = i.concat(t.explicit));
  else
    throw new Xt("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");
  r.forEach(function(a) {
    if (!(a instanceof Ot))
      throw new Xt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
    if (a.loadKind && a.loadKind !== "scalar")
      throw new Xt("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");
    if (a.multi)
      throw new Xt("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.");
  }), i.forEach(function(a) {
    if (!(a instanceof Ot))
      throw new Xt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
  });
  var n = Object.create(Qn.prototype);
  return n.implicit = (this.implicit || []).concat(r), n.explicit = (this.explicit || []).concat(i), n.compiledImplicit = zs(n, "implicit"), n.compiledExplicit = zs(n, "explicit"), n.compiledTypeMap = Vu(n.compiledImplicit, n.compiledExplicit), n;
}, "extend");
var f2 = Qn, d2 = new Ot("tag:yaml.org,2002:str", {
  kind: "scalar",
  construct: /* @__PURE__ */ p(function(e) {
    return e !== null ? e : "";
  }, "construct")
}), p2 = new Ot("tag:yaml.org,2002:seq", {
  kind: "sequence",
  construct: /* @__PURE__ */ p(function(e) {
    return e !== null ? e : [];
  }, "construct")
}), g2 = new Ot("tag:yaml.org,2002:map", {
  kind: "mapping",
  construct: /* @__PURE__ */ p(function(e) {
    return e !== null ? e : {};
  }, "construct")
}), m2 = new f2({
  explicit: [
    d2,
    p2,
    g2
  ]
});
function Zu(e) {
  if (e === null) return !0;
  var t = e.length;
  return t === 1 && e === "~" || t === 4 && (e === "null" || e === "Null" || e === "NULL");
}
p(Zu, "resolveYamlNull");
function Ku() {
  return null;
}
p(Ku, "constructYamlNull");
function Qu(e) {
  return e === null;
}
p(Qu, "isNull");
var y2 = new Ot("tag:yaml.org,2002:null", {
  kind: "scalar",
  resolve: Zu,
  construct: Ku,
  predicate: Qu,
  represent: {
    canonical: /* @__PURE__ */ p(function() {
      return "~";
    }, "canonical"),
    lowercase: /* @__PURE__ */ p(function() {
      return "null";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ p(function() {
      return "NULL";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ p(function() {
      return "Null";
    }, "camelcase"),
    empty: /* @__PURE__ */ p(function() {
      return "";
    }, "empty")
  },
  defaultStyle: "lowercase"
});
function Ju(e) {
  if (e === null) return !1;
  var t = e.length;
  return t === 4 && (e === "true" || e === "True" || e === "TRUE") || t === 5 && (e === "false" || e === "False" || e === "FALSE");
}
p(Ju, "resolveYamlBoolean");
function tf(e) {
  return e === "true" || e === "True" || e === "TRUE";
}
p(tf, "constructYamlBoolean");
function ef(e) {
  return Object.prototype.toString.call(e) === "[object Boolean]";
}
p(ef, "isBoolean");
var x2 = new Ot("tag:yaml.org,2002:bool", {
  kind: "scalar",
  resolve: Ju,
  construct: tf,
  predicate: ef,
  represent: {
    lowercase: /* @__PURE__ */ p(function(e) {
      return e ? "true" : "false";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ p(function(e) {
      return e ? "TRUE" : "FALSE";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ p(function(e) {
      return e ? "True" : "False";
    }, "camelcase")
  },
  defaultStyle: "lowercase"
});
function rf(e) {
  return 48 <= e && e <= 57 || 65 <= e && e <= 70 || 97 <= e && e <= 102;
}
p(rf, "isHexCode");
function nf(e) {
  return 48 <= e && e <= 55;
}
p(nf, "isOctCode");
function af(e) {
  return 48 <= e && e <= 57;
}
p(af, "isDecCode");
function sf(e) {
  if (e === null) return !1;
  var t = e.length, r = 0, i = !1, n;
  if (!t) return !1;
  if (n = e[r], (n === "-" || n === "+") && (n = e[++r]), n === "0") {
    if (r + 1 === t) return !0;
    if (n = e[++r], n === "b") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (n !== "0" && n !== "1") return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "x") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!rf(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "o") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!nf(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
  }
  if (n === "_") return !1;
  for (; r < t; r++)
    if (n = e[r], n !== "_") {
      if (!af(e.charCodeAt(r)))
        return !1;
      i = !0;
    }
  return !(!i || n === "_");
}
p(sf, "resolveYamlInteger");
function of(e) {
  var t = e, r = 1, i;
  if (t.indexOf("_") !== -1 && (t = t.replace(/_/g, "")), i = t[0], (i === "-" || i === "+") && (i === "-" && (r = -1), t = t.slice(1), i = t[0]), t === "0") return 0;
  if (i === "0") {
    if (t[1] === "b") return r * parseInt(t.slice(2), 2);
    if (t[1] === "x") return r * parseInt(t.slice(2), 16);
    if (t[1] === "o") return r * parseInt(t.slice(2), 8);
  }
  return r * parseInt(t, 10);
}
p(of, "constructYamlInteger");
function lf(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && e % 1 === 0 && !Tt.isNegativeZero(e);
}
p(lf, "isInteger");
var b2 = new Ot("tag:yaml.org,2002:int", {
  kind: "scalar",
  resolve: sf,
  construct: of,
  predicate: lf,
  represent: {
    binary: /* @__PURE__ */ p(function(e) {
      return e >= 0 ? "0b" + e.toString(2) : "-0b" + e.toString(2).slice(1);
    }, "binary"),
    octal: /* @__PURE__ */ p(function(e) {
      return e >= 0 ? "0o" + e.toString(8) : "-0o" + e.toString(8).slice(1);
    }, "octal"),
    decimal: /* @__PURE__ */ p(function(e) {
      return e.toString(10);
    }, "decimal"),
    /* eslint-disable max-len */
    hexadecimal: /* @__PURE__ */ p(function(e) {
      return e >= 0 ? "0x" + e.toString(16).toUpperCase() : "-0x" + e.toString(16).toUpperCase().slice(1);
    }, "hexadecimal")
  },
  defaultStyle: "decimal",
  styleAliases: {
    binary: [2, "bin"],
    octal: [8, "oct"],
    decimal: [10, "dec"],
    hexadecimal: [16, "hex"]
  }
}), C2 = new RegExp(
  // 2.5e4, 2.5 and integers
  "^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"
);
function cf(e) {
  return !(e === null || !C2.test(e) || // Quick hack to not allow integers end with `_`
  // Probably should update regexp & check speed
  e[e.length - 1] === "_");
}
p(cf, "resolveYamlFloat");
function hf(e) {
  var t, r;
  return t = e.replace(/_/g, "").toLowerCase(), r = t[0] === "-" ? -1 : 1, "+-".indexOf(t[0]) >= 0 && (t = t.slice(1)), t === ".inf" ? r === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : t === ".nan" ? NaN : r * parseFloat(t, 10);
}
p(hf, "constructYamlFloat");
var _2 = /^[-+]?[0-9]+e/;
function uf(e, t) {
  var r;
  if (isNaN(e))
    switch (t) {
      case "lowercase":
        return ".nan";
      case "uppercase":
        return ".NAN";
      case "camelcase":
        return ".NaN";
    }
  else if (Number.POSITIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return ".inf";
      case "uppercase":
        return ".INF";
      case "camelcase":
        return ".Inf";
    }
  else if (Number.NEGATIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return "-.inf";
      case "uppercase":
        return "-.INF";
      case "camelcase":
        return "-.Inf";
    }
  else if (Tt.isNegativeZero(e))
    return "-0.0";
  return r = e.toString(10), _2.test(r) ? r.replace("e", ".e") : r;
}
p(uf, "representYamlFloat");
function ff(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && (e % 1 !== 0 || Tt.isNegativeZero(e));
}
p(ff, "isFloat");
var w2 = new Ot("tag:yaml.org,2002:float", {
  kind: "scalar",
  resolve: cf,
  construct: hf,
  predicate: ff,
  represent: uf,
  defaultStyle: "lowercase"
}), df = m2.extend({
  implicit: [
    y2,
    x2,
    b2,
    w2
  ]
}), k2 = df, pf = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"
), gf = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$"
);
function mf(e) {
  return e === null ? !1 : pf.exec(e) !== null || gf.exec(e) !== null;
}
p(mf, "resolveYamlTimestamp");
function yf(e) {
  var t, r, i, n, a, s, o, l = 0, c = null, h, u, f;
  if (t = pf.exec(e), t === null && (t = gf.exec(e)), t === null) throw new Error("Date resolve error");
  if (r = +t[1], i = +t[2] - 1, n = +t[3], !t[4])
    return new Date(Date.UTC(r, i, n));
  if (a = +t[4], s = +t[5], o = +t[6], t[7]) {
    for (l = t[7].slice(0, 3); l.length < 3; )
      l += "0";
    l = +l;
  }
  return t[9] && (h = +t[10], u = +(t[11] || 0), c = (h * 60 + u) * 6e4, t[9] === "-" && (c = -c)), f = new Date(Date.UTC(r, i, n, a, s, o, l)), c && f.setTime(f.getTime() - c), f;
}
p(yf, "constructYamlTimestamp");
function xf(e) {
  return e.toISOString();
}
p(xf, "representYamlTimestamp");
var v2 = new Ot("tag:yaml.org,2002:timestamp", {
  kind: "scalar",
  resolve: mf,
  construct: yf,
  instanceOf: Date,
  represent: xf
});
function bf(e) {
  return e === "<<" || e === null;
}
p(bf, "resolveYamlMerge");
var S2 = new Ot("tag:yaml.org,2002:merge", {
  kind: "scalar",
  resolve: bf
}), Yo = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;
function Cf(e) {
  if (e === null) return !1;
  var t, r, i = 0, n = e.length, a = Yo;
  for (r = 0; r < n; r++)
    if (t = a.indexOf(e.charAt(r)), !(t > 64)) {
      if (t < 0) return !1;
      i += 6;
    }
  return i % 8 === 0;
}
p(Cf, "resolveYamlBinary");
function _f(e) {
  var t, r, i = e.replace(/[\r\n=]/g, ""), n = i.length, a = Yo, s = 0, o = [];
  for (t = 0; t < n; t++)
    t % 4 === 0 && t && (o.push(s >> 16 & 255), o.push(s >> 8 & 255), o.push(s & 255)), s = s << 6 | a.indexOf(i.charAt(t));
  return r = n % 4 * 6, r === 0 ? (o.push(s >> 16 & 255), o.push(s >> 8 & 255), o.push(s & 255)) : r === 18 ? (o.push(s >> 10 & 255), o.push(s >> 2 & 255)) : r === 12 && o.push(s >> 4 & 255), new Uint8Array(o);
}
p(_f, "constructYamlBinary");
function wf(e) {
  var t = "", r = 0, i, n, a = e.length, s = Yo;
  for (i = 0; i < a; i++)
    i % 3 === 0 && i && (t += s[r >> 18 & 63], t += s[r >> 12 & 63], t += s[r >> 6 & 63], t += s[r & 63]), r = (r << 8) + e[i];
  return n = a % 3, n === 0 ? (t += s[r >> 18 & 63], t += s[r >> 12 & 63], t += s[r >> 6 & 63], t += s[r & 63]) : n === 2 ? (t += s[r >> 10 & 63], t += s[r >> 4 & 63], t += s[r << 2 & 63], t += s[64]) : n === 1 && (t += s[r >> 2 & 63], t += s[r << 4 & 63], t += s[64], t += s[64]), t;
}
p(wf, "representYamlBinary");
function kf(e) {
  return Object.prototype.toString.call(e) === "[object Uint8Array]";
}
p(kf, "isBinary");
var T2 = new Ot("tag:yaml.org,2002:binary", {
  kind: "scalar",
  resolve: Cf,
  construct: _f,
  predicate: kf,
  represent: wf
}), B2 = Object.prototype.hasOwnProperty, A2 = Object.prototype.toString;
function vf(e) {
  if (e === null) return !0;
  var t = [], r, i, n, a, s, o = e;
  for (r = 0, i = o.length; r < i; r += 1) {
    if (n = o[r], s = !1, A2.call(n) !== "[object Object]") return !1;
    for (a in n)
      if (B2.call(n, a))
        if (!s) s = !0;
        else return !1;
    if (!s) return !1;
    if (t.indexOf(a) === -1) t.push(a);
    else return !1;
  }
  return !0;
}
p(vf, "resolveYamlOmap");
function Sf(e) {
  return e !== null ? e : [];
}
p(Sf, "constructYamlOmap");
var L2 = new Ot("tag:yaml.org,2002:omap", {
  kind: "sequence",
  resolve: vf,
  construct: Sf
}), M2 = Object.prototype.toString;
function Tf(e) {
  if (e === null) return !0;
  var t, r, i, n, a, s = e;
  for (a = new Array(s.length), t = 0, r = s.length; t < r; t += 1) {
    if (i = s[t], M2.call(i) !== "[object Object]" || (n = Object.keys(i), n.length !== 1)) return !1;
    a[t] = [n[0], i[n[0]]];
  }
  return !0;
}
p(Tf, "resolveYamlPairs");
function Bf(e) {
  if (e === null) return [];
  var t, r, i, n, a, s = e;
  for (a = new Array(s.length), t = 0, r = s.length; t < r; t += 1)
    i = s[t], n = Object.keys(i), a[t] = [n[0], i[n[0]]];
  return a;
}
p(Bf, "constructYamlPairs");
var $2 = new Ot("tag:yaml.org,2002:pairs", {
  kind: "sequence",
  resolve: Tf,
  construct: Bf
}), E2 = Object.prototype.hasOwnProperty;
function Af(e) {
  if (e === null) return !0;
  var t, r = e;
  for (t in r)
    if (E2.call(r, t) && r[t] !== null)
      return !1;
  return !0;
}
p(Af, "resolveYamlSet");
function Lf(e) {
  return e !== null ? e : {};
}
p(Lf, "constructYamlSet");
var F2 = new Ot("tag:yaml.org,2002:set", {
  kind: "mapping",
  resolve: Af,
  construct: Lf
}), Mf = k2.extend({
  implicit: [
    v2,
    S2
  ],
  explicit: [
    T2,
    L2,
    $2,
    F2
  ]
}), je = Object.prototype.hasOwnProperty, Jn = 1, $f = 2, Ef = 3, ta = 4, us = 1, D2 = 2, Sc = 3, O2 = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/, R2 = /[\x85\u2028\u2029]/, I2 = /[,\[\]\{\}]/, Ff = /^(?:!|!!|![a-z\-]+!)$/i, Df = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
function Ws(e) {
  return Object.prototype.toString.call(e);
}
p(Ws, "_class");
function he(e) {
  return e === 10 || e === 13;
}
p(he, "is_EOL");
function qe(e) {
  return e === 9 || e === 32;
}
p(qe, "is_WHITE_SPACE");
function Wt(e) {
  return e === 9 || e === 32 || e === 10 || e === 13;
}
p(Wt, "is_WS_OR_EOL");
function ar(e) {
  return e === 44 || e === 91 || e === 93 || e === 123 || e === 125;
}
p(ar, "is_FLOW_INDICATOR");
function Of(e) {
  var t;
  return 48 <= e && e <= 57 ? e - 48 : (t = e | 32, 97 <= t && t <= 102 ? t - 97 + 10 : -1);
}
p(Of, "fromHexCode");
function Rf(e) {
  return e === 120 ? 2 : e === 117 ? 4 : e === 85 ? 8 : 0;
}
p(Rf, "escapedHexLen");
function If(e) {
  return 48 <= e && e <= 57 ? e - 48 : -1;
}
p(If, "fromDecimalCode");
function qs(e) {
  return e === 48 ? "\0" : e === 97 ? "\x07" : e === 98 ? "\b" : e === 116 || e === 9 ? "	" : e === 110 ? `
` : e === 118 ? "\v" : e === 102 ? "\f" : e === 114 ? "\r" : e === 101 ? "\x1B" : e === 32 ? " " : e === 34 ? '"' : e === 47 ? "/" : e === 92 ? "\\" : e === 78 ? "" : e === 95 ? " " : e === 76 ? "\u2028" : e === 80 ? "\u2029" : "";
}
p(qs, "simpleEscapeSequence");
function Pf(e) {
  return e <= 65535 ? String.fromCharCode(e) : String.fromCharCode(
    (e - 65536 >> 10) + 55296,
    (e - 65536 & 1023) + 56320
  );
}
p(Pf, "charFromCodepoint");
var Nf = new Array(256), zf = new Array(256);
for (Je = 0; Je < 256; Je++)
  Nf[Je] = qs(Je) ? 1 : 0, zf[Je] = qs(Je);
var Je;
function Wf(e, t) {
  this.input = e, this.filename = t.filename || null, this.schema = t.schema || Mf, this.onWarning = t.onWarning || null, this.legacy = t.legacy || !1, this.json = t.json || !1, this.listener = t.listener || null, this.implicitTypes = this.schema.compiledImplicit, this.typeMap = this.schema.compiledTypeMap, this.length = e.length, this.position = 0, this.line = 0, this.lineStart = 0, this.lineIndent = 0, this.firstTabInLine = -1, this.documents = [];
}
p(Wf, "State$1");
function Uo(e, t) {
  var r = {
    name: e.filename,
    buffer: e.input.slice(0, -1),
    // omit trailing \0
    position: e.position,
    line: e.line,
    column: e.position - e.lineStart
  };
  return r.snippet = c2(r), new Xt(t, r);
}
p(Uo, "generateError");
function Q(e, t) {
  throw Uo(e, t);
}
p(Q, "throwError");
function Ri(e, t) {
  e.onWarning && e.onWarning.call(null, Uo(e, t));
}
p(Ri, "throwWarning");
var Tc = {
  YAML: /* @__PURE__ */ p(function(t, r, i) {
    var n, a, s;
    t.version !== null && Q(t, "duplication of %YAML directive"), i.length !== 1 && Q(t, "YAML directive accepts exactly one argument"), n = /^([0-9]+)\.([0-9]+)$/.exec(i[0]), n === null && Q(t, "ill-formed argument of the YAML directive"), a = parseInt(n[1], 10), s = parseInt(n[2], 10), a !== 1 && Q(t, "unacceptable YAML version of the document"), t.version = i[0], t.checkLineBreaks = s < 2, s !== 1 && s !== 2 && Ri(t, "unsupported YAML version of the document");
  }, "handleYamlDirective"),
  TAG: /* @__PURE__ */ p(function(t, r, i) {
    var n, a;
    i.length !== 2 && Q(t, "TAG directive accepts exactly two arguments"), n = i[0], a = i[1], Ff.test(n) || Q(t, "ill-formed tag handle (first argument) of the TAG directive"), je.call(t.tagMap, n) && Q(t, 'there is a previously declared suffix for "' + n + '" tag handle'), Df.test(a) || Q(t, "ill-formed tag prefix (second argument) of the TAG directive");
    try {
      a = decodeURIComponent(a);
    } catch {
      Q(t, "tag prefix is malformed: " + a);
    }
    t.tagMap[n] = a;
  }, "handleTagDirective")
};
function Fe(e, t, r, i) {
  var n, a, s, o;
  if (t < r) {
    if (o = e.input.slice(t, r), i)
      for (n = 0, a = o.length; n < a; n += 1)
        s = o.charCodeAt(n), s === 9 || 32 <= s && s <= 1114111 || Q(e, "expected valid JSON character");
    else O2.test(o) && Q(e, "the stream contains non-printable characters");
    e.result += o;
  }
}
p(Fe, "captureSegment");
function Hs(e, t, r, i) {
  var n, a, s, o;
  for (Tt.isObject(r) || Q(e, "cannot merge mappings; the provided source object is unacceptable"), n = Object.keys(r), s = 0, o = n.length; s < o; s += 1)
    a = n[s], je.call(t, a) || (t[a] = r[a], i[a] = !0);
}
p(Hs, "mergeMappings");
function sr(e, t, r, i, n, a, s, o, l) {
  var c, h;
  if (Array.isArray(n))
    for (n = Array.prototype.slice.call(n), c = 0, h = n.length; c < h; c += 1)
      Array.isArray(n[c]) && Q(e, "nested arrays are not supported inside keys"), typeof n == "object" && Ws(n[c]) === "[object Object]" && (n[c] = "[object Object]");
  if (typeof n == "object" && Ws(n) === "[object Object]" && (n = "[object Object]"), n = String(n), t === null && (t = {}), i === "tag:yaml.org,2002:merge")
    if (Array.isArray(a))
      for (c = 0, h = a.length; c < h; c += 1)
        Hs(e, t, a[c], r);
    else
      Hs(e, t, a, r);
  else
    !e.json && !je.call(r, n) && je.call(t, n) && (e.line = s || e.line, e.lineStart = o || e.lineStart, e.position = l || e.position, Q(e, "duplicated mapping key")), n === "__proto__" ? Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      value: a
    }) : t[n] = a, delete r[n];
  return t;
}
p(sr, "storeMappingPair");
function Aa(e) {
  var t;
  t = e.input.charCodeAt(e.position), t === 10 ? e.position++ : t === 13 ? (e.position++, e.input.charCodeAt(e.position) === 10 && e.position++) : Q(e, "a line break is expected"), e.line += 1, e.lineStart = e.position, e.firstTabInLine = -1;
}
p(Aa, "readLineBreak");
function xt(e, t, r) {
  for (var i = 0, n = e.input.charCodeAt(e.position); n !== 0; ) {
    for (; qe(n); )
      n === 9 && e.firstTabInLine === -1 && (e.firstTabInLine = e.position), n = e.input.charCodeAt(++e.position);
    if (t && n === 35)
      do
        n = e.input.charCodeAt(++e.position);
      while (n !== 10 && n !== 13 && n !== 0);
    if (he(n))
      for (Aa(e), n = e.input.charCodeAt(e.position), i++, e.lineIndent = 0; n === 32; )
        e.lineIndent++, n = e.input.charCodeAt(++e.position);
    else
      break;
  }
  return r !== -1 && i !== 0 && e.lineIndent < r && Ri(e, "deficient indentation"), i;
}
p(xt, "skipSeparationSpace");
function Vi(e) {
  var t = e.position, r;
  return r = e.input.charCodeAt(t), !!((r === 45 || r === 46) && r === e.input.charCodeAt(t + 1) && r === e.input.charCodeAt(t + 2) && (t += 3, r = e.input.charCodeAt(t), r === 0 || Wt(r)));
}
p(Vi, "testDocumentSeparator");
function La(e, t) {
  t === 1 ? e.result += " " : t > 1 && (e.result += Tt.repeat(`
`, t - 1));
}
p(La, "writeFoldedLines");
function qf(e, t, r) {
  var i, n, a, s, o, l, c, h, u = e.kind, f = e.result, d;
  if (d = e.input.charCodeAt(e.position), Wt(d) || ar(d) || d === 35 || d === 38 || d === 42 || d === 33 || d === 124 || d === 62 || d === 39 || d === 34 || d === 37 || d === 64 || d === 96 || (d === 63 || d === 45) && (n = e.input.charCodeAt(e.position + 1), Wt(n) || r && ar(n)))
    return !1;
  for (e.kind = "scalar", e.result = "", a = s = e.position, o = !1; d !== 0; ) {
    if (d === 58) {
      if (n = e.input.charCodeAt(e.position + 1), Wt(n) || r && ar(n))
        break;
    } else if (d === 35) {
      if (i = e.input.charCodeAt(e.position - 1), Wt(i))
        break;
    } else {
      if (e.position === e.lineStart && Vi(e) || r && ar(d))
        break;
      if (he(d))
        if (l = e.line, c = e.lineStart, h = e.lineIndent, xt(e, !1, -1), e.lineIndent >= t) {
          o = !0, d = e.input.charCodeAt(e.position);
          continue;
        } else {
          e.position = s, e.line = l, e.lineStart = c, e.lineIndent = h;
          break;
        }
    }
    o && (Fe(e, a, s, !1), La(e, e.line - l), a = s = e.position, o = !1), qe(d) || (s = e.position + 1), d = e.input.charCodeAt(++e.position);
  }
  return Fe(e, a, s, !1), e.result ? !0 : (e.kind = u, e.result = f, !1);
}
p(qf, "readPlainScalar");
function Hf(e, t) {
  var r, i, n;
  if (r = e.input.charCodeAt(e.position), r !== 39)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, i = n = e.position; (r = e.input.charCodeAt(e.position)) !== 0; )
    if (r === 39)
      if (Fe(e, i, e.position, !0), r = e.input.charCodeAt(++e.position), r === 39)
        i = e.position, e.position++, n = e.position;
      else
        return !0;
    else he(r) ? (Fe(e, i, n, !0), La(e, xt(e, !1, t)), i = n = e.position) : e.position === e.lineStart && Vi(e) ? Q(e, "unexpected end of the document within a single quoted scalar") : (e.position++, n = e.position);
  Q(e, "unexpected end of the stream within a single quoted scalar");
}
p(Hf, "readSingleQuotedScalar");
function jf(e, t) {
  var r, i, n, a, s, o;
  if (o = e.input.charCodeAt(e.position), o !== 34)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, r = i = e.position; (o = e.input.charCodeAt(e.position)) !== 0; ) {
    if (o === 34)
      return Fe(e, r, e.position, !0), e.position++, !0;
    if (o === 92) {
      if (Fe(e, r, e.position, !0), o = e.input.charCodeAt(++e.position), he(o))
        xt(e, !1, t);
      else if (o < 256 && Nf[o])
        e.result += zf[o], e.position++;
      else if ((s = Rf(o)) > 0) {
        for (n = s, a = 0; n > 0; n--)
          o = e.input.charCodeAt(++e.position), (s = Of(o)) >= 0 ? a = (a << 4) + s : Q(e, "expected hexadecimal character");
        e.result += Pf(a), e.position++;
      } else
        Q(e, "unknown escape sequence");
      r = i = e.position;
    } else he(o) ? (Fe(e, r, i, !0), La(e, xt(e, !1, t)), r = i = e.position) : e.position === e.lineStart && Vi(e) ? Q(e, "unexpected end of the document within a double quoted scalar") : (e.position++, i = e.position);
  }
  Q(e, "unexpected end of the stream within a double quoted scalar");
}
p(jf, "readDoubleQuotedScalar");
function Yf(e, t) {
  var r = !0, i, n, a, s = e.tag, o, l = e.anchor, c, h, u, f, d, g = /* @__PURE__ */ Object.create(null), m, y, x, b;
  if (b = e.input.charCodeAt(e.position), b === 91)
    h = 93, d = !1, o = [];
  else if (b === 123)
    h = 125, d = !0, o = {};
  else
    return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = o), b = e.input.charCodeAt(++e.position); b !== 0; ) {
    if (xt(e, !0, t), b = e.input.charCodeAt(e.position), b === h)
      return e.position++, e.tag = s, e.anchor = l, e.kind = d ? "mapping" : "sequence", e.result = o, !0;
    r ? b === 44 && Q(e, "expected the node content, but found ','") : Q(e, "missed comma between flow collection entries"), y = m = x = null, u = f = !1, b === 63 && (c = e.input.charCodeAt(e.position + 1), Wt(c) && (u = f = !0, e.position++, xt(e, !0, t))), i = e.line, n = e.lineStart, a = e.position, dr(e, t, Jn, !1, !0), y = e.tag, m = e.result, xt(e, !0, t), b = e.input.charCodeAt(e.position), (f || e.line === i) && b === 58 && (u = !0, b = e.input.charCodeAt(++e.position), xt(e, !0, t), dr(e, t, Jn, !1, !0), x = e.result), d ? sr(e, o, g, y, m, x, i, n, a) : u ? o.push(sr(e, null, g, y, m, x, i, n, a)) : o.push(m), xt(e, !0, t), b = e.input.charCodeAt(e.position), b === 44 ? (r = !0, b = e.input.charCodeAt(++e.position)) : r = !1;
  }
  Q(e, "unexpected end of the stream within a flow collection");
}
p(Yf, "readFlowCollection");
function Uf(e, t) {
  var r, i, n = us, a = !1, s = !1, o = t, l = 0, c = !1, h, u;
  if (u = e.input.charCodeAt(e.position), u === 124)
    i = !1;
  else if (u === 62)
    i = !0;
  else
    return !1;
  for (e.kind = "scalar", e.result = ""; u !== 0; )
    if (u = e.input.charCodeAt(++e.position), u === 43 || u === 45)
      us === n ? n = u === 43 ? Sc : D2 : Q(e, "repeat of a chomping mode identifier");
    else if ((h = If(u)) >= 0)
      h === 0 ? Q(e, "bad explicit indentation width of a block scalar; it cannot be less than one") : s ? Q(e, "repeat of an indentation width identifier") : (o = t + h - 1, s = !0);
    else
      break;
  if (qe(u)) {
    do
      u = e.input.charCodeAt(++e.position);
    while (qe(u));
    if (u === 35)
      do
        u = e.input.charCodeAt(++e.position);
      while (!he(u) && u !== 0);
  }
  for (; u !== 0; ) {
    for (Aa(e), e.lineIndent = 0, u = e.input.charCodeAt(e.position); (!s || e.lineIndent < o) && u === 32; )
      e.lineIndent++, u = e.input.charCodeAt(++e.position);
    if (!s && e.lineIndent > o && (o = e.lineIndent), he(u)) {
      l++;
      continue;
    }
    if (e.lineIndent < o) {
      n === Sc ? e.result += Tt.repeat(`
`, a ? 1 + l : l) : n === us && a && (e.result += `
`);
      break;
    }
    for (i ? qe(u) ? (c = !0, e.result += Tt.repeat(`
`, a ? 1 + l : l)) : c ? (c = !1, e.result += Tt.repeat(`
`, l + 1)) : l === 0 ? a && (e.result += " ") : e.result += Tt.repeat(`
`, l) : e.result += Tt.repeat(`
`, a ? 1 + l : l), a = !0, s = !0, l = 0, r = e.position; !he(u) && u !== 0; )
      u = e.input.charCodeAt(++e.position);
    Fe(e, r, e.position, !1);
  }
  return !0;
}
p(Uf, "readBlockScalar");
function js(e, t) {
  var r, i = e.tag, n = e.anchor, a = [], s, o = !1, l;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = a), l = e.input.charCodeAt(e.position); l !== 0 && (e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, Q(e, "tab characters must not be used in indentation")), !(l !== 45 || (s = e.input.charCodeAt(e.position + 1), !Wt(s)))); ) {
    if (o = !0, e.position++, xt(e, !0, -1) && e.lineIndent <= t) {
      a.push(null), l = e.input.charCodeAt(e.position);
      continue;
    }
    if (r = e.line, dr(e, t, Ef, !1, !0), a.push(e.result), xt(e, !0, -1), l = e.input.charCodeAt(e.position), (e.line === r || e.lineIndent > t) && l !== 0)
      Q(e, "bad indentation of a sequence entry");
    else if (e.lineIndent < t)
      break;
  }
  return o ? (e.tag = i, e.anchor = n, e.kind = "sequence", e.result = a, !0) : !1;
}
p(js, "readBlockSequence");
function Gf(e, t, r) {
  var i, n, a, s, o, l, c = e.tag, h = e.anchor, u = {}, f = /* @__PURE__ */ Object.create(null), d = null, g = null, m = null, y = !1, x = !1, b;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = u), b = e.input.charCodeAt(e.position); b !== 0; ) {
    if (!y && e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, Q(e, "tab characters must not be used in indentation")), i = e.input.charCodeAt(e.position + 1), a = e.line, (b === 63 || b === 58) && Wt(i))
      b === 63 ? (y && (sr(e, u, f, d, g, null, s, o, l), d = g = m = null), x = !0, y = !0, n = !0) : y ? (y = !1, n = !0) : Q(e, "incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"), e.position += 1, b = i;
    else {
      if (s = e.line, o = e.lineStart, l = e.position, !dr(e, r, $f, !1, !0))
        break;
      if (e.line === a) {
        for (b = e.input.charCodeAt(e.position); qe(b); )
          b = e.input.charCodeAt(++e.position);
        if (b === 58)
          b = e.input.charCodeAt(++e.position), Wt(b) || Q(e, "a whitespace character is expected after the key-value separator within a block mapping"), y && (sr(e, u, f, d, g, null, s, o, l), d = g = m = null), x = !0, y = !1, n = !1, d = e.tag, g = e.result;
        else if (x)
          Q(e, "can not read an implicit mapping pair; a colon is missed");
        else
          return e.tag = c, e.anchor = h, !0;
      } else if (x)
        Q(e, "can not read a block mapping entry; a multiline key may not be an implicit key");
      else
        return e.tag = c, e.anchor = h, !0;
    }
    if ((e.line === a || e.lineIndent > t) && (y && (s = e.line, o = e.lineStart, l = e.position), dr(e, t, ta, !0, n) && (y ? g = e.result : m = e.result), y || (sr(e, u, f, d, g, m, s, o, l), d = g = m = null), xt(e, !0, -1), b = e.input.charCodeAt(e.position)), (e.line === a || e.lineIndent > t) && b !== 0)
      Q(e, "bad indentation of a mapping entry");
    else if (e.lineIndent < t)
      break;
  }
  return y && sr(e, u, f, d, g, null, s, o, l), x && (e.tag = c, e.anchor = h, e.kind = "mapping", e.result = u), x;
}
p(Gf, "readBlockMapping");
function Xf(e) {
  var t, r = !1, i = !1, n, a, s;
  if (s = e.input.charCodeAt(e.position), s !== 33) return !1;
  if (e.tag !== null && Q(e, "duplication of a tag property"), s = e.input.charCodeAt(++e.position), s === 60 ? (r = !0, s = e.input.charCodeAt(++e.position)) : s === 33 ? (i = !0, n = "!!", s = e.input.charCodeAt(++e.position)) : n = "!", t = e.position, r) {
    do
      s = e.input.charCodeAt(++e.position);
    while (s !== 0 && s !== 62);
    e.position < e.length ? (a = e.input.slice(t, e.position), s = e.input.charCodeAt(++e.position)) : Q(e, "unexpected end of the stream within a verbatim tag");
  } else {
    for (; s !== 0 && !Wt(s); )
      s === 33 && (i ? Q(e, "tag suffix cannot contain exclamation marks") : (n = e.input.slice(t - 1, e.position + 1), Ff.test(n) || Q(e, "named tag handle cannot contain such characters"), i = !0, t = e.position + 1)), s = e.input.charCodeAt(++e.position);
    a = e.input.slice(t, e.position), I2.test(a) && Q(e, "tag suffix cannot contain flow indicator characters");
  }
  a && !Df.test(a) && Q(e, "tag name cannot contain such characters: " + a);
  try {
    a = decodeURIComponent(a);
  } catch {
    Q(e, "tag name is malformed: " + a);
  }
  return r ? e.tag = a : je.call(e.tagMap, n) ? e.tag = e.tagMap[n] + a : n === "!" ? e.tag = "!" + a : n === "!!" ? e.tag = "tag:yaml.org,2002:" + a : Q(e, 'undeclared tag handle "' + n + '"'), !0;
}
p(Xf, "readTagProperty");
function Vf(e) {
  var t, r;
  if (r = e.input.charCodeAt(e.position), r !== 38) return !1;
  for (e.anchor !== null && Q(e, "duplication of an anchor property"), r = e.input.charCodeAt(++e.position), t = e.position; r !== 0 && !Wt(r) && !ar(r); )
    r = e.input.charCodeAt(++e.position);
  return e.position === t && Q(e, "name of an anchor node must contain at least one character"), e.anchor = e.input.slice(t, e.position), !0;
}
p(Vf, "readAnchorProperty");
function Zf(e) {
  var t, r, i;
  if (i = e.input.charCodeAt(e.position), i !== 42) return !1;
  for (i = e.input.charCodeAt(++e.position), t = e.position; i !== 0 && !Wt(i) && !ar(i); )
    i = e.input.charCodeAt(++e.position);
  return e.position === t && Q(e, "name of an alias node must contain at least one character"), r = e.input.slice(t, e.position), je.call(e.anchorMap, r) || Q(e, 'unidentified alias "' + r + '"'), e.result = e.anchorMap[r], xt(e, !0, -1), !0;
}
p(Zf, "readAlias");
function dr(e, t, r, i, n) {
  var a, s, o, l = 1, c = !1, h = !1, u, f, d, g, m, y;
  if (e.listener !== null && e.listener("open", e), e.tag = null, e.anchor = null, e.kind = null, e.result = null, a = s = o = ta === r || Ef === r, i && xt(e, !0, -1) && (c = !0, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)), l === 1)
    for (; Xf(e) || Vf(e); )
      xt(e, !0, -1) ? (c = !0, o = a, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)) : o = !1;
  if (o && (o = c || n), (l === 1 || ta === r) && (Jn === r || $f === r ? m = t : m = t + 1, y = e.position - e.lineStart, l === 1 ? o && (js(e, y) || Gf(e, y, m)) || Yf(e, m) ? h = !0 : (s && Uf(e, m) || Hf(e, m) || jf(e, m) ? h = !0 : Zf(e) ? (h = !0, (e.tag !== null || e.anchor !== null) && Q(e, "alias node should not have any properties")) : qf(e, m, Jn === r) && (h = !0, e.tag === null && (e.tag = "?")), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : l === 0 && (h = o && js(e, y))), e.tag === null)
    e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
  else if (e.tag === "?") {
    for (e.result !== null && e.kind !== "scalar" && Q(e, 'unacceptable node kind for !<?> tag; it should be "scalar", not "' + e.kind + '"'), u = 0, f = e.implicitTypes.length; u < f; u += 1)
      if (g = e.implicitTypes[u], g.resolve(e.result)) {
        e.result = g.construct(e.result), e.tag = g.tag, e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
        break;
      }
  } else if (e.tag !== "!") {
    if (je.call(e.typeMap[e.kind || "fallback"], e.tag))
      g = e.typeMap[e.kind || "fallback"][e.tag];
    else
      for (g = null, d = e.typeMap.multi[e.kind || "fallback"], u = 0, f = d.length; u < f; u += 1)
        if (e.tag.slice(0, d[u].tag.length) === d[u].tag) {
          g = d[u];
          break;
        }
    g || Q(e, "unknown tag !<" + e.tag + ">"), e.result !== null && g.kind !== e.kind && Q(e, "unacceptable node kind for !<" + e.tag + '> tag; it should be "' + g.kind + '", not "' + e.kind + '"'), g.resolve(e.result, e.tag) ? (e.result = g.construct(e.result, e.tag), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : Q(e, "cannot resolve a node with !<" + e.tag + "> explicit tag");
  }
  return e.listener !== null && e.listener("close", e), e.tag !== null || e.anchor !== null || h;
}
p(dr, "composeNode");
function Kf(e) {
  var t = e.position, r, i, n, a = !1, s;
  for (e.version = null, e.checkLineBreaks = e.legacy, e.tagMap = /* @__PURE__ */ Object.create(null), e.anchorMap = /* @__PURE__ */ Object.create(null); (s = e.input.charCodeAt(e.position)) !== 0 && (xt(e, !0, -1), s = e.input.charCodeAt(e.position), !(e.lineIndent > 0 || s !== 37)); ) {
    for (a = !0, s = e.input.charCodeAt(++e.position), r = e.position; s !== 0 && !Wt(s); )
      s = e.input.charCodeAt(++e.position);
    for (i = e.input.slice(r, e.position), n = [], i.length < 1 && Q(e, "directive name must not be less than one character in length"); s !== 0; ) {
      for (; qe(s); )
        s = e.input.charCodeAt(++e.position);
      if (s === 35) {
        do
          s = e.input.charCodeAt(++e.position);
        while (s !== 0 && !he(s));
        break;
      }
      if (he(s)) break;
      for (r = e.position; s !== 0 && !Wt(s); )
        s = e.input.charCodeAt(++e.position);
      n.push(e.input.slice(r, e.position));
    }
    s !== 0 && Aa(e), je.call(Tc, i) ? Tc[i](e, i, n) : Ri(e, 'unknown document directive "' + i + '"');
  }
  if (xt(e, !0, -1), e.lineIndent === 0 && e.input.charCodeAt(e.position) === 45 && e.input.charCodeAt(e.position + 1) === 45 && e.input.charCodeAt(e.position + 2) === 45 ? (e.position += 3, xt(e, !0, -1)) : a && Q(e, "directives end mark is expected"), dr(e, e.lineIndent - 1, ta, !1, !0), xt(e, !0, -1), e.checkLineBreaks && R2.test(e.input.slice(t, e.position)) && Ri(e, "non-ASCII line breaks are interpreted as content"), e.documents.push(e.result), e.position === e.lineStart && Vi(e)) {
    e.input.charCodeAt(e.position) === 46 && (e.position += 3, xt(e, !0, -1));
    return;
  }
  if (e.position < e.length - 1)
    Q(e, "end of the stream or a document separator is expected");
  else
    return;
}
p(Kf, "readDocument");
function Go(e, t) {
  e = String(e), t = t || {}, e.length !== 0 && (e.charCodeAt(e.length - 1) !== 10 && e.charCodeAt(e.length - 1) !== 13 && (e += `
`), e.charCodeAt(0) === 65279 && (e = e.slice(1)));
  var r = new Wf(e, t), i = e.indexOf("\0");
  for (i !== -1 && (r.position = i, Q(r, "null byte is not allowed in input")), r.input += "\0"; r.input.charCodeAt(r.position) === 32; )
    r.lineIndent += 1, r.position += 1;
  for (; r.position < r.length - 1; )
    Kf(r);
  return r.documents;
}
p(Go, "loadDocuments");
function P2(e, t, r) {
  t !== null && typeof t == "object" && typeof r > "u" && (r = t, t = null);
  var i = Go(e, r);
  if (typeof t != "function")
    return i;
  for (var n = 0, a = i.length; n < a; n += 1)
    t(i[n]);
}
p(P2, "loadAll$1");
function Qf(e, t) {
  var r = Go(e, t);
  if (r.length !== 0) {
    if (r.length === 1)
      return r[0];
    throw new Xt("expected a single document in the stream, but found more");
  }
}
p(Qf, "load$1");
var N2 = Qf, z2 = {
  load: N2
}, Jf = Object.prototype.toString, td = Object.prototype.hasOwnProperty, Xo = 65279, W2 = 9, Ii = 10, q2 = 13, H2 = 32, j2 = 33, Y2 = 34, Ys = 35, U2 = 37, G2 = 38, X2 = 39, V2 = 42, ed = 44, Z2 = 45, ea = 58, K2 = 61, Q2 = 62, J2 = 63, tC = 64, rd = 91, id = 93, eC = 96, nd = 123, rC = 124, ad = 125, It = {};
It[0] = "\\0";
It[7] = "\\a";
It[8] = "\\b";
It[9] = "\\t";
It[10] = "\\n";
It[11] = "\\v";
It[12] = "\\f";
It[13] = "\\r";
It[27] = "\\e";
It[34] = '\\"';
It[92] = "\\\\";
It[133] = "\\N";
It[160] = "\\_";
It[8232] = "\\L";
It[8233] = "\\P";
var iC = [
  "y",
  "Y",
  "yes",
  "Yes",
  "YES",
  "on",
  "On",
  "ON",
  "n",
  "N",
  "no",
  "No",
  "NO",
  "off",
  "Off",
  "OFF"
], nC = /^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;
function sd(e, t) {
  var r, i, n, a, s, o, l;
  if (t === null) return {};
  for (r = {}, i = Object.keys(t), n = 0, a = i.length; n < a; n += 1)
    s = i[n], o = String(t[s]), s.slice(0, 2) === "!!" && (s = "tag:yaml.org,2002:" + s.slice(2)), l = e.compiledTypeMap.fallback[s], l && td.call(l.styleAliases, o) && (o = l.styleAliases[o]), r[s] = o;
  return r;
}
p(sd, "compileStyleMap");
function od(e) {
  var t, r, i;
  if (t = e.toString(16).toUpperCase(), e <= 255)
    r = "x", i = 2;
  else if (e <= 65535)
    r = "u", i = 4;
  else if (e <= 4294967295)
    r = "U", i = 8;
  else
    throw new Xt("code point within a string may not be greater than 0xFFFFFFFF");
  return "\\" + r + Tt.repeat("0", i - t.length) + t;
}
p(od, "encodeHex");
var aC = 1, Pi = 2;
function ld(e) {
  this.schema = e.schema || Mf, this.indent = Math.max(1, e.indent || 2), this.noArrayIndent = e.noArrayIndent || !1, this.skipInvalid = e.skipInvalid || !1, this.flowLevel = Tt.isNothing(e.flowLevel) ? -1 : e.flowLevel, this.styleMap = sd(this.schema, e.styles || null), this.sortKeys = e.sortKeys || !1, this.lineWidth = e.lineWidth || 80, this.noRefs = e.noRefs || !1, this.noCompatMode = e.noCompatMode || !1, this.condenseFlow = e.condenseFlow || !1, this.quotingType = e.quotingType === '"' ? Pi : aC, this.forceQuotes = e.forceQuotes || !1, this.replacer = typeof e.replacer == "function" ? e.replacer : null, this.implicitTypes = this.schema.compiledImplicit, this.explicitTypes = this.schema.compiledExplicit, this.tag = null, this.result = "", this.duplicates = [], this.usedDuplicates = null;
}
p(ld, "State");
function Us(e, t) {
  for (var r = Tt.repeat(" ", t), i = 0, n = -1, a = "", s, o = e.length; i < o; )
    n = e.indexOf(`
`, i), n === -1 ? (s = e.slice(i), i = o) : (s = e.slice(i, n + 1), i = n + 1), s.length && s !== `
` && (a += r), a += s;
  return a;
}
p(Us, "indentString");
function ra(e, t) {
  return `
` + Tt.repeat(" ", e.indent * t);
}
p(ra, "generateNextLine");
function cd(e, t) {
  var r, i, n;
  for (r = 0, i = e.implicitTypes.length; r < i; r += 1)
    if (n = e.implicitTypes[r], n.resolve(t))
      return !0;
  return !1;
}
p(cd, "testImplicitResolving");
function Ni(e) {
  return e === H2 || e === W2;
}
p(Ni, "isWhitespace");
function Vr(e) {
  return 32 <= e && e <= 126 || 161 <= e && e <= 55295 && e !== 8232 && e !== 8233 || 57344 <= e && e <= 65533 && e !== Xo || 65536 <= e && e <= 1114111;
}
p(Vr, "isPrintable");
function Gs(e) {
  return Vr(e) && e !== Xo && e !== q2 && e !== Ii;
}
p(Gs, "isNsCharOrWhitespace");
function Xs(e, t, r) {
  var i = Gs(e), n = i && !Ni(e);
  return (
    // ns-plain-safe
    (r ? (
      // c = flow-in
      i
    ) : i && e !== ed && e !== rd && e !== id && e !== nd && e !== ad) && e !== Ys && !(t === ea && !n) || Gs(t) && !Ni(t) && e === Ys || t === ea && n
  );
}
p(Xs, "isPlainSafe");
function hd(e) {
  return Vr(e) && e !== Xo && !Ni(e) && e !== Z2 && e !== J2 && e !== ea && e !== ed && e !== rd && e !== id && e !== nd && e !== ad && e !== Ys && e !== G2 && e !== V2 && e !== j2 && e !== rC && e !== K2 && e !== Q2 && e !== X2 && e !== Y2 && e !== U2 && e !== tC && e !== eC;
}
p(hd, "isPlainSafeFirst");
function ud(e) {
  return !Ni(e) && e !== ea;
}
p(ud, "isPlainSafeLast");
function $r(e, t) {
  var r = e.charCodeAt(t), i;
  return r >= 55296 && r <= 56319 && t + 1 < e.length && (i = e.charCodeAt(t + 1), i >= 56320 && i <= 57343) ? (r - 55296) * 1024 + i - 56320 + 65536 : r;
}
p($r, "codePointAt");
function Vo(e) {
  var t = /^\n* /;
  return t.test(e);
}
p(Vo, "needIndentIndicator");
var fd = 1, Vs = 2, dd = 3, pd = 4, Lr = 5;
function gd(e, t, r, i, n, a, s, o) {
  var l, c = 0, h = null, u = !1, f = !1, d = i !== -1, g = -1, m = hd($r(e, 0)) && ud($r(e, e.length - 1));
  if (t || s)
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = $r(e, l), !Vr(c))
        return Lr;
      m = m && Xs(c, h, o), h = c;
    }
  else {
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = $r(e, l), c === Ii)
        u = !0, d && (f = f || // Foldable line = too long, and not more-indented.
        l - g - 1 > i && e[g + 1] !== " ", g = l);
      else if (!Vr(c))
        return Lr;
      m = m && Xs(c, h, o), h = c;
    }
    f = f || d && l - g - 1 > i && e[g + 1] !== " ";
  }
  return !u && !f ? m && !s && !n(e) ? fd : a === Pi ? Lr : Vs : r > 9 && Vo(e) ? Lr : s ? a === Pi ? Lr : Vs : f ? pd : dd;
}
p(gd, "chooseScalarStyle");
function md(e, t, r, i, n) {
  e.dump = (function() {
    if (t.length === 0)
      return e.quotingType === Pi ? '""' : "''";
    if (!e.noCompatMode && (iC.indexOf(t) !== -1 || nC.test(t)))
      return e.quotingType === Pi ? '"' + t + '"' : "'" + t + "'";
    var a = e.indent * Math.max(1, r), s = e.lineWidth === -1 ? -1 : Math.max(Math.min(e.lineWidth, 40), e.lineWidth - a), o = i || e.flowLevel > -1 && r >= e.flowLevel;
    function l(c) {
      return cd(e, c);
    }
    switch (p(l, "testAmbiguity"), gd(
      t,
      o,
      e.indent,
      s,
      l,
      e.quotingType,
      e.forceQuotes && !i,
      n
    )) {
      case fd:
        return t;
      case Vs:
        return "'" + t.replace(/'/g, "''") + "'";
      case dd:
        return "|" + Zs(t, e.indent) + Ks(Us(t, a));
      case pd:
        return ">" + Zs(t, e.indent) + Ks(Us(yd(t, s), a));
      case Lr:
        return '"' + xd(t) + '"';
      default:
        throw new Xt("impossible error: invalid scalar style");
    }
  })();
}
p(md, "writeScalar");
function Zs(e, t) {
  var r = Vo(e) ? String(t) : "", i = e[e.length - 1] === `
`, n = i && (e[e.length - 2] === `
` || e === `
`), a = n ? "+" : i ? "" : "-";
  return r + a + `
`;
}
p(Zs, "blockHeader");
function Ks(e) {
  return e[e.length - 1] === `
` ? e.slice(0, -1) : e;
}
p(Ks, "dropEndingNewline");
function yd(e, t) {
  for (var r = /(\n+)([^\n]*)/g, i = (function() {
    var c = e.indexOf(`
`);
    return c = c !== -1 ? c : e.length, r.lastIndex = c, Qs(e.slice(0, c), t);
  })(), n = e[0] === `
` || e[0] === " ", a, s; s = r.exec(e); ) {
    var o = s[1], l = s[2];
    a = l[0] === " ", i += o + (!n && !a && l !== "" ? `
` : "") + Qs(l, t), n = a;
  }
  return i;
}
p(yd, "foldString");
function Qs(e, t) {
  if (e === "" || e[0] === " ") return e;
  for (var r = / [^ ]/g, i, n = 0, a, s = 0, o = 0, l = ""; i = r.exec(e); )
    o = i.index, o - n > t && (a = s > n ? s : o, l += `
` + e.slice(n, a), n = a + 1), s = o;
  return l += `
`, e.length - n > t && s > n ? l += e.slice(n, s) + `
` + e.slice(s + 1) : l += e.slice(n), l.slice(1);
}
p(Qs, "foldLine");
function xd(e) {
  for (var t = "", r = 0, i, n = 0; n < e.length; r >= 65536 ? n += 2 : n++)
    r = $r(e, n), i = It[r], !i && Vr(r) ? (t += e[n], r >= 65536 && (t += e[n + 1])) : t += i || od(r);
  return t;
}
p(xd, "escapeString");
function bd(e, t, r) {
  var i = "", n = e.tag, a, s, o;
  for (a = 0, s = r.length; a < s; a += 1)
    o = r[a], e.replacer && (o = e.replacer.call(r, String(a), o)), (we(e, t, o, !1, !1) || typeof o > "u" && we(e, t, null, !1, !1)) && (i !== "" && (i += "," + (e.condenseFlow ? "" : " ")), i += e.dump);
  e.tag = n, e.dump = "[" + i + "]";
}
p(bd, "writeFlowSequence");
function Js(e, t, r, i) {
  var n = "", a = e.tag, s, o, l;
  for (s = 0, o = r.length; s < o; s += 1)
    l = r[s], e.replacer && (l = e.replacer.call(r, String(s), l)), (we(e, t + 1, l, !0, !0, !1, !0) || typeof l > "u" && we(e, t + 1, null, !0, !0, !1, !0)) && ((!i || n !== "") && (n += ra(e, t)), e.dump && Ii === e.dump.charCodeAt(0) ? n += "-" : n += "- ", n += e.dump);
  e.tag = a, e.dump = n || "[]";
}
p(Js, "writeBlockSequence");
function Cd(e, t, r) {
  var i = "", n = e.tag, a = Object.keys(r), s, o, l, c, h;
  for (s = 0, o = a.length; s < o; s += 1)
    h = "", i !== "" && (h += ", "), e.condenseFlow && (h += '"'), l = a[s], c = r[l], e.replacer && (c = e.replacer.call(r, l, c)), we(e, t, l, !1, !1) && (e.dump.length > 1024 && (h += "? "), h += e.dump + (e.condenseFlow ? '"' : "") + ":" + (e.condenseFlow ? "" : " "), we(e, t, c, !1, !1) && (h += e.dump, i += h));
  e.tag = n, e.dump = "{" + i + "}";
}
p(Cd, "writeFlowMapping");
function _d(e, t, r, i) {
  var n = "", a = e.tag, s = Object.keys(r), o, l, c, h, u, f;
  if (e.sortKeys === !0)
    s.sort();
  else if (typeof e.sortKeys == "function")
    s.sort(e.sortKeys);
  else if (e.sortKeys)
    throw new Xt("sortKeys must be a boolean or a function");
  for (o = 0, l = s.length; o < l; o += 1)
    f = "", (!i || n !== "") && (f += ra(e, t)), c = s[o], h = r[c], e.replacer && (h = e.replacer.call(r, c, h)), we(e, t + 1, c, !0, !0, !0) && (u = e.tag !== null && e.tag !== "?" || e.dump && e.dump.length > 1024, u && (e.dump && Ii === e.dump.charCodeAt(0) ? f += "?" : f += "? "), f += e.dump, u && (f += ra(e, t)), we(e, t + 1, h, !0, u) && (e.dump && Ii === e.dump.charCodeAt(0) ? f += ":" : f += ": ", f += e.dump, n += f));
  e.tag = a, e.dump = n || "{}";
}
p(_d, "writeBlockMapping");
function to(e, t, r) {
  var i, n, a, s, o, l;
  for (n = r ? e.explicitTypes : e.implicitTypes, a = 0, s = n.length; a < s; a += 1)
    if (o = n[a], (o.instanceOf || o.predicate) && (!o.instanceOf || typeof t == "object" && t instanceof o.instanceOf) && (!o.predicate || o.predicate(t))) {
      if (r ? o.multi && o.representName ? e.tag = o.representName(t) : e.tag = o.tag : e.tag = "?", o.represent) {
        if (l = e.styleMap[o.tag] || o.defaultStyle, Jf.call(o.represent) === "[object Function]")
          i = o.represent(t, l);
        else if (td.call(o.represent, l))
          i = o.represent[l](t, l);
        else
          throw new Xt("!<" + o.tag + '> tag resolver accepts not "' + l + '" style');
        e.dump = i;
      }
      return !0;
    }
  return !1;
}
p(to, "detectType");
function we(e, t, r, i, n, a, s) {
  e.tag = null, e.dump = r, to(e, r, !1) || to(e, r, !0);
  var o = Jf.call(e.dump), l = i, c;
  i && (i = e.flowLevel < 0 || e.flowLevel > t);
  var h = o === "[object Object]" || o === "[object Array]", u, f;
  if (h && (u = e.duplicates.indexOf(r), f = u !== -1), (e.tag !== null && e.tag !== "?" || f || e.indent !== 2 && t > 0) && (n = !1), f && e.usedDuplicates[u])
    e.dump = "*ref_" + u;
  else {
    if (h && f && !e.usedDuplicates[u] && (e.usedDuplicates[u] = !0), o === "[object Object]")
      i && Object.keys(e.dump).length !== 0 ? (_d(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (Cd(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (o === "[object Array]")
      i && e.dump.length !== 0 ? (e.noArrayIndent && !s && t > 0 ? Js(e, t - 1, e.dump, n) : Js(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (bd(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (o === "[object String]")
      e.tag !== "?" && md(e, e.dump, t, a, l);
    else {
      if (o === "[object Undefined]")
        return !1;
      if (e.skipInvalid) return !1;
      throw new Xt("unacceptable kind of an object to dump " + o);
    }
    e.tag !== null && e.tag !== "?" && (c = encodeURI(
      e.tag[0] === "!" ? e.tag.slice(1) : e.tag
    ).replace(/!/g, "%21"), e.tag[0] === "!" ? c = "!" + c : c.slice(0, 18) === "tag:yaml.org,2002:" ? c = "!!" + c.slice(18) : c = "!<" + c + ">", e.dump = c + " " + e.dump);
  }
  return !0;
}
p(we, "writeNode");
function wd(e, t) {
  var r = [], i = [], n, a;
  for (ia(e, r, i), n = 0, a = i.length; n < a; n += 1)
    t.duplicates.push(r[i[n]]);
  t.usedDuplicates = new Array(a);
}
p(wd, "getDuplicateReferences");
function ia(e, t, r) {
  var i, n, a;
  if (e !== null && typeof e == "object")
    if (n = t.indexOf(e), n !== -1)
      r.indexOf(n) === -1 && r.push(n);
    else if (t.push(e), Array.isArray(e))
      for (n = 0, a = e.length; n < a; n += 1)
        ia(e[n], t, r);
    else
      for (i = Object.keys(e), n = 0, a = i.length; n < a; n += 1)
        ia(e[i[n]], t, r);
}
p(ia, "inspectNode");
function sC(e, t) {
  t = t || {};
  var r = new ld(t);
  r.noRefs || wd(e, r);
  var i = e;
  return r.replacer && (i = r.replacer.call({ "": i }, "", i)), we(r, 0, i, !0, !0) ? r.dump + `
` : "";
}
p(sC, "dump$1");
function oC(e, t) {
  return function() {
    throw new Error("Function yaml." + e + " is removed in js-yaml 4. Use yaml." + t + " instead, which is now safe by default.");
  };
}
p(oC, "renamed");
var lC = df, cC = z2.load;
var Ft = {
  aggregation: 17.25,
  extension: 17.25,
  composition: 17.25,
  dependency: 6,
  lollipop: 13.5,
  arrow_point: 4
  //arrow_cross: 24,
}, Bc = {
  arrow_point: 9,
  arrow_cross: 12.5,
  arrow_circle: 12.5
};
function _i(e, t) {
  if (e === void 0 || t === void 0)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  e = mt(e), t = mt(t);
  const [r, i] = [e.x, e.y], [n, a] = [t.x, t.y], s = n - r, o = a - i;
  return { angle: Math.atan(o / s), deltaX: s, deltaY: o };
}
p(_i, "calculateDeltaAndAngle");
var mt = /* @__PURE__ */ p((e) => Array.isArray(e) ? { x: e[0], y: e[1] } : e, "pointTransformer"), hC = /* @__PURE__ */ p((e) => ({
  x: /* @__PURE__ */ p(function(t, r, i) {
    let n = 0;
    const a = mt(i[0]).x < mt(i[i.length - 1]).x ? "left" : "right";
    if (r === 0 && Object.hasOwn(Ft, e.arrowTypeStart)) {
      const { angle: d, deltaX: g } = _i(i[0], i[1]);
      n = Ft[e.arrowTypeStart] * Math.cos(d) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Ft, e.arrowTypeEnd)) {
      const { angle: d, deltaX: g } = _i(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Ft[e.arrowTypeEnd] * Math.cos(d) * (g >= 0 ? 1 : -1);
    }
    const s = Math.abs(
      mt(t).x - mt(i[i.length - 1]).x
    ), o = Math.abs(
      mt(t).y - mt(i[i.length - 1]).y
    ), l = Math.abs(mt(t).x - mt(i[0]).x), c = Math.abs(mt(t).y - mt(i[0]).y), h = Ft[e.arrowTypeStart], u = Ft[e.arrowTypeEnd], f = 1;
    if (s < u && s > 0 && o < u) {
      let d = u + f - s;
      d *= a === "right" ? -1 : 1, n -= d;
    }
    if (l < h && l > 0 && c < h) {
      let d = h + f - l;
      d *= a === "right" ? -1 : 1, n += d;
    }
    return mt(t).x + n;
  }, "x"),
  y: /* @__PURE__ */ p(function(t, r, i) {
    let n = 0;
    const a = mt(i[0]).y < mt(i[i.length - 1]).y ? "down" : "up";
    if (r === 0 && Object.hasOwn(Ft, e.arrowTypeStart)) {
      const { angle: d, deltaY: g } = _i(i[0], i[1]);
      n = Ft[e.arrowTypeStart] * Math.abs(Math.sin(d)) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Ft, e.arrowTypeEnd)) {
      const { angle: d, deltaY: g } = _i(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Ft[e.arrowTypeEnd] * Math.abs(Math.sin(d)) * (g >= 0 ? 1 : -1);
    }
    const s = Math.abs(
      mt(t).y - mt(i[i.length - 1]).y
    ), o = Math.abs(
      mt(t).x - mt(i[i.length - 1]).x
    ), l = Math.abs(mt(t).y - mt(i[0]).y), c = Math.abs(mt(t).x - mt(i[0]).x), h = Ft[e.arrowTypeStart], u = Ft[e.arrowTypeEnd], f = 1;
    if (s < u && s > 0 && o < u) {
      let d = u + f - s;
      d *= a === "up" ? -1 : 1, n -= d;
    }
    if (l < h && l > 0 && c < h) {
      let d = h + f - l;
      d *= a === "up" ? -1 : 1, n += d;
    }
    return mt(t).y + n;
  }, "y")
}), "getLineFunctionsWithOffset"), Zo = /* @__PURE__ */ p(({
  flowchart: e
}) => {
  const t = e?.subGraphTitleMargin?.top ?? 0, r = e?.subGraphTitleMargin?.bottom ?? 0, i = t + r;
  return {
    subGraphTitleTopMargin: t,
    subGraphTitleBottomMargin: r,
    subGraphTitleTotalMargin: i
  };
}, "getSubGraphTitleMargins"), uC = /* @__PURE__ */ p((e) => {
  const { handDrawnSeed: t } = ft();
  return {
    fill: e,
    hachureAngle: 120,
    // angle of hachure,
    hachureGap: 4,
    fillWeight: 2,
    roughness: 0.7,
    stroke: e,
    seed: t
  };
}, "solidStateFill"), Jr = /* @__PURE__ */ p((e) => {
  const t = fC([
    ...e.cssCompiledStyles || [],
    ...e.cssStyles || [],
    ...e.labelStyle || []
  ]);
  return { stylesMap: t, stylesArray: [...t] };
}, "compileStyles"), fC = /* @__PURE__ */ p((e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((r) => {
    const [i, n] = r.split(":");
    t.set(i.trim(), n?.trim());
  }), t;
}, "styles2Map"), kd = /* @__PURE__ */ p((e) => e === "color" || e === "font-size" || e === "font-family" || e === "font-weight" || e === "font-style" || e === "text-decoration" || e === "text-align" || e === "text-transform" || e === "line-height" || e === "letter-spacing" || e === "word-spacing" || e === "text-shadow" || e === "text-overflow" || e === "white-space" || e === "word-wrap" || e === "word-break" || e === "overflow-wrap" || e === "hyphens", "isLabelStyle"), U = /* @__PURE__ */ p((e) => {
  const { stylesArray: t } = Jr(e), r = [], i = [], n = [], a = [];
  return t.forEach((s) => {
    const o = s[0];
    kd(o) ? r.push(s.join(":") + " !important") : (i.push(s.join(":") + " !important"), o.includes("stroke") && n.push(s.join(":") + " !important"), o === "fill" && a.push(s.join(":") + " !important"));
  }), {
    labelStyles: r.join(";"),
    nodeStyles: i.join(";"),
    stylesArray: t,
    borderStyles: n,
    backgroundStyles: a
  };
}, "styles2String"), Y = /* @__PURE__ */ p((e, t) => {
  const { themeVariables: r, handDrawnSeed: i } = ft(), { nodeBorder: n, mainBkg: a } = r, { stylesMap: s } = Jr(e);
  return Object.assign(
    {
      roughness: 0.7,
      fill: s.get("fill") || a,
      fillStyle: "hachure",
      // solid fill
      fillWeight: 4,
      hachureGap: 5.2,
      stroke: s.get("stroke") || n,
      seed: i,
      strokeWidth: s.get("stroke-width")?.replace("px", "") || 1.3,
      fillLineDash: [0, 0],
      strokeLineDash: dC(s.get("stroke-dasharray"))
    },
    t
  );
}, "userNodeOverrides"), dC = /* @__PURE__ */ p((e) => {
  if (!e)
    return [0, 0];
  const t = e.trim().split(/\s+/).map(Number);
  if (t.length === 1) {
    const n = isNaN(t[0]) ? 0 : t[0];
    return [n, n];
  }
  const r = isNaN(t[0]) ? 0 : t[0], i = isNaN(t[1]) ? 0 : t[1];
  return [r, i];
}, "getStrokeDashArray"), pn = {}, vt = {}, Ac;
function pC() {
  return Ac || (Ac = 1, Object.defineProperty(vt, "__esModule", { value: !0 }), vt.BLANK_URL = vt.relativeFirstCharacters = vt.whitespaceEscapeCharsRegex = vt.urlSchemeRegex = vt.ctrlCharactersRegex = vt.htmlCtrlEntityRegex = vt.htmlEntitiesRegex = vt.invalidProtocolRegex = void 0, vt.invalidProtocolRegex = /^([^\w]*)(javascript|data|vbscript)/im, vt.htmlEntitiesRegex = /&#(\w+)(^\w|;)?/g, vt.htmlCtrlEntityRegex = /&(newline|tab);/gi, vt.ctrlCharactersRegex = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim, vt.urlSchemeRegex = /^.+(:|&colon;)/gim, vt.whitespaceEscapeCharsRegex = /(\\|%5[cC])((%(6[eE]|72|74))|[nrt])/g, vt.relativeFirstCharacters = [".", "/"], vt.BLANK_URL = "about:blank"), vt;
}
var Lc;
function gC() {
  if (Lc) return pn;
  Lc = 1, Object.defineProperty(pn, "__esModule", { value: !0 }), pn.sanitizeUrl = a;
  var e = pC();
  function t(s) {
    return e.relativeFirstCharacters.indexOf(s[0]) > -1;
  }
  function r(s) {
    var o = s.replace(e.ctrlCharactersRegex, "");
    return o.replace(e.htmlEntitiesRegex, function(l, c) {
      return String.fromCharCode(c);
    });
  }
  function i(s) {
    return URL.canParse(s);
  }
  function n(s) {
    try {
      return decodeURIComponent(s);
    } catch {
      return s;
    }
  }
  function a(s) {
    if (!s)
      return e.BLANK_URL;
    var o, l = n(s.trim());
    do
      l = r(l).replace(e.htmlCtrlEntityRegex, "").replace(e.ctrlCharactersRegex, "").replace(e.whitespaceEscapeCharsRegex, "").trim(), l = n(l), o = l.match(e.ctrlCharactersRegex) || l.match(e.htmlEntitiesRegex) || l.match(e.htmlCtrlEntityRegex) || l.match(e.whitespaceEscapeCharsRegex);
    while (o && o.length > 0);
    var c = l;
    if (!c)
      return e.BLANK_URL;
    if (t(c))
      return c;
    var h = c.trimStart(), u = h.match(e.urlSchemeRegex);
    if (!u)
      return c;
    var f = u[0].toLowerCase().trim();
    if (e.invalidProtocolRegex.test(f))
      return e.BLANK_URL;
    var d = h.replace(/\\/g, "/");
    if (f === "mailto:" || f.includes("://"))
      return d;
    if (f === "http:" || f === "https:") {
      if (!i(d))
        return e.BLANK_URL;
      var g = new URL(d);
      return g.protocol = g.protocol.toLowerCase(), g.hostname = g.hostname.toLowerCase(), g.toString();
    }
    return d;
  }
  return pn;
}
var mC = gC(), vd = typeof global == "object" && global && global.Object === Object && global, yC = typeof self == "object" && self && self.Object === Object && self, ve = vd || yC || Function("return this")(), na = ve.Symbol, Sd = Object.prototype, xC = Sd.hasOwnProperty, bC = Sd.toString, fi = na ? na.toStringTag : void 0;
function CC(e) {
  var t = xC.call(e, fi), r = e[fi];
  try {
    e[fi] = void 0;
    var i = !0;
  } catch {
  }
  var n = bC.call(e);
  return i && (t ? e[fi] = r : delete e[fi]), n;
}
var _C = Object.prototype, wC = _C.toString;
function kC(e) {
  return wC.call(e);
}
var vC = "[object Null]", SC = "[object Undefined]", Mc = na ? na.toStringTag : void 0;
function ti(e) {
  return e == null ? e === void 0 ? SC : vC : Mc && Mc in Object(e) ? CC(e) : kC(e);
}
function yr(e) {
  var t = typeof e;
  return e != null && (t == "object" || t == "function");
}
var TC = "[object AsyncFunction]", BC = "[object Function]", AC = "[object GeneratorFunction]", LC = "[object Proxy]";
function Ko(e) {
  if (!yr(e))
    return !1;
  var t = ti(e);
  return t == BC || t == AC || t == TC || t == LC;
}
var fs = ve["__core-js_shared__"], $c = (function() {
  var e = /[^.]+$/.exec(fs && fs.keys && fs.keys.IE_PROTO || "");
  return e ? "Symbol(src)_1." + e : "";
})();
function MC(e) {
  return !!$c && $c in e;
}
var $C = Function.prototype, EC = $C.toString;
function xr(e) {
  if (e != null) {
    try {
      return EC.call(e);
    } catch {
    }
    try {
      return e + "";
    } catch {
    }
  }
  return "";
}
var FC = /[\\^$.*+?()[\]{}|]/g, DC = /^\[object .+?Constructor\]$/, OC = Function.prototype, RC = Object.prototype, IC = OC.toString, PC = RC.hasOwnProperty, NC = RegExp(
  "^" + IC.call(PC).replace(FC, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function zC(e) {
  if (!yr(e) || MC(e))
    return !1;
  var t = Ko(e) ? NC : DC;
  return t.test(xr(e));
}
function WC(e, t) {
  return e?.[t];
}
function br(e, t) {
  var r = WC(e, t);
  return zC(r) ? r : void 0;
}
var zi = br(Object, "create");
function qC() {
  this.__data__ = zi ? zi(null) : {}, this.size = 0;
}
function HC(e) {
  var t = this.has(e) && delete this.__data__[e];
  return this.size -= t ? 1 : 0, t;
}
var jC = "__lodash_hash_undefined__", YC = Object.prototype, UC = YC.hasOwnProperty;
function GC(e) {
  var t = this.__data__;
  if (zi) {
    var r = t[e];
    return r === jC ? void 0 : r;
  }
  return UC.call(t, e) ? t[e] : void 0;
}
var XC = Object.prototype, VC = XC.hasOwnProperty;
function ZC(e) {
  var t = this.__data__;
  return zi ? t[e] !== void 0 : VC.call(t, e);
}
var KC = "__lodash_hash_undefined__";
function QC(e, t) {
  var r = this.__data__;
  return this.size += this.has(e) ? 0 : 1, r[e] = zi && t === void 0 ? KC : t, this;
}
function pr(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
pr.prototype.clear = qC;
pr.prototype.delete = HC;
pr.prototype.get = GC;
pr.prototype.has = ZC;
pr.prototype.set = QC;
function JC() {
  this.__data__ = [], this.size = 0;
}
function Ma(e, t) {
  return e === t || e !== e && t !== t;
}
function $a(e, t) {
  for (var r = e.length; r--; )
    if (Ma(e[r][0], t))
      return r;
  return -1;
}
var t_ = Array.prototype, e_ = t_.splice;
function r_(e) {
  var t = this.__data__, r = $a(t, e);
  if (r < 0)
    return !1;
  var i = t.length - 1;
  return r == i ? t.pop() : e_.call(t, r, 1), --this.size, !0;
}
function i_(e) {
  var t = this.__data__, r = $a(t, e);
  return r < 0 ? void 0 : t[r][1];
}
function n_(e) {
  return $a(this.__data__, e) > -1;
}
function a_(e, t) {
  var r = this.__data__, i = $a(r, e);
  return i < 0 ? (++this.size, r.push([e, t])) : r[i][1] = t, this;
}
function Ie(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Ie.prototype.clear = JC;
Ie.prototype.delete = r_;
Ie.prototype.get = i_;
Ie.prototype.has = n_;
Ie.prototype.set = a_;
var Wi = br(ve, "Map");
function s_() {
  this.size = 0, this.__data__ = {
    hash: new pr(),
    map: new (Wi || Ie)(),
    string: new pr()
  };
}
function o_(e) {
  var t = typeof e;
  return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null;
}
function Ea(e, t) {
  var r = e.__data__;
  return o_(t) ? r[typeof t == "string" ? "string" : "hash"] : r.map;
}
function l_(e) {
  var t = Ea(this, e).delete(e);
  return this.size -= t ? 1 : 0, t;
}
function c_(e) {
  return Ea(this, e).get(e);
}
function h_(e) {
  return Ea(this, e).has(e);
}
function u_(e, t) {
  var r = Ea(this, e), i = r.size;
  return r.set(e, t), this.size += r.size == i ? 0 : 1, this;
}
function Ge(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Ge.prototype.clear = s_;
Ge.prototype.delete = l_;
Ge.prototype.get = c_;
Ge.prototype.has = h_;
Ge.prototype.set = u_;
var f_ = "Expected a function";
function Zi(e, t) {
  if (typeof e != "function" || t != null && typeof t != "function")
    throw new TypeError(f_);
  var r = function() {
    var i = arguments, n = t ? t.apply(this, i) : i[0], a = r.cache;
    if (a.has(n))
      return a.get(n);
    var s = e.apply(this, i);
    return r.cache = a.set(n, s) || a, s;
  };
  return r.cache = new (Zi.Cache || Ge)(), r;
}
Zi.Cache = Ge;
function d_() {
  this.__data__ = new Ie(), this.size = 0;
}
function p_(e) {
  var t = this.__data__, r = t.delete(e);
  return this.size = t.size, r;
}
function g_(e) {
  return this.__data__.get(e);
}
function m_(e) {
  return this.__data__.has(e);
}
var y_ = 200;
function x_(e, t) {
  var r = this.__data__;
  if (r instanceof Ie) {
    var i = r.__data__;
    if (!Wi || i.length < y_ - 1)
      return i.push([e, t]), this.size = ++r.size, this;
    r = this.__data__ = new Ge(i);
  }
  return r.set(e, t), this.size = r.size, this;
}
function ei(e) {
  var t = this.__data__ = new Ie(e);
  this.size = t.size;
}
ei.prototype.clear = d_;
ei.prototype.delete = p_;
ei.prototype.get = g_;
ei.prototype.has = m_;
ei.prototype.set = x_;
var aa = (function() {
  try {
    var e = br(Object, "defineProperty");
    return e({}, "", {}), e;
  } catch {
  }
})();
function Qo(e, t, r) {
  t == "__proto__" && aa ? aa(e, t, {
    configurable: !0,
    enumerable: !0,
    value: r,
    writable: !0
  }) : e[t] = r;
}
function eo(e, t, r) {
  (r !== void 0 && !Ma(e[t], r) || r === void 0 && !(t in e)) && Qo(e, t, r);
}
function b_(e) {
  return function(t, r, i) {
    for (var n = -1, a = Object(t), s = i(t), o = s.length; o--; ) {
      var l = s[++n];
      if (r(a[l], l, a) === !1)
        break;
    }
    return t;
  };
}
var C_ = b_(), Td = typeof exports == "object" && exports && !exports.nodeType && exports, Ec = Td && typeof module == "object" && module && !module.nodeType && module, __ = Ec && Ec.exports === Td, Fc = __ ? ve.Buffer : void 0, Dc = Fc ? Fc.allocUnsafe : void 0;
function w_(e, t) {
  if (t)
    return e.slice();
  var r = e.length, i = Dc ? Dc(r) : new e.constructor(r);
  return e.copy(i), i;
}
var Oc = ve.Uint8Array;
function k_(e) {
  var t = new e.constructor(e.byteLength);
  return new Oc(t).set(new Oc(e)), t;
}
function v_(e, t) {
  var r = t ? k_(e.buffer) : e.buffer;
  return new e.constructor(r, e.byteOffset, e.length);
}
function S_(e, t) {
  var r = -1, i = e.length;
  for (t || (t = Array(i)); ++r < i; )
    t[r] = e[r];
  return t;
}
var Rc = Object.create, T_ = /* @__PURE__ */ (function() {
  function e() {
  }
  return function(t) {
    if (!yr(t))
      return {};
    if (Rc)
      return Rc(t);
    e.prototype = t;
    var r = new e();
    return e.prototype = void 0, r;
  };
})();
function Bd(e, t) {
  return function(r) {
    return e(t(r));
  };
}
var Ad = Bd(Object.getPrototypeOf, Object), B_ = Object.prototype;
function Fa(e) {
  var t = e && e.constructor, r = typeof t == "function" && t.prototype || B_;
  return e === r;
}
function A_(e) {
  return typeof e.constructor == "function" && !Fa(e) ? T_(Ad(e)) : {};
}
function Ki(e) {
  return e != null && typeof e == "object";
}
var L_ = "[object Arguments]";
function Ic(e) {
  return Ki(e) && ti(e) == L_;
}
var Ld = Object.prototype, M_ = Ld.hasOwnProperty, $_ = Ld.propertyIsEnumerable, sa = Ic(/* @__PURE__ */ (function() {
  return arguments;
})()) ? Ic : function(e) {
  return Ki(e) && M_.call(e, "callee") && !$_.call(e, "callee");
}, oa = Array.isArray, E_ = 9007199254740991;
function Md(e) {
  return typeof e == "number" && e > -1 && e % 1 == 0 && e <= E_;
}
function Da(e) {
  return e != null && Md(e.length) && !Ko(e);
}
function F_(e) {
  return Ki(e) && Da(e);
}
function D_() {
  return !1;
}
var $d = typeof exports == "object" && exports && !exports.nodeType && exports, Pc = $d && typeof module == "object" && module && !module.nodeType && module, O_ = Pc && Pc.exports === $d, Nc = O_ ? ve.Buffer : void 0, R_ = Nc ? Nc.isBuffer : void 0, Jo = R_ || D_, I_ = "[object Object]", P_ = Function.prototype, N_ = Object.prototype, Ed = P_.toString, z_ = N_.hasOwnProperty, W_ = Ed.call(Object);
function q_(e) {
  if (!Ki(e) || ti(e) != I_)
    return !1;
  var t = Ad(e);
  if (t === null)
    return !0;
  var r = z_.call(t, "constructor") && t.constructor;
  return typeof r == "function" && r instanceof r && Ed.call(r) == W_;
}
var H_ = "[object Arguments]", j_ = "[object Array]", Y_ = "[object Boolean]", U_ = "[object Date]", G_ = "[object Error]", X_ = "[object Function]", V_ = "[object Map]", Z_ = "[object Number]", K_ = "[object Object]", Q_ = "[object RegExp]", J_ = "[object Set]", tw = "[object String]", ew = "[object WeakMap]", rw = "[object ArrayBuffer]", iw = "[object DataView]", nw = "[object Float32Array]", aw = "[object Float64Array]", sw = "[object Int8Array]", ow = "[object Int16Array]", lw = "[object Int32Array]", cw = "[object Uint8Array]", hw = "[object Uint8ClampedArray]", uw = "[object Uint16Array]", fw = "[object Uint32Array]", pt = {};
pt[nw] = pt[aw] = pt[sw] = pt[ow] = pt[lw] = pt[cw] = pt[hw] = pt[uw] = pt[fw] = !0;
pt[H_] = pt[j_] = pt[rw] = pt[Y_] = pt[iw] = pt[U_] = pt[G_] = pt[X_] = pt[V_] = pt[Z_] = pt[K_] = pt[Q_] = pt[J_] = pt[tw] = pt[ew] = !1;
function dw(e) {
  return Ki(e) && Md(e.length) && !!pt[ti(e)];
}
function pw(e) {
  return function(t) {
    return e(t);
  };
}
var Fd = typeof exports == "object" && exports && !exports.nodeType && exports, Mi = Fd && typeof module == "object" && module && !module.nodeType && module, gw = Mi && Mi.exports === Fd, ds = gw && vd.process, zc = (function() {
  try {
    var e = Mi && Mi.require && Mi.require("util").types;
    return e || ds && ds.binding && ds.binding("util");
  } catch {
  }
})(), Wc = zc && zc.isTypedArray, tl = Wc ? pw(Wc) : dw;
function ro(e, t) {
  if (!(t === "constructor" && typeof e[t] == "function") && t != "__proto__")
    return e[t];
}
var mw = Object.prototype, yw = mw.hasOwnProperty;
function xw(e, t, r) {
  var i = e[t];
  (!(yw.call(e, t) && Ma(i, r)) || r === void 0 && !(t in e)) && Qo(e, t, r);
}
function bw(e, t, r, i) {
  var n = !r;
  r || (r = {});
  for (var a = -1, s = t.length; ++a < s; ) {
    var o = t[a], l = void 0;
    l === void 0 && (l = e[o]), n ? Qo(r, o, l) : xw(r, o, l);
  }
  return r;
}
function Cw(e, t) {
  for (var r = -1, i = Array(e); ++r < e; )
    i[r] = t(r);
  return i;
}
var _w = 9007199254740991, ww = /^(?:0|[1-9]\d*)$/;
function Dd(e, t) {
  var r = typeof e;
  return t = t ?? _w, !!t && (r == "number" || r != "symbol" && ww.test(e)) && e > -1 && e % 1 == 0 && e < t;
}
var kw = Object.prototype, vw = kw.hasOwnProperty;
function Sw(e, t) {
  var r = oa(e), i = !r && sa(e), n = !r && !i && Jo(e), a = !r && !i && !n && tl(e), s = r || i || n || a, o = s ? Cw(e.length, String) : [], l = o.length;
  for (var c in e)
    (t || vw.call(e, c)) && !(s && // Safari 9 has enumerable `arguments.length` in strict mode.
    (c == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    n && (c == "offset" || c == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    a && (c == "buffer" || c == "byteLength" || c == "byteOffset") || // Skip index properties.
    Dd(c, l))) && o.push(c);
  return o;
}
function Tw(e) {
  var t = [];
  if (e != null)
    for (var r in Object(e))
      t.push(r);
  return t;
}
var Bw = Object.prototype, Aw = Bw.hasOwnProperty;
function Lw(e) {
  if (!yr(e))
    return Tw(e);
  var t = Fa(e), r = [];
  for (var i in e)
    i == "constructor" && (t || !Aw.call(e, i)) || r.push(i);
  return r;
}
function Od(e) {
  return Da(e) ? Sw(e, !0) : Lw(e);
}
function Mw(e) {
  return bw(e, Od(e));
}
function $w(e, t, r, i, n, a, s) {
  var o = ro(e, r), l = ro(t, r), c = s.get(l);
  if (c) {
    eo(e, r, c);
    return;
  }
  var h = a ? a(o, l, r + "", e, t, s) : void 0, u = h === void 0;
  if (u) {
    var f = oa(l), d = !f && Jo(l), g = !f && !d && tl(l);
    h = l, f || d || g ? oa(o) ? h = o : F_(o) ? h = S_(o) : d ? (u = !1, h = w_(l, !0)) : g ? (u = !1, h = v_(l, !0)) : h = [] : q_(l) || sa(l) ? (h = o, sa(o) ? h = Mw(o) : (!yr(o) || Ko(o)) && (h = A_(l))) : u = !1;
  }
  u && (s.set(l, h), n(h, l, i, a, s), s.delete(l)), eo(e, r, h);
}
function Rd(e, t, r, i, n) {
  e !== t && C_(t, function(a, s) {
    if (n || (n = new ei()), yr(a))
      $w(e, t, s, r, Rd, i, n);
    else {
      var o = i ? i(ro(e, s), a, s + "", e, t, n) : void 0;
      o === void 0 && (o = a), eo(e, s, o);
    }
  }, Od);
}
function Id(e) {
  return e;
}
function Ew(e, t, r) {
  switch (r.length) {
    case 0:
      return e.call(t);
    case 1:
      return e.call(t, r[0]);
    case 2:
      return e.call(t, r[0], r[1]);
    case 3:
      return e.call(t, r[0], r[1], r[2]);
  }
  return e.apply(t, r);
}
var qc = Math.max;
function Fw(e, t, r) {
  return t = qc(t === void 0 ? e.length - 1 : t, 0), function() {
    for (var i = arguments, n = -1, a = qc(i.length - t, 0), s = Array(a); ++n < a; )
      s[n] = i[t + n];
    n = -1;
    for (var o = Array(t + 1); ++n < t; )
      o[n] = i[n];
    return o[t] = r(s), Ew(e, this, o);
  };
}
function Dw(e) {
  return function() {
    return e;
  };
}
var Ow = aa ? function(e, t) {
  return aa(e, "toString", {
    configurable: !0,
    enumerable: !1,
    value: Dw(t),
    writable: !0
  });
} : Id, Rw = 800, Iw = 16, Pw = Date.now;
function Nw(e) {
  var t = 0, r = 0;
  return function() {
    var i = Pw(), n = Iw - (i - r);
    if (r = i, n > 0) {
      if (++t >= Rw)
        return arguments[0];
    } else
      t = 0;
    return e.apply(void 0, arguments);
  };
}
var zw = Nw(Ow);
function Ww(e, t) {
  return zw(Fw(e, t, Id), e + "");
}
function qw(e, t, r) {
  if (!yr(r))
    return !1;
  var i = typeof t;
  return (i == "number" ? Da(r) && Dd(t, r.length) : i == "string" && t in r) ? Ma(r[t], e) : !1;
}
function Hw(e) {
  return Ww(function(t, r) {
    var i = -1, n = r.length, a = n > 1 ? r[n - 1] : void 0, s = n > 2 ? r[2] : void 0;
    for (a = e.length > 3 && typeof a == "function" ? (n--, a) : void 0, s && qw(r[0], r[1], s) && (a = n < 3 ? void 0 : a, n = 1), t = Object(t); ++i < n; ) {
      var o = r[i];
      o && e(t, o, i, a);
    }
    return t;
  });
}
var jw = Hw(function(e, t, r) {
  Rd(e, t, r);
}), Yw = "​", Uw = {
  curveBasis: Ln,
  curveBasisClosed: X1,
  curveBasisOpen: V1,
  curveBumpX: _u,
  curveBumpY: wu,
  curveBundle: Z1,
  curveCardinalClosed: K1,
  curveCardinalOpen: Q1,
  curveCardinal: Tu,
  curveCatmullRomClosed: J1,
  curveCatmullRomOpen: t2,
  curveCatmullRom: Au,
  curveLinear: Xn,
  curveLinearClosed: e2,
  curveMonotoneX: Du,
  curveMonotoneY: Ou,
  curveNatural: Iu,
  curveStep: Pu,
  curveStepAfter: zu,
  curveStepBefore: Nu
}, Gw = /\s*(?:(\w+)(?=:):|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, Xw = /* @__PURE__ */ p(function(e, t) {
  const r = Pd(e, /(?:init\b)|(?:initialize\b)/);
  let i = {};
  if (Array.isArray(r)) {
    const s = r.map((o) => o.args);
    In(s), i = St(i, [...s]);
  } else
    i = r.args;
  if (!i)
    return;
  let n = vo(e, t);
  const a = "config";
  return i[a] !== void 0 && (n === "flowchart-v2" && (n = "flowchart"), i[n] = i[a], delete i[a]), i;
}, "detectInit"), Pd = /* @__PURE__ */ p(function(e, t = null) {
  try {
    const r = new RegExp(
      `[%]{2}(?![{]${Gw.source})(?=[}][%]{2}).*
`,
      "ig"
    );
    e = e.trim().replace(r, "").replace(/'/gm, '"'), F.debug(
      `Detecting diagram directive${t !== null ? " type:" + t : ""} based on the text:${e}`
    );
    let i;
    const n = [];
    for (; (i = Ai.exec(e)) !== null; )
      if (i.index === Ai.lastIndex && Ai.lastIndex++, i && !t || t && i[1]?.match(t) || t && i[2]?.match(t)) {
        const a = i[1] ? i[1] : i[2], s = i[3] ? i[3].trim() : i[4] ? JSON.parse(i[4].trim()) : null;
        n.push({ type: a, args: s });
      }
    return n.length === 0 ? { type: e, args: null } : n.length === 1 ? n[0] : n;
  } catch (r) {
    return F.error(
      `ERROR: ${r.message} - Unable to parse directive type: '${t}' based on the text: '${e}'`
    ), { type: void 0, args: null };
  }
}, "detectDirective"), Vw = /* @__PURE__ */ p(function(e) {
  return e.replace(Ai, "");
}, "removeDirectives"), Zw = /* @__PURE__ */ p(function(e, t) {
  for (const [r, i] of t.entries())
    if (i.match(e))
      return r;
  return -1;
}, "isSubstringInArray");
function el(e, t) {
  if (!e)
    return t;
  const r = `curve${e.charAt(0).toUpperCase() + e.slice(1)}`;
  return Uw[r] ?? t;
}
p(el, "interpolateToCurve");
function Nd(e, t) {
  const r = e.trim();
  if (r)
    return t.securityLevel !== "loose" ? mC.sanitizeUrl(r) : r;
}
p(Nd, "formatUrl");
var Kw = /* @__PURE__ */ p((e, ...t) => {
  const r = e.split("."), i = r.length - 1, n = r[i];
  let a = window;
  for (let s = 0; s < i; s++)
    if (a = a[r[s]], !a) {
      F.error(`Function name: ${e} not found in window`);
      return;
    }
  a[n](...t);
}, "runFunc");
function rl(e, t) {
  return !e || !t ? 0 : Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2));
}
p(rl, "distance");
function zd(e) {
  let t, r = 0;
  e.forEach((n) => {
    r += rl(n, t), t = n;
  });
  const i = r / 2;
  return il(e, i);
}
p(zd, "traverseEdge");
function Wd(e) {
  return e.length === 1 ? e[0] : zd(e);
}
p(Wd, "calcLabelPosition");
var Hc = /* @__PURE__ */ p((e, t = 2) => {
  const r = Math.pow(10, t);
  return Math.round(e * r) / r;
}, "roundNumber"), il = /* @__PURE__ */ p((e, t) => {
  let r, i = t;
  for (const n of e) {
    if (r) {
      const a = rl(n, r);
      if (a === 0)
        return r;
      if (a < i)
        i -= a;
      else {
        const s = i / a;
        if (s <= 0)
          return r;
        if (s >= 1)
          return { x: n.x, y: n.y };
        if (s > 0 && s < 1)
          return {
            x: Hc((1 - s) * r.x + s * n.x, 5),
            y: Hc((1 - s) * r.y + s * n.y, 5)
          };
      }
    }
    r = n;
  }
  throw new Error("Could not find a suitable point for the given distance");
}, "calculatePoint"), Qw = /* @__PURE__ */ p((e, t, r) => {
  F.info(`our points ${JSON.stringify(t)}`), t[0] !== r && (t = t.reverse());
  const n = il(t, 25), a = e ? 10 : 5, s = Math.atan2(t[0].y - n.y, t[0].x - n.x), o = { x: 0, y: 0 };
  return o.x = Math.sin(s) * a + (t[0].x + n.x) / 2, o.y = -Math.cos(s) * a + (t[0].y + n.y) / 2, o;
}, "calcCardinalityPosition");
function qd(e, t, r) {
  const i = structuredClone(r);
  F.info("our points", i), t !== "start_left" && t !== "start_right" && i.reverse();
  const n = 25 + e, a = il(i, n), s = 10 + e * 0.5, o = Math.atan2(i[0].y - a.y, i[0].x - a.x), l = { x: 0, y: 0 };
  return t === "start_left" ? (l.x = Math.sin(o + Math.PI) * s + (i[0].x + a.x) / 2, l.y = -Math.cos(o + Math.PI) * s + (i[0].y + a.y) / 2) : t === "end_right" ? (l.x = Math.sin(o - Math.PI) * s + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(o - Math.PI) * s + (i[0].y + a.y) / 2 - 5) : t === "end_left" ? (l.x = Math.sin(o) * s + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(o) * s + (i[0].y + a.y) / 2 - 5) : (l.x = Math.sin(o) * s + (i[0].x + a.x) / 2, l.y = -Math.cos(o) * s + (i[0].y + a.y) / 2), l;
}
p(qd, "calcTerminalLabelPosition");
function Hd(e) {
  let t = "", r = "";
  for (const i of e)
    i !== void 0 && (i.startsWith("color:") || i.startsWith("text-align:") ? r = r + i + ";" : t = t + i + ";");
  return { style: t, labelStyle: r };
}
p(Hd, "getStylesFromArray");
var jc = 0, Jw = /* @__PURE__ */ p(() => (jc++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + jc), "generateId");
function jd(e) {
  let t = "";
  const r = "0123456789abcdef", i = r.length;
  for (let n = 0; n < e; n++)
    t += r.charAt(Math.floor(Math.random() * i));
  return t;
}
p(jd, "makeRandomHex");
var tk = /* @__PURE__ */ p((e) => jd(e.length), "random"), ek = /* @__PURE__ */ p(function() {
  return {
    x: 0,
    y: 0,
    fill: void 0,
    anchor: "start",
    style: "#666",
    width: 100,
    height: 100,
    textMargin: 0,
    rx: 0,
    ry: 0,
    valign: void 0,
    text: ""
  };
}, "getTextObj"), rk = /* @__PURE__ */ p(function(e, t) {
  const r = t.text.replace(Qr.lineBreakRegex, " "), [, i] = Oa(t.fontSize), n = e.append("text");
  n.attr("x", t.x), n.attr("y", t.y), n.style("text-anchor", t.anchor), n.style("font-family", t.fontFamily), n.style("font-size", i), n.style("font-weight", t.fontWeight), n.attr("fill", t.fill), t.class !== void 0 && n.attr("class", t.class);
  const a = n.append("tspan");
  return a.attr("x", t.x + t.textMargin * 2), a.attr("fill", t.fill), a.text(r), n;
}, "drawSimpleText"), ik = Zi(
  (e, t, r) => {
    if (!e || (r = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", joinWith: "<br/>" },
      r
    ), Qr.lineBreakRegex.test(e)))
      return e;
    const i = e.split(" ").filter(Boolean), n = [];
    let a = "";
    return i.forEach((s, o) => {
      const l = Oe(`${s} `, r), c = Oe(a, r);
      if (l > t) {
        const { hyphenatedStrings: f, remainingWord: d } = nk(s, t, "-", r);
        n.push(a, ...f), a = d;
      } else c + l >= t ? (n.push(a), a = s) : a = [a, s].filter(Boolean).join(" ");
      o + 1 === i.length && n.push(a);
    }), n.filter((s) => s !== "").join(r.joinWith);
  },
  (e, t, r) => `${e}${t}${r.fontSize}${r.fontWeight}${r.fontFamily}${r.joinWith}`
), nk = Zi(
  (e, t, r = "-", i) => {
    i = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", margin: 0 },
      i
    );
    const n = [...e], a = [];
    let s = "";
    return n.forEach((o, l) => {
      const c = `${s}${o}`;
      if (Oe(c, i) >= t) {
        const u = l + 1, f = n.length === u, d = `${c}${r}`;
        a.push(f ? c : d), s = "";
      } else
        s = c;
    }), { hyphenatedStrings: a, remainingWord: s };
  },
  (e, t, r = "-", i) => `${e}${t}${r}${i.fontSize}${i.fontWeight}${i.fontFamily}`
);
function Yd(e, t) {
  return nl(e, t).height;
}
p(Yd, "calculateTextHeight");
function Oe(e, t) {
  return nl(e, t).width;
}
p(Oe, "calculateTextWidth");
var nl = Zi(
  (e, t) => {
    const { fontSize: r = 12, fontFamily: i = "Arial", fontWeight: n = 400 } = t;
    if (!e)
      return { width: 0, height: 0 };
    const [, a] = Oa(r), s = ["sans-serif", i], o = e.split(Qr.lineBreakRegex), l = [], c = ht("body");
    if (!c.remove)
      return { width: 0, height: 0, lineHeight: 0 };
    const h = c.append("svg");
    for (const f of s) {
      let d = 0;
      const g = { width: 0, height: 0, lineHeight: 0 };
      for (const m of o) {
        const y = ek();
        y.text = m || Yw;
        const x = rk(h, y).style("font-size", a).style("font-weight", n).style("font-family", f), b = (x._groups || x)[0][0].getBBox();
        if (b.width === 0 && b.height === 0)
          throw new Error("svg element not in render tree");
        g.width = Math.round(Math.max(g.width, b.width)), d = Math.round(b.height), g.height += d, g.lineHeight = Math.round(Math.max(g.lineHeight, d));
      }
      l.push(g);
    }
    h.remove();
    const u = isNaN(l[1].height) || isNaN(l[1].width) || isNaN(l[1].lineHeight) || l[0].height > l[1].height && l[0].width > l[1].width && l[0].lineHeight > l[1].lineHeight ? 0 : 1;
    return l[u];
  },
  (e, t) => `${e}${t.fontSize}${t.fontWeight}${t.fontFamily}`
), qr, ak = (qr = class {
  constructor(t = !1, r) {
    this.count = 0, this.count = r ? r.length : 0, this.next = t ? () => this.count++ : () => Date.now();
  }
}, p(qr, "InitIDGenerator"), qr), gn, sk = /* @__PURE__ */ p(function(e) {
  return gn = gn || document.createElement("div"), e = escape(e).replace(/%26/g, "&").replace(/%23/g, "#").replace(/%3B/g, ";"), gn.innerHTML = e, unescape(gn.textContent);
}, "entityDecode");
function al(e) {
  return "str" in e;
}
p(al, "isDetailedError");
var ok = /* @__PURE__ */ p((e, t, r, i) => {
  if (!i)
    return;
  const n = e.node()?.getBBox();
  n && e.append("text").text(i).attr("text-anchor", "middle").attr("x", n.x + n.width / 2).attr("y", -r).attr("class", t);
}, "insertTitle"), Oa = /* @__PURE__ */ p((e) => {
  if (typeof e == "number")
    return [e, e + "px"];
  const t = parseInt(e ?? "", 10);
  return Number.isNaN(t) ? [void 0, void 0] : e === String(t) ? [t, e + "px"] : [t, e];
}, "parseFontSize");
function sl(e, t) {
  return jw({}, e, t);
}
p(sl, "cleanAndMerge");
var ce = {
  assignWithDepth: St,
  wrapLabel: ik,
  calculateTextHeight: Yd,
  calculateTextWidth: Oe,
  calculateTextDimensions: nl,
  cleanAndMerge: sl,
  detectInit: Xw,
  detectDirective: Pd,
  isSubstringInArray: Zw,
  interpolateToCurve: el,
  calcLabelPosition: Wd,
  calcCardinalityPosition: Qw,
  calcTerminalLabelPosition: qd,
  formatUrl: Nd,
  getStylesFromArray: Hd,
  generateId: Jw,
  random: tk,
  runFunc: Kw,
  entityDecode: sk,
  insertTitle: ok,
  isLabelCoordinateInPath: Ud,
  parseFontSize: Oa,
  InitIDGenerator: ak
}, lk = /* @__PURE__ */ p(function(e) {
  let t = e;
  return t = t.replace(/style.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/classDef.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/#\w+;/g, function(r) {
    const i = r.substring(1, r.length - 1);
    return /^\+?\d+$/.test(i) ? "ﬂ°°" + i + "¶ß" : "ﬂ°" + i + "¶ß";
  }), t;
}, "encodeEntities"), Cr = /* @__PURE__ */ p(function(e) {
  return e.replace(/ﬂ°°/g, "&#").replace(/ﬂ°/g, "&").replace(/¶ß/g, ";");
}, "decodeEntities"), oL = /* @__PURE__ */ p((e, t, {
  counter: r = 0,
  prefix: i,
  suffix: n
}, a) => a || `${i ? `${i}_` : ""}${e}_${t}_${r}${n ? `_${n}` : ""}`, "getEdgeId");
function Rt(e) {
  return e ?? null;
}
p(Rt, "handleUndefinedAttr");
function Ud(e, t) {
  const r = Math.round(e.x), i = Math.round(e.y), n = t.replace(
    /(\d+\.\d+)/g,
    (a) => Math.round(parseFloat(a)).toString()
  );
  return n.includes(r.toString()) || n.includes(i.toString());
}
p(Ud, "isLabelCoordinateInPath");
const ck = Object.freeze({
  left: 0,
  top: 0,
  width: 16,
  height: 16
}), la = Object.freeze({
  rotate: 0,
  vFlip: !1,
  hFlip: !1
}), Gd = Object.freeze({
  ...ck,
  ...la
}), hk = Object.freeze({
  ...Gd,
  body: "",
  hidden: !1
}), uk = Object.freeze({
  width: null,
  height: null
}), fk = Object.freeze({
  ...uk,
  ...la
}), dk = (e, t, r, i = "") => {
  const n = e.split(":");
  if (e.slice(0, 1) === "@") {
    if (n.length < 2 || n.length > 3) return null;
    i = n.shift().slice(1);
  }
  if (n.length > 3 || !n.length) return null;
  if (n.length > 1) {
    const o = n.pop(), l = n.pop(), c = {
      provider: n.length > 0 ? n[0] : i,
      prefix: l,
      name: o
    };
    return ps(c) ? c : null;
  }
  const a = n[0], s = a.split("-");
  if (s.length > 1) {
    const o = {
      provider: i,
      prefix: s.shift(),
      name: s.join("-")
    };
    return ps(o) ? o : null;
  }
  if (r && i === "") {
    const o = {
      provider: i,
      prefix: "",
      name: a
    };
    return ps(o, r) ? o : null;
  }
  return null;
}, ps = (e, t) => e ? !!((t && e.prefix === "" || e.prefix) && e.name) : !1;
function pk(e, t) {
  const r = {};
  !e.hFlip != !t.hFlip && (r.hFlip = !0), !e.vFlip != !t.vFlip && (r.vFlip = !0);
  const i = ((e.rotate || 0) + (t.rotate || 0)) % 4;
  return i && (r.rotate = i), r;
}
function Yc(e, t) {
  const r = pk(e, t);
  for (const i in hk) i in la ? i in e && !(i in r) && (r[i] = la[i]) : i in t ? r[i] = t[i] : i in e && (r[i] = e[i]);
  return r;
}
function gk(e, t) {
  const r = e.icons, i = e.aliases || /* @__PURE__ */ Object.create(null), n = /* @__PURE__ */ Object.create(null);
  function a(s) {
    if (r[s]) return n[s] = [];
    if (!(s in n)) {
      n[s] = null;
      const o = i[s] && i[s].parent, l = o && a(o);
      l && (n[s] = [o].concat(l));
    }
    return n[s];
  }
  return (t || Object.keys(r).concat(Object.keys(i))).forEach(a), n;
}
function Uc(e, t, r) {
  const i = e.icons, n = e.aliases || /* @__PURE__ */ Object.create(null);
  let a = {};
  function s(o) {
    a = Yc(i[o] || n[o], a);
  }
  return s(t), r.forEach(s), Yc(e, a);
}
function mk(e, t) {
  if (e.icons[t]) return Uc(e, t, []);
  const r = gk(e, [t])[t];
  return r ? Uc(e, t, r) : null;
}
const yk = /(-?[0-9.]*[0-9]+[0-9.]*)/g, xk = /^-?[0-9.]*[0-9]+[0-9.]*$/g;
function Gc(e, t, r) {
  if (t === 1) return e;
  if (r = r || 100, typeof e == "number") return Math.ceil(e * t * r) / r;
  if (typeof e != "string") return e;
  const i = e.split(yk);
  if (i === null || !i.length) return e;
  const n = [];
  let a = i.shift(), s = xk.test(a);
  for (; ; ) {
    if (s) {
      const o = parseFloat(a);
      isNaN(o) ? n.push(a) : n.push(Math.ceil(o * t * r) / r);
    } else n.push(a);
    if (a = i.shift(), a === void 0) return n.join("");
    s = !s;
  }
}
function bk(e, t = "defs") {
  let r = "";
  const i = e.indexOf("<" + t);
  for (; i >= 0; ) {
    const n = e.indexOf(">", i), a = e.indexOf("</" + t);
    if (n === -1 || a === -1) break;
    const s = e.indexOf(">", a);
    if (s === -1) break;
    r += e.slice(n + 1, a).trim(), e = e.slice(0, i).trim() + e.slice(s + 1);
  }
  return {
    defs: r,
    content: e
  };
}
function Ck(e, t) {
  return e ? "<defs>" + e + "</defs>" + t : t;
}
function _k(e, t, r) {
  const i = bk(e);
  return Ck(i.defs, t + i.content + r);
}
const wk = (e) => e === "unset" || e === "undefined" || e === "none";
function kk(e, t) {
  const r = {
    ...Gd,
    ...e
  }, i = {
    ...fk,
    ...t
  }, n = {
    left: r.left,
    top: r.top,
    width: r.width,
    height: r.height
  };
  let a = r.body;
  [r, i].forEach((m) => {
    const y = [], x = m.hFlip, b = m.vFlip;
    let C = m.rotate;
    x ? b ? C += 2 : (y.push("translate(" + (n.width + n.left).toString() + " " + (0 - n.top).toString() + ")"), y.push("scale(-1 1)"), n.top = n.left = 0) : b && (y.push("translate(" + (0 - n.left).toString() + " " + (n.height + n.top).toString() + ")"), y.push("scale(1 -1)"), n.top = n.left = 0);
    let k;
    switch (C < 0 && (C -= Math.floor(C / 4) * 4), C = C % 4, C) {
      case 1:
        k = n.height / 2 + n.top, y.unshift("rotate(90 " + k.toString() + " " + k.toString() + ")");
        break;
      case 2:
        y.unshift("rotate(180 " + (n.width / 2 + n.left).toString() + " " + (n.height / 2 + n.top).toString() + ")");
        break;
      case 3:
        k = n.width / 2 + n.left, y.unshift("rotate(-90 " + k.toString() + " " + k.toString() + ")");
        break;
    }
    C % 2 === 1 && (n.left !== n.top && (k = n.left, n.left = n.top, n.top = k), n.width !== n.height && (k = n.width, n.width = n.height, n.height = k)), y.length && (a = _k(a, '<g transform="' + y.join(" ") + '">', "</g>"));
  });
  const s = i.width, o = i.height, l = n.width, c = n.height;
  let h, u;
  s === null ? (u = o === null ? "1em" : o === "auto" ? c : o, h = Gc(u, l / c)) : (h = s === "auto" ? l : s, u = o === null ? Gc(h, c / l) : o === "auto" ? c : o);
  const f = {}, d = (m, y) => {
    wk(y) || (f[m] = y.toString());
  };
  d("width", h), d("height", u);
  const g = [
    n.left,
    n.top,
    l,
    c
  ];
  return f.viewBox = g.join(" "), {
    attributes: f,
    viewBox: g,
    body: a
  };
}
const vk = /\sid="(\S+)"/g, Xc = /* @__PURE__ */ new Map();
function Sk(e) {
  e = e.replace(/[0-9]+$/, "") || "a";
  const t = Xc.get(e) || 0;
  return Xc.set(e, t + 1), t ? `${e}${t}` : e;
}
function Tk(e) {
  const t = [];
  let r;
  for (; r = vk.exec(e); ) t.push(r[1]);
  if (!t.length) return e;
  const i = "suffix" + (Math.random() * 16777216 | Date.now()).toString(16);
  return t.forEach((n) => {
    const a = Sk(n), s = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    e = e.replace(new RegExp('([#;"])(' + s + ')([")]|\\.[a-z])', "g"), "$1" + a + i + "$3");
  }), e = e.replace(new RegExp(i, "g"), ""), e;
}
function Bk(e, t) {
  let r = e.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
  for (const i in t) r += " " + i + '="' + t[i] + '"';
  return '<svg xmlns="http://www.w3.org/2000/svg"' + r + ">" + e + "</svg>";
}
function ol() {
  return { async: !1, breaks: !1, extensions: null, gfm: !0, hooks: null, pedantic: !1, renderer: null, silent: !1, tokenizer: null, walkTokens: null };
}
var _r = ol();
function Xd(e) {
  _r = e;
}
var $i = { exec: () => null };
function ut(e, t = "") {
  let r = typeof e == "string" ? e : e.source, i = { replace: (n, a) => {
    let s = typeof a == "string" ? a : a.source;
    return s = s.replace(qt.caret, "$1"), r = r.replace(n, s), i;
  }, getRegex: () => new RegExp(r, t) };
  return i;
}
var Ak = (() => {
  try {
    return !!new RegExp("(?<=1)(?<!1)");
  } catch {
    return !1;
  }
})(), qt = { codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm, outputLinkReplace: /\\([\[\]])/g, indentCodeCompensation: /^(\s+)(?:```)/, beginningSpace: /^\s+/, endingHash: /#$/, startingSpaceChar: /^ /, endingSpaceChar: / $/, nonSpaceChar: /[^ ]/, newLineCharGlobal: /\n/g, tabCharGlobal: /\t/g, multipleSpaceGlobal: /\s+/g, blankLine: /^[ \t]*$/, doubleBlankLine: /\n[ \t]*\n[ \t]*$/, blockquoteStart: /^ {0,3}>/, blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g, blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm, listReplaceTabs: /^\t+/, listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g, listIsTask: /^\[[ xX]\] /, listReplaceTask: /^\[[ xX]\] +/, anyLine: /\n.*\n/, hrefBrackets: /^<(.*)>$/, tableDelimiter: /[:|]/, tableAlignChars: /^\||\| *$/g, tableRowBlankLine: /\n[ \t]*$/, tableAlignRight: /^ *-+: *$/, tableAlignCenter: /^ *:-+: *$/, tableAlignLeft: /^ *:-+ *$/, startATag: /^<a /i, endATag: /^<\/a>/i, startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i, endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i, startAngleBracket: /^</, endAngleBracket: />$/, pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/, unicodeAlphaNumeric: /[\p{L}\p{N}]/u, escapeTest: /[&<>"']/, escapeReplace: /[&<>"']/g, escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g, unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig, caret: /(^|[^\[])\^/g, percentDecode: /%25/g, findPipe: /\|/g, splitPipe: / \|/, slashPipe: /\\\|/g, carriageReturn: /\r\n|\r/g, spaceLine: /^ +$/gm, notSpaceStart: /^\S*/, endingNewline: /\n$/, listItemRegex: (e) => new RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`), nextBulletRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), hrRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), fencesBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:\`\`\`|~~~)`), headingBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}#`), htmlBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}<(?:[a-z].*>|!--)`, "i") }, Lk = /^(?:[ \t]*(?:\n|$))+/, Mk = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, $k = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Qi = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Ek = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, ll = /(?:[*+-]|\d{1,9}[.)])/, Vd = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, Zd = ut(Vd).replace(/bull/g, ll).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), Fk = ut(Vd).replace(/bull/g, ll).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), cl = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Dk = /^[^\n]+/, hl = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/, Ok = ut(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", hl).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Rk = ut(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, ll).getRegex(), Ra = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", ul = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Ik = ut("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", ul).replace("tag", Ra).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Kd = ut(cl).replace("hr", Qi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ra).getRegex(), Pk = ut(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Kd).getRegex(), fl = { blockquote: Pk, code: Mk, def: Ok, fences: $k, heading: Ek, hr: Qi, html: Ik, lheading: Zd, list: Rk, newline: Lk, paragraph: Kd, table: $i, text: Dk }, Vc = ut("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Qi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ra).getRegex(), Nk = { ...fl, lheading: Fk, table: Vc, paragraph: ut(cl).replace("hr", Qi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Vc).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ra).getRegex() }, zk = { ...fl, html: ut(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", ul).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(), def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/, heading: /^(#{1,6})(.*)(?:\n+|$)/, fences: $i, lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/, paragraph: ut(cl).replace("hr", Qi).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Zd).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex() }, Wk = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, qk = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Qd = /^( {2,}|\\)\n(?!\s*$)/, Hk = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Ia = /[\p{P}\p{S}]/u, dl = /[\s\p{P}\p{S}]/u, Jd = /[^\s\p{P}\p{S}]/u, jk = ut(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, dl).getRegex(), tp = /(?!~)[\p{P}\p{S}]/u, Yk = /(?!~)[\s\p{P}\p{S}]/u, Uk = /(?:[^\s\p{P}\p{S}]|~)/u, Gk = ut(/link|precode-code|html/, "g").replace("link", /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-", Ak ? "(?<!`)()" : "(^^|[^`])").replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/).replace("html", /<(?! )[^<>]*?>/).getRegex(), ep = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, Xk = ut(ep, "u").replace(/punct/g, Ia).getRegex(), Vk = ut(ep, "u").replace(/punct/g, tp).getRegex(), rp = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", Zk = ut(rp, "gu").replace(/notPunctSpace/g, Jd).replace(/punctSpace/g, dl).replace(/punct/g, Ia).getRegex(), Kk = ut(rp, "gu").replace(/notPunctSpace/g, Uk).replace(/punctSpace/g, Yk).replace(/punct/g, tp).getRegex(), Qk = ut("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, Jd).replace(/punctSpace/g, dl).replace(/punct/g, Ia).getRegex(), Jk = ut(/\\(punct)/, "gu").replace(/punct/g, Ia).getRegex(), tv = ut(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), ev = ut(ul).replace("(?:-->|$)", "-->").getRegex(), rv = ut("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", ev).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), ca = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+[^`]*?`+(?!`)|[^\[\]\\`])*?/, iv = ut(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", ca).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ip = ut(/^!?\[(label)\]\[(ref)\]/).replace("label", ca).replace("ref", hl).getRegex(), np = ut(/^!?\[(ref)\](?:\[\])?/).replace("ref", hl).getRegex(), nv = ut("reflink|nolink(?!\\()", "g").replace("reflink", ip).replace("nolink", np).getRegex(), Zc = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/, pl = { _backpedal: $i, anyPunctuation: Jk, autolink: tv, blockSkip: Gk, br: Qd, code: qk, del: $i, emStrongLDelim: Xk, emStrongRDelimAst: Zk, emStrongRDelimUnd: Qk, escape: Wk, link: iv, nolink: np, punctuation: jk, reflink: ip, reflinkSearch: nv, tag: rv, text: Hk, url: $i }, av = { ...pl, link: ut(/^!?\[(label)\]\((.*?)\)/).replace("label", ca).getRegex(), reflink: ut(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", ca).getRegex() }, io = { ...pl, emStrongRDelimAst: Kk, emStrongLDelim: Vk, url: ut(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol", Zc).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(), _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/, del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/, text: ut(/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol", Zc).getRegex() }, sv = { ...io, br: ut(Qd).replace("{2,}", "*").getRegex(), text: ut(io.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex() }, mn = { normal: fl, gfm: Nk, pedantic: zk }, di = { normal: pl, gfm: io, breaks: sv, pedantic: av }, ov = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }, Kc = (e) => ov[e];
function ye(e, t) {
  if (t) {
    if (qt.escapeTest.test(e)) return e.replace(qt.escapeReplace, Kc);
  } else if (qt.escapeTestNoEncode.test(e)) return e.replace(qt.escapeReplaceNoEncode, Kc);
  return e;
}
function Qc(e) {
  try {
    e = encodeURI(e).replace(qt.percentDecode, "%");
  } catch {
    return null;
  }
  return e;
}
function Jc(e, t) {
  let r = e.replace(qt.findPipe, (a, s, o) => {
    let l = !1, c = s;
    for (; --c >= 0 && o[c] === "\\"; ) l = !l;
    return l ? "|" : " |";
  }), i = r.split(qt.splitPipe), n = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !i.at(-1)?.trim() && i.pop(), t) if (i.length > t) i.splice(t);
  else for (; i.length < t; ) i.push("");
  for (; n < i.length; n++) i[n] = i[n].trim().replace(qt.slashPipe, "|");
  return i;
}
function pi(e, t, r) {
  let i = e.length;
  if (i === 0) return "";
  let n = 0;
  for (; n < i && e.charAt(i - n - 1) === t; )
    n++;
  return e.slice(0, i - n);
}
function lv(e, t) {
  if (e.indexOf(t[1]) === -1) return -1;
  let r = 0;
  for (let i = 0; i < e.length; i++) if (e[i] === "\\") i++;
  else if (e[i] === t[0]) r++;
  else if (e[i] === t[1] && (r--, r < 0)) return i;
  return r > 0 ? -2 : -1;
}
function th(e, t, r, i, n) {
  let a = t.href, s = t.title || null, o = e[1].replace(n.other.outputLinkReplace, "$1");
  i.state.inLink = !0;
  let l = { type: e[0].charAt(0) === "!" ? "image" : "link", raw: r, href: a, title: s, text: o, tokens: i.inlineTokens(o) };
  return i.state.inLink = !1, l;
}
function cv(e, t, r) {
  let i = e.match(r.other.indentCodeCompensation);
  if (i === null) return t;
  let n = i[1];
  return t.split(`
`).map((a) => {
    let s = a.match(r.other.beginningSpace);
    if (s === null) return a;
    let [o] = s;
    return o.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
var ha = class {
  options;
  rules;
  lexer;
  constructor(t) {
    this.options = t || _r;
  }
  space(t) {
    let r = this.rules.block.newline.exec(t);
    if (r && r[0].length > 0) return { type: "space", raw: r[0] };
  }
  code(t) {
    let r = this.rules.block.code.exec(t);
    if (r) {
      let i = r[0].replace(this.rules.other.codeRemoveIndent, "");
      return { type: "code", raw: r[0], codeBlockStyle: "indented", text: this.options.pedantic ? i : pi(i, `
`) };
    }
  }
  fences(t) {
    let r = this.rules.block.fences.exec(t);
    if (r) {
      let i = r[0], n = cv(i, r[3] || "", this.rules);
      return { type: "code", raw: i, lang: r[2] ? r[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : r[2], text: n };
    }
  }
  heading(t) {
    let r = this.rules.block.heading.exec(t);
    if (r) {
      let i = r[2].trim();
      if (this.rules.other.endingHash.test(i)) {
        let n = pi(i, "#");
        (this.options.pedantic || !n || this.rules.other.endingSpaceChar.test(n)) && (i = n.trim());
      }
      return { type: "heading", raw: r[0], depth: r[1].length, text: i, tokens: this.lexer.inline(i) };
    }
  }
  hr(t) {
    let r = this.rules.block.hr.exec(t);
    if (r) return { type: "hr", raw: pi(r[0], `
`) };
  }
  blockquote(t) {
    let r = this.rules.block.blockquote.exec(t);
    if (r) {
      let i = pi(r[0], `
`).split(`
`), n = "", a = "", s = [];
      for (; i.length > 0; ) {
        let o = !1, l = [], c;
        for (c = 0; c < i.length; c++) if (this.rules.other.blockquoteStart.test(i[c])) l.push(i[c]), o = !0;
        else if (!o) l.push(i[c]);
        else break;
        i = i.slice(c);
        let h = l.join(`
`), u = h.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        n = n ? `${n}
${h}` : h, a = a ? `${a}
${u}` : u;
        let f = this.lexer.state.top;
        if (this.lexer.state.top = !0, this.lexer.blockTokens(u, s, !0), this.lexer.state.top = f, i.length === 0) break;
        let d = s.at(-1);
        if (d?.type === "code") break;
        if (d?.type === "blockquote") {
          let g = d, m = g.raw + `
` + i.join(`
`), y = this.blockquote(m);
          s[s.length - 1] = y, n = n.substring(0, n.length - g.raw.length) + y.raw, a = a.substring(0, a.length - g.text.length) + y.text;
          break;
        } else if (d?.type === "list") {
          let g = d, m = g.raw + `
` + i.join(`
`), y = this.list(m);
          s[s.length - 1] = y, n = n.substring(0, n.length - d.raw.length) + y.raw, a = a.substring(0, a.length - g.raw.length) + y.raw, i = m.substring(s.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return { type: "blockquote", raw: n, tokens: s, text: a };
    }
  }
  list(t) {
    let r = this.rules.block.list.exec(t);
    if (r) {
      let i = r[1].trim(), n = i.length > 1, a = { type: "list", raw: "", ordered: n, start: n ? +i.slice(0, -1) : "", loose: !1, items: [] };
      i = n ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = n ? i : "[*+-]");
      let s = this.rules.other.listItemRegex(i), o = !1;
      for (; t; ) {
        let c = !1, h = "", u = "";
        if (!(r = s.exec(t)) || this.rules.block.hr.test(t)) break;
        h = r[0], t = t.substring(h.length);
        let f = r[2].split(`
`, 1)[0].replace(this.rules.other.listReplaceTabs, (b) => " ".repeat(3 * b.length)), d = t.split(`
`, 1)[0], g = !f.trim(), m = 0;
        if (this.options.pedantic ? (m = 2, u = f.trimStart()) : g ? m = r[1].length + 1 : (m = r[2].search(this.rules.other.nonSpaceChar), m = m > 4 ? 1 : m, u = f.slice(m), m += r[1].length), g && this.rules.other.blankLine.test(d) && (h += d + `
`, t = t.substring(d.length + 1), c = !0), !c) {
          let b = this.rules.other.nextBulletRegex(m), C = this.rules.other.hrRegex(m), k = this.rules.other.fencesBeginRegex(m), w = this.rules.other.headingBeginRegex(m), A = this.rules.other.htmlBeginRegex(m);
          for (; t; ) {
            let S = t.split(`
`, 1)[0], D;
            if (d = S, this.options.pedantic ? (d = d.replace(this.rules.other.listReplaceNesting, "  "), D = d) : D = d.replace(this.rules.other.tabCharGlobal, "    "), k.test(d) || w.test(d) || A.test(d) || b.test(d) || C.test(d)) break;
            if (D.search(this.rules.other.nonSpaceChar) >= m || !d.trim()) u += `
` + D.slice(m);
            else {
              if (g || f.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || k.test(f) || w.test(f) || C.test(f)) break;
              u += `
` + d;
            }
            !g && !d.trim() && (g = !0), h += S + `
`, t = t.substring(S.length + 1), f = D.slice(m);
          }
        }
        a.loose || (o ? a.loose = !0 : this.rules.other.doubleBlankLine.test(h) && (o = !0));
        let y = null, x;
        this.options.gfm && (y = this.rules.other.listIsTask.exec(u), y && (x = y[0] !== "[ ] ", u = u.replace(this.rules.other.listReplaceTask, ""))), a.items.push({ type: "list_item", raw: h, task: !!y, checked: x, loose: !1, text: u, tokens: [] }), a.raw += h;
      }
      let l = a.items.at(-1);
      if (l) l.raw = l.raw.trimEnd(), l.text = l.text.trimEnd();
      else return;
      a.raw = a.raw.trimEnd();
      for (let c = 0; c < a.items.length; c++) if (this.lexer.state.top = !1, a.items[c].tokens = this.lexer.blockTokens(a.items[c].text, []), !a.loose) {
        let h = a.items[c].tokens.filter((f) => f.type === "space"), u = h.length > 0 && h.some((f) => this.rules.other.anyLine.test(f.raw));
        a.loose = u;
      }
      if (a.loose) for (let c = 0; c < a.items.length; c++) a.items[c].loose = !0;
      return a;
    }
  }
  html(t) {
    let r = this.rules.block.html.exec(t);
    if (r) return { type: "html", block: !0, raw: r[0], pre: r[1] === "pre" || r[1] === "script" || r[1] === "style", text: r[0] };
  }
  def(t) {
    let r = this.rules.block.def.exec(t);
    if (r) {
      let i = r[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), n = r[2] ? r[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = r[3] ? r[3].substring(1, r[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : r[3];
      return { type: "def", tag: i, raw: r[0], href: n, title: a };
    }
  }
  table(t) {
    let r = this.rules.block.table.exec(t);
    if (!r || !this.rules.other.tableDelimiter.test(r[2])) return;
    let i = Jc(r[1]), n = r[2].replace(this.rules.other.tableAlignChars, "").split("|"), a = r[3]?.trim() ? r[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], s = { type: "table", raw: r[0], header: [], align: [], rows: [] };
    if (i.length === n.length) {
      for (let o of n) this.rules.other.tableAlignRight.test(o) ? s.align.push("right") : this.rules.other.tableAlignCenter.test(o) ? s.align.push("center") : this.rules.other.tableAlignLeft.test(o) ? s.align.push("left") : s.align.push(null);
      for (let o = 0; o < i.length; o++) s.header.push({ text: i[o], tokens: this.lexer.inline(i[o]), header: !0, align: s.align[o] });
      for (let o of a) s.rows.push(Jc(o, s.header.length).map((l, c) => ({ text: l, tokens: this.lexer.inline(l), header: !1, align: s.align[c] })));
      return s;
    }
  }
  lheading(t) {
    let r = this.rules.block.lheading.exec(t);
    if (r) return { type: "heading", raw: r[0], depth: r[2].charAt(0) === "=" ? 1 : 2, text: r[1], tokens: this.lexer.inline(r[1]) };
  }
  paragraph(t) {
    let r = this.rules.block.paragraph.exec(t);
    if (r) {
      let i = r[1].charAt(r[1].length - 1) === `
` ? r[1].slice(0, -1) : r[1];
      return { type: "paragraph", raw: r[0], text: i, tokens: this.lexer.inline(i) };
    }
  }
  text(t) {
    let r = this.rules.block.text.exec(t);
    if (r) return { type: "text", raw: r[0], text: r[0], tokens: this.lexer.inline(r[0]) };
  }
  escape(t) {
    let r = this.rules.inline.escape.exec(t);
    if (r) return { type: "escape", raw: r[0], text: r[1] };
  }
  tag(t) {
    let r = this.rules.inline.tag.exec(t);
    if (r) return !this.lexer.state.inLink && this.rules.other.startATag.test(r[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(r[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(r[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(r[0]) && (this.lexer.state.inRawBlock = !1), { type: "html", raw: r[0], inLink: this.lexer.state.inLink, inRawBlock: this.lexer.state.inRawBlock, block: !1, text: r[0] };
  }
  link(t) {
    let r = this.rules.inline.link.exec(t);
    if (r) {
      let i = r[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(i)) {
        if (!this.rules.other.endAngleBracket.test(i)) return;
        let s = pi(i.slice(0, -1), "\\");
        if ((i.length - s.length) % 2 === 0) return;
      } else {
        let s = lv(r[2], "()");
        if (s === -2) return;
        if (s > -1) {
          let o = (r[0].indexOf("!") === 0 ? 5 : 4) + r[1].length + s;
          r[2] = r[2].substring(0, s), r[0] = r[0].substring(0, o).trim(), r[3] = "";
        }
      }
      let n = r[2], a = "";
      if (this.options.pedantic) {
        let s = this.rules.other.pedanticHrefTitle.exec(n);
        s && (n = s[1], a = s[3]);
      } else a = r[3] ? r[3].slice(1, -1) : "";
      return n = n.trim(), this.rules.other.startAngleBracket.test(n) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(i) ? n = n.slice(1) : n = n.slice(1, -1)), th(r, { href: n && n.replace(this.rules.inline.anyPunctuation, "$1"), title: a && a.replace(this.rules.inline.anyPunctuation, "$1") }, r[0], this.lexer, this.rules);
    }
  }
  reflink(t, r) {
    let i;
    if ((i = this.rules.inline.reflink.exec(t)) || (i = this.rules.inline.nolink.exec(t))) {
      let n = (i[2] || i[1]).replace(this.rules.other.multipleSpaceGlobal, " "), a = r[n.toLowerCase()];
      if (!a) {
        let s = i[0].charAt(0);
        return { type: "text", raw: s, text: s };
      }
      return th(i, a, i[0], this.lexer, this.rules);
    }
  }
  emStrong(t, r, i = "") {
    let n = this.rules.inline.emStrongLDelim.exec(t);
    if (!(!n || n[3] && i.match(this.rules.other.unicodeAlphaNumeric)) && (!(n[1] || n[2]) || !i || this.rules.inline.punctuation.exec(i))) {
      let a = [...n[0]].length - 1, s, o, l = a, c = 0, h = n[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (h.lastIndex = 0, r = r.slice(-1 * t.length + a); (n = h.exec(r)) != null; ) {
        if (s = n[1] || n[2] || n[3] || n[4] || n[5] || n[6], !s) continue;
        if (o = [...s].length, n[3] || n[4]) {
          l += o;
          continue;
        } else if ((n[5] || n[6]) && a % 3 && !((a + o) % 3)) {
          c += o;
          continue;
        }
        if (l -= o, l > 0) continue;
        o = Math.min(o, o + l + c);
        let u = [...n[0]][0].length, f = t.slice(0, a + n.index + u + o);
        if (Math.min(a, o) % 2) {
          let g = f.slice(1, -1);
          return { type: "em", raw: f, text: g, tokens: this.lexer.inlineTokens(g) };
        }
        let d = f.slice(2, -2);
        return { type: "strong", raw: f, text: d, tokens: this.lexer.inlineTokens(d) };
      }
    }
  }
  codespan(t) {
    let r = this.rules.inline.code.exec(t);
    if (r) {
      let i = r[2].replace(this.rules.other.newLineCharGlobal, " "), n = this.rules.other.nonSpaceChar.test(i), a = this.rules.other.startingSpaceChar.test(i) && this.rules.other.endingSpaceChar.test(i);
      return n && a && (i = i.substring(1, i.length - 1)), { type: "codespan", raw: r[0], text: i };
    }
  }
  br(t) {
    let r = this.rules.inline.br.exec(t);
    if (r) return { type: "br", raw: r[0] };
  }
  del(t) {
    let r = this.rules.inline.del.exec(t);
    if (r) return { type: "del", raw: r[0], text: r[2], tokens: this.lexer.inlineTokens(r[2]) };
  }
  autolink(t) {
    let r = this.rules.inline.autolink.exec(t);
    if (r) {
      let i, n;
      return r[2] === "@" ? (i = r[1], n = "mailto:" + i) : (i = r[1], n = i), { type: "link", raw: r[0], text: i, href: n, tokens: [{ type: "text", raw: i, text: i }] };
    }
  }
  url(t) {
    let r;
    if (r = this.rules.inline.url.exec(t)) {
      let i, n;
      if (r[2] === "@") i = r[0], n = "mailto:" + i;
      else {
        let a;
        do
          a = r[0], r[0] = this.rules.inline._backpedal.exec(r[0])?.[0] ?? "";
        while (a !== r[0]);
        i = r[0], r[1] === "www." ? n = "http://" + r[0] : n = r[0];
      }
      return { type: "link", raw: r[0], text: i, href: n, tokens: [{ type: "text", raw: i, text: i }] };
    }
  }
  inlineText(t) {
    let r = this.rules.inline.text.exec(t);
    if (r) {
      let i = this.lexer.state.inRawBlock;
      return { type: "text", raw: r[0], text: r[0], escaped: i };
    }
  }
}, se = class no {
  tokens;
  options;
  state;
  tokenizer;
  inlineQueue;
  constructor(t) {
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || _r, this.options.tokenizer = this.options.tokenizer || new ha(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = { inLink: !1, inRawBlock: !1, top: !0 };
    let r = { other: qt, block: mn.normal, inline: di.normal };
    this.options.pedantic ? (r.block = mn.pedantic, r.inline = di.pedantic) : this.options.gfm && (r.block = mn.gfm, this.options.breaks ? r.inline = di.breaks : r.inline = di.gfm), this.tokenizer.rules = r;
  }
  static get rules() {
    return { block: mn, inline: di };
  }
  static lex(t, r) {
    return new no(r).lex(t);
  }
  static lexInline(t, r) {
    return new no(r).inlineTokens(t);
  }
  lex(t) {
    t = t.replace(qt.carriageReturn, `
`), this.blockTokens(t, this.tokens);
    for (let r = 0; r < this.inlineQueue.length; r++) {
      let i = this.inlineQueue[r];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, r = [], i = !1) {
    for (this.options.pedantic && (t = t.replace(qt.tabCharGlobal, "    ").replace(qt.spaceLine, "")); t; ) {
      let n;
      if (this.options.extensions?.block?.some((s) => (n = s.call({ lexer: this }, t, r)) ? (t = t.substring(n.raw.length), r.push(n), !0) : !1)) continue;
      if (n = this.tokenizer.space(t)) {
        t = t.substring(n.raw.length);
        let s = r.at(-1);
        n.raw.length === 1 && s !== void 0 ? s.raw += `
` : r.push(n);
        continue;
      }
      if (n = this.tokenizer.code(t)) {
        t = t.substring(n.raw.length);
        let s = r.at(-1);
        s?.type === "paragraph" || s?.type === "text" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + n.raw, s.text += `
` + n.text, this.inlineQueue.at(-1).src = s.text) : r.push(n);
        continue;
      }
      if (n = this.tokenizer.fences(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.heading(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.hr(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.blockquote(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.list(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.html(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.def(t)) {
        t = t.substring(n.raw.length);
        let s = r.at(-1);
        s?.type === "paragraph" || s?.type === "text" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + n.raw, s.text += `
` + n.raw, this.inlineQueue.at(-1).src = s.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = { href: n.href, title: n.title }, r.push(n));
        continue;
      }
      if (n = this.tokenizer.table(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.lheading(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      let a = t;
      if (this.options.extensions?.startBlock) {
        let s = 1 / 0, o = t.slice(1), l;
        this.options.extensions.startBlock.forEach((c) => {
          l = c.call({ lexer: this }, o), typeof l == "number" && l >= 0 && (s = Math.min(s, l));
        }), s < 1 / 0 && s >= 0 && (a = t.substring(0, s + 1));
      }
      if (this.state.top && (n = this.tokenizer.paragraph(a))) {
        let s = r.at(-1);
        i && s?.type === "paragraph" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + n.raw, s.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = s.text) : r.push(n), i = a.length !== t.length, t = t.substring(n.raw.length);
        continue;
      }
      if (n = this.tokenizer.text(t)) {
        t = t.substring(n.raw.length);
        let s = r.at(-1);
        s?.type === "text" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + n.raw, s.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = s.text) : r.push(n);
        continue;
      }
      if (t) {
        let s = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(s);
          break;
        } else throw new Error(s);
      }
    }
    return this.state.top = !0, r;
  }
  inline(t, r = []) {
    return this.inlineQueue.push({ src: t, tokens: r }), r;
  }
  inlineTokens(t, r = []) {
    let i = t, n = null;
    if (this.tokens.links) {
      let l = Object.keys(this.tokens.links);
      if (l.length > 0) for (; (n = this.tokenizer.rules.inline.reflinkSearch.exec(i)) != null; ) l.includes(n[0].slice(n[0].lastIndexOf("[") + 1, -1)) && (i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (n = this.tokenizer.rules.inline.anyPunctuation.exec(i)) != null; ) i = i.slice(0, n.index) + "++" + i.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    let a;
    for (; (n = this.tokenizer.rules.inline.blockSkip.exec(i)) != null; ) a = n[2] ? n[2].length : 0, i = i.slice(0, n.index + a) + "[" + "a".repeat(n[0].length - a - 2) + "]" + i.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    i = this.options.hooks?.emStrongMask?.call({ lexer: this }, i) ?? i;
    let s = !1, o = "";
    for (; t; ) {
      s || (o = ""), s = !1;
      let l;
      if (this.options.extensions?.inline?.some((h) => (l = h.call({ lexer: this }, t, r)) ? (t = t.substring(l.raw.length), r.push(l), !0) : !1)) continue;
      if (l = this.tokenizer.escape(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.tag(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.link(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.reflink(t, this.tokens.links)) {
        t = t.substring(l.raw.length);
        let h = r.at(-1);
        l.type === "text" && h?.type === "text" ? (h.raw += l.raw, h.text += l.text) : r.push(l);
        continue;
      }
      if (l = this.tokenizer.emStrong(t, i, o)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.codespan(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.br(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.del(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.autolink(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (!this.state.inLink && (l = this.tokenizer.url(t))) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      let c = t;
      if (this.options.extensions?.startInline) {
        let h = 1 / 0, u = t.slice(1), f;
        this.options.extensions.startInline.forEach((d) => {
          f = d.call({ lexer: this }, u), typeof f == "number" && f >= 0 && (h = Math.min(h, f));
        }), h < 1 / 0 && h >= 0 && (c = t.substring(0, h + 1));
      }
      if (l = this.tokenizer.inlineText(c)) {
        t = t.substring(l.raw.length), l.raw.slice(-1) !== "_" && (o = l.raw.slice(-1)), s = !0;
        let h = r.at(-1);
        h?.type === "text" ? (h.raw += l.raw, h.text += l.text) : r.push(l);
        continue;
      }
      if (t) {
        let h = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(h);
          break;
        } else throw new Error(h);
      }
    }
    return r;
  }
}, ua = class {
  options;
  parser;
  constructor(t) {
    this.options = t || _r;
  }
  space(t) {
    return "";
  }
  code({ text: t, lang: r, escaped: i }) {
    let n = (r || "").match(qt.notSpaceStart)?.[0], a = t.replace(qt.endingNewline, "") + `
`;
    return n ? '<pre><code class="language-' + ye(n) + '">' + (i ? a : ye(a, !0)) + `</code></pre>
` : "<pre><code>" + (i ? a : ye(a, !0)) + `</code></pre>
`;
  }
  blockquote({ tokens: t }) {
    return `<blockquote>
${this.parser.parse(t)}</blockquote>
`;
  }
  html({ text: t }) {
    return t;
  }
  def(t) {
    return "";
  }
  heading({ tokens: t, depth: r }) {
    return `<h${r}>${this.parser.parseInline(t)}</h${r}>
`;
  }
  hr(t) {
    return `<hr>
`;
  }
  list(t) {
    let r = t.ordered, i = t.start, n = "";
    for (let o = 0; o < t.items.length; o++) {
      let l = t.items[o];
      n += this.listitem(l);
    }
    let a = r ? "ol" : "ul", s = r && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + a + s + `>
` + n + "</" + a + `>
`;
  }
  listitem(t) {
    let r = "";
    if (t.task) {
      let i = this.checkbox({ checked: !!t.checked });
      t.loose ? t.tokens[0]?.type === "paragraph" ? (t.tokens[0].text = i + " " + t.tokens[0].text, t.tokens[0].tokens && t.tokens[0].tokens.length > 0 && t.tokens[0].tokens[0].type === "text" && (t.tokens[0].tokens[0].text = i + " " + ye(t.tokens[0].tokens[0].text), t.tokens[0].tokens[0].escaped = !0)) : t.tokens.unshift({ type: "text", raw: i + " ", text: i + " ", escaped: !0 }) : r += i + " ";
    }
    return r += this.parser.parse(t.tokens, !!t.loose), `<li>${r}</li>
`;
  }
  checkbox({ checked: t }) {
    return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens: t }) {
    return `<p>${this.parser.parseInline(t)}</p>
`;
  }
  table(t) {
    let r = "", i = "";
    for (let a = 0; a < t.header.length; a++) i += this.tablecell(t.header[a]);
    r += this.tablerow({ text: i });
    let n = "";
    for (let a = 0; a < t.rows.length; a++) {
      let s = t.rows[a];
      i = "";
      for (let o = 0; o < s.length; o++) i += this.tablecell(s[o]);
      n += this.tablerow({ text: i });
    }
    return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + r + `</thead>
` + n + `</table>
`;
  }
  tablerow({ text: t }) {
    return `<tr>
${t}</tr>
`;
  }
  tablecell(t) {
    let r = this.parser.parseInline(t.tokens), i = t.header ? "th" : "td";
    return (t.align ? `<${i} align="${t.align}">` : `<${i}>`) + r + `</${i}>
`;
  }
  strong({ tokens: t }) {
    return `<strong>${this.parser.parseInline(t)}</strong>`;
  }
  em({ tokens: t }) {
    return `<em>${this.parser.parseInline(t)}</em>`;
  }
  codespan({ text: t }) {
    return `<code>${ye(t, !0)}</code>`;
  }
  br(t) {
    return "<br>";
  }
  del({ tokens: t }) {
    return `<del>${this.parser.parseInline(t)}</del>`;
  }
  link({ href: t, title: r, tokens: i }) {
    let n = this.parser.parseInline(i), a = Qc(t);
    if (a === null) return n;
    t = a;
    let s = '<a href="' + t + '"';
    return r && (s += ' title="' + ye(r) + '"'), s += ">" + n + "</a>", s;
  }
  image({ href: t, title: r, text: i, tokens: n }) {
    n && (i = this.parser.parseInline(n, this.parser.textRenderer));
    let a = Qc(t);
    if (a === null) return ye(i);
    t = a;
    let s = `<img src="${t}" alt="${i}"`;
    return r && (s += ` title="${ye(r)}"`), s += ">", s;
  }
  text(t) {
    return "tokens" in t && t.tokens ? this.parser.parseInline(t.tokens) : "escaped" in t && t.escaped ? t.text : ye(t.text);
  }
}, gl = class {
  strong({ text: t }) {
    return t;
  }
  em({ text: t }) {
    return t;
  }
  codespan({ text: t }) {
    return t;
  }
  del({ text: t }) {
    return t;
  }
  html({ text: t }) {
    return t;
  }
  text({ text: t }) {
    return t;
  }
  link({ text: t }) {
    return "" + t;
  }
  image({ text: t }) {
    return "" + t;
  }
  br() {
    return "";
  }
}, oe = class ao {
  options;
  renderer;
  textRenderer;
  constructor(t) {
    this.options = t || _r, this.options.renderer = this.options.renderer || new ua(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new gl();
  }
  static parse(t, r) {
    return new ao(r).parse(t);
  }
  static parseInline(t, r) {
    return new ao(r).parseInline(t);
  }
  parse(t, r = !0) {
    let i = "";
    for (let n = 0; n < t.length; n++) {
      let a = t[n];
      if (this.options.extensions?.renderers?.[a.type]) {
        let o = a, l = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (l !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "def", "paragraph", "text"].includes(o.type)) {
          i += l || "";
          continue;
        }
      }
      let s = a;
      switch (s.type) {
        case "space": {
          i += this.renderer.space(s);
          continue;
        }
        case "hr": {
          i += this.renderer.hr(s);
          continue;
        }
        case "heading": {
          i += this.renderer.heading(s);
          continue;
        }
        case "code": {
          i += this.renderer.code(s);
          continue;
        }
        case "table": {
          i += this.renderer.table(s);
          continue;
        }
        case "blockquote": {
          i += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          i += this.renderer.list(s);
          continue;
        }
        case "html": {
          i += this.renderer.html(s);
          continue;
        }
        case "def": {
          i += this.renderer.def(s);
          continue;
        }
        case "paragraph": {
          i += this.renderer.paragraph(s);
          continue;
        }
        case "text": {
          let o = s, l = this.renderer.text(o);
          for (; n + 1 < t.length && t[n + 1].type === "text"; ) o = t[++n], l += `
` + this.renderer.text(o);
          r ? i += this.renderer.paragraph({ type: "paragraph", raw: l, text: l, tokens: [{ type: "text", raw: l, text: l, escaped: !0 }] }) : i += l;
          continue;
        }
        default: {
          let o = 'Token with "' + s.type + '" type was not found.';
          if (this.options.silent) return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return i;
  }
  parseInline(t, r = this.renderer) {
    let i = "";
    for (let n = 0; n < t.length; n++) {
      let a = t[n];
      if (this.options.extensions?.renderers?.[a.type]) {
        let o = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          i += o || "";
          continue;
        }
      }
      let s = a;
      switch (s.type) {
        case "escape": {
          i += r.text(s);
          break;
        }
        case "html": {
          i += r.html(s);
          break;
        }
        case "link": {
          i += r.link(s);
          break;
        }
        case "image": {
          i += r.image(s);
          break;
        }
        case "strong": {
          i += r.strong(s);
          break;
        }
        case "em": {
          i += r.em(s);
          break;
        }
        case "codespan": {
          i += r.codespan(s);
          break;
        }
        case "br": {
          i += r.br(s);
          break;
        }
        case "del": {
          i += r.del(s);
          break;
        }
        case "text": {
          i += r.text(s);
          break;
        }
        default: {
          let o = 'Token with "' + s.type + '" type was not found.';
          if (this.options.silent) return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return i;
  }
}, wi = class {
  options;
  block;
  constructor(t) {
    this.options = t || _r;
  }
  static passThroughHooks = /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens", "emStrongMask"]);
  static passThroughHooksRespectAsync = /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens"]);
  preprocess(t) {
    return t;
  }
  postprocess(t) {
    return t;
  }
  processAllTokens(t) {
    return t;
  }
  emStrongMask(t) {
    return t;
  }
  provideLexer() {
    return this.block ? se.lex : se.lexInline;
  }
  provideParser() {
    return this.block ? oe.parse : oe.parseInline;
  }
}, hv = class {
  defaults = ol();
  options = this.setOptions;
  parse = this.parseMarkdown(!0);
  parseInline = this.parseMarkdown(!1);
  Parser = oe;
  Renderer = ua;
  TextRenderer = gl;
  Lexer = se;
  Tokenizer = ha;
  Hooks = wi;
  constructor(...t) {
    this.use(...t);
  }
  walkTokens(t, r) {
    let i = [];
    for (let n of t) switch (i = i.concat(r.call(this, n)), n.type) {
      case "table": {
        let a = n;
        for (let s of a.header) i = i.concat(this.walkTokens(s.tokens, r));
        for (let s of a.rows) for (let o of s) i = i.concat(this.walkTokens(o.tokens, r));
        break;
      }
      case "list": {
        let a = n;
        i = i.concat(this.walkTokens(a.items, r));
        break;
      }
      default: {
        let a = n;
        this.defaults.extensions?.childTokens?.[a.type] ? this.defaults.extensions.childTokens[a.type].forEach((s) => {
          let o = a[s].flat(1 / 0);
          i = i.concat(this.walkTokens(o, r));
        }) : a.tokens && (i = i.concat(this.walkTokens(a.tokens, r)));
      }
    }
    return i;
  }
  use(...t) {
    let r = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return t.forEach((i) => {
      let n = { ...i };
      if (n.async = this.defaults.async || n.async || !1, i.extensions && (i.extensions.forEach((a) => {
        if (!a.name) throw new Error("extension name required");
        if ("renderer" in a) {
          let s = r.renderers[a.name];
          s ? r.renderers[a.name] = function(...o) {
            let l = a.renderer.apply(this, o);
            return l === !1 && (l = s.apply(this, o)), l;
          } : r.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline") throw new Error("extension level must be 'block' or 'inline'");
          let s = r[a.level];
          s ? s.unshift(a.tokenizer) : r[a.level] = [a.tokenizer], a.start && (a.level === "block" ? r.startBlock ? r.startBlock.push(a.start) : r.startBlock = [a.start] : a.level === "inline" && (r.startInline ? r.startInline.push(a.start) : r.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (r.childTokens[a.name] = a.childTokens);
      }), n.extensions = r), i.renderer) {
        let a = this.defaults.renderer || new ua(this.defaults);
        for (let s in i.renderer) {
          if (!(s in a)) throw new Error(`renderer '${s}' does not exist`);
          if (["options", "parser"].includes(s)) continue;
          let o = s, l = i.renderer[o], c = a[o];
          a[o] = (...h) => {
            let u = l.apply(a, h);
            return u === !1 && (u = c.apply(a, h)), u || "";
          };
        }
        n.renderer = a;
      }
      if (i.tokenizer) {
        let a = this.defaults.tokenizer || new ha(this.defaults);
        for (let s in i.tokenizer) {
          if (!(s in a)) throw new Error(`tokenizer '${s}' does not exist`);
          if (["options", "rules", "lexer"].includes(s)) continue;
          let o = s, l = i.tokenizer[o], c = a[o];
          a[o] = (...h) => {
            let u = l.apply(a, h);
            return u === !1 && (u = c.apply(a, h)), u;
          };
        }
        n.tokenizer = a;
      }
      if (i.hooks) {
        let a = this.defaults.hooks || new wi();
        for (let s in i.hooks) {
          if (!(s in a)) throw new Error(`hook '${s}' does not exist`);
          if (["options", "block"].includes(s)) continue;
          let o = s, l = i.hooks[o], c = a[o];
          wi.passThroughHooks.has(s) ? a[o] = (h) => {
            if (this.defaults.async && wi.passThroughHooksRespectAsync.has(s)) return (async () => {
              let f = await l.call(a, h);
              return c.call(a, f);
            })();
            let u = l.call(a, h);
            return c.call(a, u);
          } : a[o] = (...h) => {
            if (this.defaults.async) return (async () => {
              let f = await l.apply(a, h);
              return f === !1 && (f = await c.apply(a, h)), f;
            })();
            let u = l.apply(a, h);
            return u === !1 && (u = c.apply(a, h)), u;
          };
        }
        n.hooks = a;
      }
      if (i.walkTokens) {
        let a = this.defaults.walkTokens, s = i.walkTokens;
        n.walkTokens = function(o) {
          let l = [];
          return l.push(s.call(this, o)), a && (l = l.concat(a.call(this, o))), l;
        };
      }
      this.defaults = { ...this.defaults, ...n };
    }), this;
  }
  setOptions(t) {
    return this.defaults = { ...this.defaults, ...t }, this;
  }
  lexer(t, r) {
    return se.lex(t, r ?? this.defaults);
  }
  parser(t, r) {
    return oe.parse(t, r ?? this.defaults);
  }
  parseMarkdown(t) {
    return (r, i) => {
      let n = { ...i }, a = { ...this.defaults, ...n }, s = this.onError(!!a.silent, !!a.async);
      if (this.defaults.async === !0 && n.async === !1) return s(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof r > "u" || r === null) return s(new Error("marked(): input parameter is undefined or null"));
      if (typeof r != "string") return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
      if (a.hooks && (a.hooks.options = a, a.hooks.block = t), a.async) return (async () => {
        let o = a.hooks ? await a.hooks.preprocess(r) : r, l = await (a.hooks ? await a.hooks.provideLexer() : t ? se.lex : se.lexInline)(o, a), c = a.hooks ? await a.hooks.processAllTokens(l) : l;
        a.walkTokens && await Promise.all(this.walkTokens(c, a.walkTokens));
        let h = await (a.hooks ? await a.hooks.provideParser() : t ? oe.parse : oe.parseInline)(c, a);
        return a.hooks ? await a.hooks.postprocess(h) : h;
      })().catch(s);
      try {
        a.hooks && (r = a.hooks.preprocess(r));
        let o = (a.hooks ? a.hooks.provideLexer() : t ? se.lex : se.lexInline)(r, a);
        a.hooks && (o = a.hooks.processAllTokens(o)), a.walkTokens && this.walkTokens(o, a.walkTokens);
        let l = (a.hooks ? a.hooks.provideParser() : t ? oe.parse : oe.parseInline)(o, a);
        return a.hooks && (l = a.hooks.postprocess(l)), l;
      } catch (o) {
        return s(o);
      }
    };
  }
  onError(t, r) {
    return (i) => {
      if (i.message += `
Please report this to https://github.com/markedjs/marked.`, t) {
        let n = "<p>An error occurred:</p><pre>" + ye(i.message + "", !0) + "</pre>";
        return r ? Promise.resolve(n) : n;
      }
      if (r) return Promise.reject(i);
      throw i;
    };
  }
}, gr = new hv();
function dt(e, t) {
  return gr.parse(e, t);
}
dt.options = dt.setOptions = function(e) {
  return gr.setOptions(e), dt.defaults = gr.defaults, Xd(dt.defaults), dt;
};
dt.getDefaults = ol;
dt.defaults = _r;
dt.use = function(...e) {
  return gr.use(...e), dt.defaults = gr.defaults, Xd(dt.defaults), dt;
};
dt.walkTokens = function(e, t) {
  return gr.walkTokens(e, t);
};
dt.parseInline = gr.parseInline;
dt.Parser = oe;
dt.parser = oe.parse;
dt.Renderer = ua;
dt.TextRenderer = gl;
dt.Lexer = se;
dt.lexer = se.lex;
dt.Tokenizer = ha;
dt.Hooks = wi;
dt.parse = dt;
dt.options;
dt.setOptions;
dt.use;
dt.walkTokens;
dt.parseInline;
oe.parse;
se.lex;
function ap(e) {
  for (var t = [], r = 1; r < arguments.length; r++)
    t[r - 1] = arguments[r];
  var i = Array.from(typeof e == "string" ? [e] : e);
  i[i.length - 1] = i[i.length - 1].replace(/\r?\n([\t ]*)$/, "");
  var n = i.reduce(function(o, l) {
    var c = l.match(/\n([\t ]+|(?!\s).)/g);
    return c ? o.concat(c.map(function(h) {
      var u, f;
      return (f = (u = h.match(/[\t ]/g)) === null || u === void 0 ? void 0 : u.length) !== null && f !== void 0 ? f : 0;
    })) : o;
  }, []);
  if (n.length) {
    var a = new RegExp(`
[	 ]{` + Math.min.apply(Math, n) + "}", "g");
    i = i.map(function(o) {
      return o.replace(a, `
`);
    });
  }
  i[0] = i[0].replace(/^\r?\n/, "");
  var s = i[0];
  return t.forEach(function(o, l) {
    var c = s.match(/(?:^|\n)( *)$/), h = c ? c[1] : "", u = o;
    typeof o == "string" && o.includes(`
`) && (u = String(o).split(`
`).map(function(f, d) {
      return d === 0 ? f : "" + h + f;
    }).join(`
`)), s += u + i[l + 1];
  }), s;
}
var uv = {
  body: '<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/><text transform="translate(21.16 64.67)" style="fill: #fff; font-family: ArialMT, Arial; font-size: 67.75px;"><tspan x="0" y="0">?</tspan></text></g>',
  height: 80,
  width: 80
}, so = /* @__PURE__ */ new Map(), sp = /* @__PURE__ */ new Map(), fv = /* @__PURE__ */ p((e) => {
  for (const t of e) {
    if (!t.name)
      throw new Error(
        'Invalid icon loader. Must have a "name" property with non-empty string value.'
      );
    if (F.debug("Registering icon pack:", t.name), "loader" in t)
      sp.set(t.name, t.loader);
    else if ("icons" in t)
      so.set(t.name, t.icons);
    else
      throw F.error("Invalid icon loader:", t), new Error('Invalid icon loader. Must have either "icons" or "loader" property.');
  }
}, "registerIconPacks"), op = /* @__PURE__ */ p(async (e, t) => {
  const r = dk(e, !0, t !== void 0);
  if (!r)
    throw new Error(`Invalid icon name: ${e}`);
  const i = r.prefix || t;
  if (!i)
    throw new Error(`Icon name must contain a prefix: ${e}`);
  let n = so.get(i);
  if (!n) {
    const s = sp.get(i);
    if (!s)
      throw new Error(`Icon set not found: ${r.prefix}`);
    try {
      n = { ...await s(), prefix: i }, so.set(i, n);
    } catch (o) {
      throw F.error(o), new Error(`Failed to load icon set: ${r.prefix}`);
    }
  }
  const a = mk(n, r.name);
  if (!a)
    throw new Error(`Icon not found: ${e}`);
  return a;
}, "getRegisteredIconData"), dv = /* @__PURE__ */ p(async (e) => {
  try {
    return await op(e), !0;
  } catch {
    return !1;
  }
}, "isIconAvailable"), Ji = /* @__PURE__ */ p(async (e, t, r) => {
  let i;
  try {
    i = await op(e, t?.fallbackPrefix);
  } catch (s) {
    F.error(s), i = uv;
  }
  const n = kk(i, t), a = Bk(Tk(n.body), {
    ...n.attributes,
    ...r
  });
  return te(a, Dt());
}, "getIconSVG");
function lp(e, { markdownAutoWrap: t }) {
  const i = e.replace(/<br\/>/g, `
`).replace(/\n{2,}/g, `
`), n = ap(i);
  return t === !1 ? n.replace(/ /g, "&nbsp;") : n;
}
p(lp, "preprocessMarkdown");
function cp(e, t = {}) {
  const r = lp(e, t), i = dt.lexer(r), n = [[]];
  let a = 0;
  function s(o, l = "normal") {
    o.type === "text" ? o.text.split(`
`).forEach((h, u) => {
      u !== 0 && (a++, n.push([])), h.split(" ").forEach((f) => {
        f = f.replace(/&#39;/g, "'"), f && n[a].push({ content: f, type: l });
      });
    }) : o.type === "strong" || o.type === "em" ? o.tokens.forEach((c) => {
      s(c, o.type);
    }) : o.type === "html" && n[a].push({ content: o.text, type: "normal" });
  }
  return p(s, "processNode"), i.forEach((o) => {
    o.type === "paragraph" ? o.tokens?.forEach((l) => {
      s(l);
    }) : o.type === "html" ? n[a].push({ content: o.text, type: "normal" }) : n[a].push({ content: o.raw, type: "normal" });
  }), n;
}
p(cp, "markdownToLines");
function hp(e, { markdownAutoWrap: t } = {}) {
  const r = dt.lexer(e);
  function i(n) {
    return n.type === "text" ? t === !1 ? n.text.replace(/\n */g, "<br/>").replace(/ /g, "&nbsp;") : n.text.replace(/\n */g, "<br/>") : n.type === "strong" ? `<strong>${n.tokens?.map(i).join("")}</strong>` : n.type === "em" ? `<em>${n.tokens?.map(i).join("")}</em>` : n.type === "paragraph" ? `<p>${n.tokens?.map(i).join("")}</p>` : n.type === "space" ? "" : n.type === "html" ? `${n.text}` : n.type === "escape" ? n.text : (F.warn(`Unsupported markdown: ${n.type}`), n.raw);
  }
  return p(i, "output"), r.map(i).join("");
}
p(hp, "markdownToHTML");
function up(e) {
  return Intl.Segmenter ? [...new Intl.Segmenter().segment(e)].map((t) => t.segment) : [...e];
}
p(up, "splitTextToChars");
function fp(e, t) {
  const r = up(t.content);
  return ml(e, [], r, t.type);
}
p(fp, "splitWordToFitWidth");
function ml(e, t, r, i) {
  if (r.length === 0)
    return [
      { content: t.join(""), type: i },
      { content: "", type: i }
    ];
  const [n, ...a] = r, s = [...t, n];
  return e([{ content: s.join(""), type: i }]) ? ml(e, s, a, i) : (t.length === 0 && n && (t.push(n), r.shift()), [
    { content: t.join(""), type: i },
    { content: r.join(""), type: i }
  ]);
}
p(ml, "splitWordToFitWidthRecursion");
function dp(e, t) {
  if (e.some(({ content: r }) => r.includes(`
`)))
    throw new Error("splitLineToFitWidth does not support newlines in the line");
  return fa(e, t);
}
p(dp, "splitLineToFitWidth");
function fa(e, t, r = [], i = []) {
  if (e.length === 0)
    return i.length > 0 && r.push(i), r.length > 0 ? r : [];
  let n = "";
  e[0].content === " " && (n = " ", e.shift());
  const a = e.shift() ?? { content: " ", type: "normal" }, s = [...i];
  if (n !== "" && s.push({ content: n, type: "normal" }), s.push(a), t(s))
    return fa(e, t, r, s);
  if (i.length > 0)
    r.push(i), e.unshift(a);
  else if (a.content) {
    const [o, l] = fp(t, a);
    r.push([o]), l.content && e.unshift(l);
  }
  return fa(e, t, r);
}
p(fa, "splitLineToFitWidthRecursion");
function oo(e, t) {
  t && e.attr("style", t);
}
p(oo, "applyStyle");
async function pp(e, t, r, i, n = !1, a = Dt()) {
  const s = e.append("foreignObject");
  s.attr("width", `${10 * r}px`), s.attr("height", `${10 * r}px`);
  const o = s.append("xhtml:div"), l = Yr(t.label) ? await So(t.label.replace(Qr.lineBreakRegex, `
`), a) : te(t.label, a), c = t.isNode ? "nodeLabel" : "edgeLabel", h = o.append("span");
  h.html(l), oo(h, t.labelStyle), h.attr("class", `${c} ${i}`), oo(o, t.labelStyle), o.style("display", "table-cell"), o.style("white-space", "nowrap"), o.style("line-height", "1.5"), o.style("max-width", r + "px"), o.style("text-align", "center"), o.attr("xmlns", "http://www.w3.org/1999/xhtml"), n && o.attr("class", "labelBkg");
  let u = o.node().getBoundingClientRect();
  return u.width === r && (o.style("display", "table"), o.style("white-space", "break-spaces"), o.style("width", r + "px"), u = o.node().getBoundingClientRect()), s.node();
}
p(pp, "addHtmlSpan");
function Pa(e, t, r) {
  return e.append("tspan").attr("class", "text-outer-tspan").attr("x", 0).attr("y", t * r - 0.1 + "em").attr("dy", r + "em");
}
p(Pa, "createTspan");
function gp(e, t, r) {
  const i = e.append("text"), n = Pa(i, 1, t);
  Na(n, r);
  const a = n.node().getComputedTextLength();
  return i.remove(), a;
}
p(gp, "computeWidthOfText");
function pv(e, t, r) {
  const i = e.append("text"), n = Pa(i, 1, t);
  Na(n, [{ content: r, type: "normal" }]);
  const a = n.node()?.getBoundingClientRect();
  return a && i.remove(), a;
}
p(pv, "computeDimensionOfText");
function mp(e, t, r, i = !1) {
  const a = t.append("g"), s = a.insert("rect").attr("class", "background").attr("style", "stroke: none"), o = a.append("text").attr("y", "-10.1");
  let l = 0;
  for (const c of r) {
    const h = /* @__PURE__ */ p((f) => gp(a, 1.1, f) <= e, "checkWidth"), u = h(c) ? [c] : dp(c, h);
    for (const f of u) {
      const d = Pa(o, l, 1.1);
      Na(d, f), l++;
    }
  }
  if (i) {
    const c = o.node().getBBox(), h = 2;
    return s.attr("x", c.x - h).attr("y", c.y - h).attr("width", c.width + 2 * h).attr("height", c.height + 2 * h), a.node();
  } else
    return o.node();
}
p(mp, "createFormattedText");
function Na(e, t) {
  e.text(""), t.forEach((r, i) => {
    const n = e.append("tspan").attr("font-style", r.type === "em" ? "italic" : "normal").attr("class", "text-inner-tspan").attr("font-weight", r.type === "strong" ? "bold" : "normal");
    i === 0 ? n.text(r.content) : n.text(" " + r.content);
  });
}
p(Na, "updateTextContentAndStyles");
async function yp(e, t = {}) {
  const r = [];
  e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, (n, a, s) => (r.push(
    (async () => {
      const o = `${a}:${s}`;
      return await dv(o) ? await Ji(o, void 0, { class: "label-icon" }) : `<i class='${te(n, t).replace(":", " ")}'></i>`;
    })()
  ), n));
  const i = await Promise.all(r);
  return e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, () => i.shift() ?? "");
}
p(yp, "replaceIconSubstring");
var Xe = /* @__PURE__ */ p(async (e, t = "", {
  style: r = "",
  isTitle: i = !1,
  classes: n = "",
  useHtmlLabels: a = !0,
  isNode: s = !0,
  width: o = 200,
  addSvgBackground: l = !1
} = {}, c) => {
  if (F.debug(
    "XYZ createText",
    t,
    r,
    i,
    n,
    a,
    s,
    "addSvgBackground: ",
    l
  ), a) {
    const h = hp(t, c), u = await yp(Cr(h), c), f = t.replace(/\\\\/g, "\\"), d = {
      isNode: s,
      label: Yr(t) ? f : u,
      labelStyle: r.replace("fill:", "color:")
    };
    return await pp(e, d, o, n, l, c);
  } else {
    const h = t.replace(/<br\s*\/?>/g, "<br/>"), u = cp(h.replace("<br>", "<br/>"), c), f = mp(
      o,
      e,
      u,
      t ? l : !1
    );
    if (s) {
      /stroke:/.exec(r) && (r = r.replace("stroke:", "lineColor:"));
      const d = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      ht(f).attr("style", d);
    } else {
      const d = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/background:/g, "fill:");
      ht(f).select("rect").attr("style", d.replace(/background:/g, "fill:"));
      const g = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      ht(f).select("text").attr("style", g);
    }
    return f;
  }
}, "createText");
function gs(e, t, r) {
  if (e && e.length) {
    const [i, n] = t, a = Math.PI / 180 * r, s = Math.cos(a), o = Math.sin(a);
    for (const l of e) {
      const [c, h] = l;
      l[0] = (c - i) * s - (h - n) * o + i, l[1] = (c - i) * o + (h - n) * s + n;
    }
  }
}
function gv(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}
function mv(e, t, r, i = 1) {
  const n = r, a = Math.max(t, 0.1), s = e[0] && e[0][0] && typeof e[0][0] == "number" ? [e] : e, o = [0, 0];
  if (n) for (const c of s) gs(c, o, n);
  const l = (function(c, h, u) {
    const f = [];
    for (const b of c) {
      const C = [...b];
      gv(C[0], C[C.length - 1]) || C.push([C[0][0], C[0][1]]), C.length > 2 && f.push(C);
    }
    const d = [];
    h = Math.max(h, 0.1);
    const g = [];
    for (const b of f) for (let C = 0; C < b.length - 1; C++) {
      const k = b[C], w = b[C + 1];
      if (k[1] !== w[1]) {
        const A = Math.min(k[1], w[1]);
        g.push({ ymin: A, ymax: Math.max(k[1], w[1]), x: A === k[1] ? k[0] : w[0], islope: (w[0] - k[0]) / (w[1] - k[1]) });
      }
    }
    if (g.sort(((b, C) => b.ymin < C.ymin ? -1 : b.ymin > C.ymin ? 1 : b.x < C.x ? -1 : b.x > C.x ? 1 : b.ymax === C.ymax ? 0 : (b.ymax - C.ymax) / Math.abs(b.ymax - C.ymax))), !g.length) return d;
    let m = [], y = g[0].ymin, x = 0;
    for (; m.length || g.length; ) {
      if (g.length) {
        let b = -1;
        for (let C = 0; C < g.length && !(g[C].ymin > y); C++) b = C;
        g.splice(0, b + 1).forEach(((C) => {
          m.push({ s: y, edge: C });
        }));
      }
      if (m = m.filter(((b) => !(b.edge.ymax <= y))), m.sort(((b, C) => b.edge.x === C.edge.x ? 0 : (b.edge.x - C.edge.x) / Math.abs(b.edge.x - C.edge.x))), (u !== 1 || x % h == 0) && m.length > 1) for (let b = 0; b < m.length; b += 2) {
        const C = b + 1;
        if (C >= m.length) break;
        const k = m[b].edge, w = m[C].edge;
        d.push([[Math.round(k.x), y], [Math.round(w.x), y]]);
      }
      y += u, m.forEach(((b) => {
        b.edge.x = b.edge.x + u * b.edge.islope;
      })), x++;
    }
    return d;
  })(s, a, i);
  if (n) {
    for (const c of s) gs(c, o, -n);
    (function(c, h, u) {
      const f = [];
      c.forEach(((d) => f.push(...d))), gs(f, h, u);
    })(l, o, -n);
  }
  return l;
}
function tn(e, t) {
  var r;
  const i = t.hachureAngle + 90;
  let n = t.hachureGap;
  n < 0 && (n = 4 * t.strokeWidth), n = Math.round(Math.max(n, 0.1));
  let a = 1;
  return t.roughness >= 1 && (((r = t.randomizer) === null || r === void 0 ? void 0 : r.next()) || Math.random()) > 0.7 && (a = n), mv(e, n, i, a || 1);
}
class yl {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    return this._fillPolygons(t, r);
  }
  _fillPolygons(t, r) {
    const i = tn(t, r);
    return { type: "fillSketch", ops: this.renderLines(i, r) };
  }
  renderLines(t, r) {
    const i = [];
    for (const n of t) i.push(...this.helper.doubleLineOps(n[0][0], n[0][1], n[1][0], n[1][1], r));
    return i;
  }
}
function za(e) {
  const t = e[0], r = e[1];
  return Math.sqrt(Math.pow(t[0] - r[0], 2) + Math.pow(t[1] - r[1], 2));
}
class yv extends yl {
  fillPolygons(t, r) {
    let i = r.hachureGap;
    i < 0 && (i = 4 * r.strokeWidth), i = Math.max(i, 0.1);
    const n = tn(t, Object.assign({}, r, { hachureGap: i })), a = Math.PI / 180 * r.hachureAngle, s = [], o = 0.5 * i * Math.cos(a), l = 0.5 * i * Math.sin(a);
    for (const [c, h] of n) za([c, h]) && s.push([[c[0] - o, c[1] + l], [...h]], [[c[0] + o, c[1] - l], [...h]]);
    return { type: "fillSketch", ops: this.renderLines(s, r) };
  }
}
class xv extends yl {
  fillPolygons(t, r) {
    const i = this._fillPolygons(t, r), n = Object.assign({}, r, { hachureAngle: r.hachureAngle + 90 }), a = this._fillPolygons(t, n);
    return i.ops = i.ops.concat(a.ops), i;
  }
}
class bv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = tn(t, r = Object.assign({}, r, { hachureAngle: 0 }));
    return this.dotsOnLines(i, r);
  }
  dotsOnLines(t, r) {
    const i = [];
    let n = r.hachureGap;
    n < 0 && (n = 4 * r.strokeWidth), n = Math.max(n, 0.1);
    let a = r.fillWeight;
    a < 0 && (a = r.strokeWidth / 2);
    const s = n / 4;
    for (const o of t) {
      const l = za(o), c = l / n, h = Math.ceil(c) - 1, u = l - h * n, f = (o[0][0] + o[1][0]) / 2 - n / 4, d = Math.min(o[0][1], o[1][1]);
      for (let g = 0; g < h; g++) {
        const m = d + u + g * n, y = f - s + 2 * Math.random() * s, x = m - s + 2 * Math.random() * s, b = this.helper.ellipse(y, x, a, a, r);
        i.push(...b.ops);
      }
    }
    return { type: "fillSketch", ops: i };
  }
}
class Cv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = tn(t, r);
    return { type: "fillSketch", ops: this.dashedLine(i, r) };
  }
  dashedLine(t, r) {
    const i = r.dashOffset < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashOffset, n = r.dashGap < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashGap, a = [];
    return t.forEach(((s) => {
      const o = za(s), l = Math.floor(o / (i + n)), c = (o + n - l * (i + n)) / 2;
      let h = s[0], u = s[1];
      h[0] > u[0] && (h = s[1], u = s[0]);
      const f = Math.atan((u[1] - h[1]) / (u[0] - h[0]));
      for (let d = 0; d < l; d++) {
        const g = d * (i + n), m = g + i, y = [h[0] + g * Math.cos(f) + c * Math.cos(f), h[1] + g * Math.sin(f) + c * Math.sin(f)], x = [h[0] + m * Math.cos(f) + c * Math.cos(f), h[1] + m * Math.sin(f) + c * Math.sin(f)];
        a.push(...this.helper.doubleLineOps(y[0], y[1], x[0], x[1], r));
      }
    })), a;
  }
}
class _v {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap, n = r.zigzagOffset < 0 ? i : r.zigzagOffset, a = tn(t, r = Object.assign({}, r, { hachureGap: i + n }));
    return { type: "fillSketch", ops: this.zigzagLines(a, n, r) };
  }
  zigzagLines(t, r, i) {
    const n = [];
    return t.forEach(((a) => {
      const s = za(a), o = Math.round(s / (2 * r));
      let l = a[0], c = a[1];
      l[0] > c[0] && (l = a[1], c = a[0]);
      const h = Math.atan((c[1] - l[1]) / (c[0] - l[0]));
      for (let u = 0; u < o; u++) {
        const f = 2 * u * r, d = 2 * (u + 1) * r, g = Math.sqrt(2 * Math.pow(r, 2)), m = [l[0] + f * Math.cos(h), l[1] + f * Math.sin(h)], y = [l[0] + d * Math.cos(h), l[1] + d * Math.sin(h)], x = [m[0] + g * Math.cos(h + Math.PI / 4), m[1] + g * Math.sin(h + Math.PI / 4)];
        n.push(...this.helper.doubleLineOps(m[0], m[1], x[0], x[1], i), ...this.helper.doubleLineOps(x[0], x[1], y[0], y[1], i));
      }
    })), n;
  }
}
const Ut = {};
class wv {
  constructor(t) {
    this.seed = t;
  }
  next() {
    return this.seed ? (2 ** 31 - 1 & (this.seed = Math.imul(48271, this.seed))) / 2 ** 31 : Math.random();
  }
}
const kv = 0, ms = 1, eh = 2, yn = { A: 7, a: 7, C: 6, c: 6, H: 1, h: 1, L: 2, l: 2, M: 2, m: 2, Q: 4, q: 4, S: 4, s: 4, T: 2, t: 2, V: 1, v: 1, Z: 0, z: 0 };
function ys(e, t) {
  return e.type === t;
}
function xl(e) {
  const t = [], r = (function(s) {
    const o = new Array();
    for (; s !== ""; ) if (s.match(/^([ \t\r\n,]+)/)) s = s.substr(RegExp.$1.length);
    else if (s.match(/^([aAcChHlLmMqQsStTvVzZ])/)) o[o.length] = { type: kv, text: RegExp.$1 }, s = s.substr(RegExp.$1.length);
    else {
      if (!s.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/)) return [];
      o[o.length] = { type: ms, text: `${parseFloat(RegExp.$1)}` }, s = s.substr(RegExp.$1.length);
    }
    return o[o.length] = { type: eh, text: "" }, o;
  })(e);
  let i = "BOD", n = 0, a = r[n];
  for (; !ys(a, eh); ) {
    let s = 0;
    const o = [];
    if (i === "BOD") {
      if (a.text !== "M" && a.text !== "m") return xl("M0,0" + e);
      n++, s = yn[a.text], i = a.text;
    } else ys(a, ms) ? s = yn[i] : (n++, s = yn[a.text], i = a.text);
    if (!(n + s < r.length)) throw new Error("Path data ended short");
    for (let l = n; l < n + s; l++) {
      const c = r[l];
      if (!ys(c, ms)) throw new Error("Param not a number: " + i + "," + c.text);
      o[o.length] = +c.text;
    }
    if (typeof yn[i] != "number") throw new Error("Bad segment: " + i);
    {
      const l = { key: i, data: o };
      t.push(l), n += s, a = r[n], i === "M" && (i = "L"), i === "m" && (i = "l");
    }
  }
  return t;
}
function xp(e) {
  let t = 0, r = 0, i = 0, n = 0;
  const a = [];
  for (const { key: s, data: o } of e) switch (s) {
    case "M":
      a.push({ key: "M", data: [...o] }), [t, r] = o, [i, n] = o;
      break;
    case "m":
      t += o[0], r += o[1], a.push({ key: "M", data: [t, r] }), i = t, n = r;
      break;
    case "L":
      a.push({ key: "L", data: [...o] }), [t, r] = o;
      break;
    case "l":
      t += o[0], r += o[1], a.push({ key: "L", data: [t, r] });
      break;
    case "C":
      a.push({ key: "C", data: [...o] }), t = o[4], r = o[5];
      break;
    case "c": {
      const l = o.map(((c, h) => h % 2 ? c + r : c + t));
      a.push({ key: "C", data: l }), t = l[4], r = l[5];
      break;
    }
    case "Q":
      a.push({ key: "Q", data: [...o] }), t = o[2], r = o[3];
      break;
    case "q": {
      const l = o.map(((c, h) => h % 2 ? c + r : c + t));
      a.push({ key: "Q", data: l }), t = l[2], r = l[3];
      break;
    }
    case "A":
      a.push({ key: "A", data: [...o] }), t = o[5], r = o[6];
      break;
    case "a":
      t += o[5], r += o[6], a.push({ key: "A", data: [o[0], o[1], o[2], o[3], o[4], t, r] });
      break;
    case "H":
      a.push({ key: "H", data: [...o] }), t = o[0];
      break;
    case "h":
      t += o[0], a.push({ key: "H", data: [t] });
      break;
    case "V":
      a.push({ key: "V", data: [...o] }), r = o[0];
      break;
    case "v":
      r += o[0], a.push({ key: "V", data: [r] });
      break;
    case "S":
      a.push({ key: "S", data: [...o] }), t = o[2], r = o[3];
      break;
    case "s": {
      const l = o.map(((c, h) => h % 2 ? c + r : c + t));
      a.push({ key: "S", data: l }), t = l[2], r = l[3];
      break;
    }
    case "T":
      a.push({ key: "T", data: [...o] }), t = o[0], r = o[1];
      break;
    case "t":
      t += o[0], r += o[1], a.push({ key: "T", data: [t, r] });
      break;
    case "Z":
    case "z":
      a.push({ key: "Z", data: [] }), t = i, r = n;
  }
  return a;
}
function bp(e) {
  const t = [];
  let r = "", i = 0, n = 0, a = 0, s = 0, o = 0, l = 0;
  for (const { key: c, data: h } of e) {
    switch (c) {
      case "M":
        t.push({ key: "M", data: [...h] }), [i, n] = h, [a, s] = h;
        break;
      case "C":
        t.push({ key: "C", data: [...h] }), i = h[4], n = h[5], o = h[2], l = h[3];
        break;
      case "L":
        t.push({ key: "L", data: [...h] }), [i, n] = h;
        break;
      case "H":
        i = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "V":
        n = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "S": {
        let u = 0, f = 0;
        r === "C" || r === "S" ? (u = i + (i - o), f = n + (n - l)) : (u = i, f = n), t.push({ key: "C", data: [u, f, ...h] }), o = h[0], l = h[1], i = h[2], n = h[3];
        break;
      }
      case "T": {
        const [u, f] = h;
        let d = 0, g = 0;
        r === "Q" || r === "T" ? (d = i + (i - o), g = n + (n - l)) : (d = i, g = n);
        const m = i + 2 * (d - i) / 3, y = n + 2 * (g - n) / 3, x = u + 2 * (d - u) / 3, b = f + 2 * (g - f) / 3;
        t.push({ key: "C", data: [m, y, x, b, u, f] }), o = d, l = g, i = u, n = f;
        break;
      }
      case "Q": {
        const [u, f, d, g] = h, m = i + 2 * (u - i) / 3, y = n + 2 * (f - n) / 3, x = d + 2 * (u - d) / 3, b = g + 2 * (f - g) / 3;
        t.push({ key: "C", data: [m, y, x, b, d, g] }), o = u, l = f, i = d, n = g;
        break;
      }
      case "A": {
        const u = Math.abs(h[0]), f = Math.abs(h[1]), d = h[2], g = h[3], m = h[4], y = h[5], x = h[6];
        u === 0 || f === 0 ? (t.push({ key: "C", data: [i, n, y, x, y, x] }), i = y, n = x) : (i !== y || n !== x) && (Cp(i, n, y, x, u, f, d, g, m).forEach((function(b) {
          t.push({ key: "C", data: b });
        })), i = y, n = x);
        break;
      }
      case "Z":
        t.push({ key: "Z", data: [] }), i = a, n = s;
    }
    r = c;
  }
  return t;
}
function gi(e, t, r) {
  return [e * Math.cos(r) - t * Math.sin(r), e * Math.sin(r) + t * Math.cos(r)];
}
function Cp(e, t, r, i, n, a, s, o, l, c) {
  const h = (u = s, Math.PI * u / 180);
  var u;
  let f = [], d = 0, g = 0, m = 0, y = 0;
  if (c) [d, g, m, y] = c;
  else {
    [e, t] = gi(e, t, -h), [r, i] = gi(r, i, -h);
    const R = (e - r) / 2, B = (t - i) / 2;
    let L = R * R / (n * n) + B * B / (a * a);
    L > 1 && (L = Math.sqrt(L), n *= L, a *= L);
    const T = n * n, E = a * a, M = T * E - T * B * B - E * R * R, q = T * B * B + E * R * R, X = (o === l ? -1 : 1) * Math.sqrt(Math.abs(M / q));
    m = X * n * B / a + (e + r) / 2, y = X * -a * R / n + (t + i) / 2, d = Math.asin(parseFloat(((t - y) / a).toFixed(9))), g = Math.asin(parseFloat(((i - y) / a).toFixed(9))), e < m && (d = Math.PI - d), r < m && (g = Math.PI - g), d < 0 && (d = 2 * Math.PI + d), g < 0 && (g = 2 * Math.PI + g), l && d > g && (d -= 2 * Math.PI), !l && g > d && (g -= 2 * Math.PI);
  }
  let x = g - d;
  if (Math.abs(x) > 120 * Math.PI / 180) {
    const R = g, B = r, L = i;
    g = l && g > d ? d + 120 * Math.PI / 180 * 1 : d + 120 * Math.PI / 180 * -1, f = Cp(r = m + n * Math.cos(g), i = y + a * Math.sin(g), B, L, n, a, s, 0, l, [g, R, m, y]);
  }
  x = g - d;
  const b = Math.cos(d), C = Math.sin(d), k = Math.cos(g), w = Math.sin(g), A = Math.tan(x / 4), S = 4 / 3 * n * A, D = 4 / 3 * a * A, I = [e, t], O = [e + S * C, t - D * b], $ = [r + S * w, i - D * k], N = [r, i];
  if (O[0] = 2 * I[0] - O[0], O[1] = 2 * I[1] - O[1], c) return [O, $, N].concat(f);
  {
    f = [O, $, N].concat(f);
    const R = [];
    for (let B = 0; B < f.length; B += 3) {
      const L = gi(f[B][0], f[B][1], h), T = gi(f[B + 1][0], f[B + 1][1], h), E = gi(f[B + 2][0], f[B + 2][1], h);
      R.push([L[0], L[1], T[0], T[1], E[0], E[1]]);
    }
    return R;
  }
}
const vv = { randOffset: function(e, t) {
  return nt(e, t);
}, randOffsetWithRange: function(e, t, r) {
  return da(e, t, r);
}, ellipse: function(e, t, r, i, n) {
  const a = wp(r, i, n);
  return lo(e, t, n, a).opset;
}, doubleLineOps: function(e, t, r, i, n) {
  return Ye(e, t, r, i, n, !0);
} };
function _p(e, t, r, i, n) {
  return { type: "path", ops: Ye(e, t, r, i, n) };
}
function En(e, t, r) {
  const i = (e || []).length;
  if (i > 2) {
    const n = [];
    for (let a = 0; a < i - 1; a++) n.push(...Ye(e[a][0], e[a][1], e[a + 1][0], e[a + 1][1], r));
    return t && n.push(...Ye(e[i - 1][0], e[i - 1][1], e[0][0], e[0][1], r)), { type: "path", ops: n };
  }
  return i === 2 ? _p(e[0][0], e[0][1], e[1][0], e[1][1], r) : { type: "path", ops: [] };
}
function Sv(e, t, r, i, n) {
  return (function(a, s) {
    return En(a, !0, s);
  })([[e, t], [e + r, t], [e + r, t + i], [e, t + i]], n);
}
function rh(e, t) {
  if (e.length) {
    const r = typeof e[0][0] == "number" ? [e] : e, i = xn(r[0], 1 * (1 + 0.2 * t.roughness), t), n = t.disableMultiStroke ? [] : xn(r[0], 1.5 * (1 + 0.22 * t.roughness), ah(t));
    for (let a = 1; a < r.length; a++) {
      const s = r[a];
      if (s.length) {
        const o = xn(s, 1 * (1 + 0.2 * t.roughness), t), l = t.disableMultiStroke ? [] : xn(s, 1.5 * (1 + 0.22 * t.roughness), ah(t));
        for (const c of o) c.op !== "move" && i.push(c);
        for (const c of l) c.op !== "move" && n.push(c);
      }
    }
    return { type: "path", ops: i.concat(n) };
  }
  return { type: "path", ops: [] };
}
function wp(e, t, r) {
  const i = Math.sqrt(2 * Math.PI * Math.sqrt((Math.pow(e / 2, 2) + Math.pow(t / 2, 2)) / 2)), n = Math.ceil(Math.max(r.curveStepCount, r.curveStepCount / Math.sqrt(200) * i)), a = 2 * Math.PI / n;
  let s = Math.abs(e / 2), o = Math.abs(t / 2);
  const l = 1 - r.curveFitting;
  return s += nt(s * l, r), o += nt(o * l, r), { increment: a, rx: s, ry: o };
}
function lo(e, t, r, i) {
  const [n, a] = sh(i.increment, e, t, i.rx, i.ry, 1, i.increment * da(0.1, da(0.4, 1, r), r), r);
  let s = pa(n, null, r);
  if (!r.disableMultiStroke && r.roughness !== 0) {
    const [o] = sh(i.increment, e, t, i.rx, i.ry, 1.5, 0, r), l = pa(o, null, r);
    s = s.concat(l);
  }
  return { estimatedPoints: a, opset: { type: "path", ops: s } };
}
function ih(e, t, r, i, n, a, s, o, l) {
  const c = e, h = t;
  let u = Math.abs(r / 2), f = Math.abs(i / 2);
  u += nt(0.01 * u, l), f += nt(0.01 * f, l);
  let d = n, g = a;
  for (; d < 0; ) d += 2 * Math.PI, g += 2 * Math.PI;
  g - d > 2 * Math.PI && (d = 0, g = 2 * Math.PI);
  const m = 2 * Math.PI / l.curveStepCount, y = Math.min(m / 2, (g - d) / 2), x = oh(y, c, h, u, f, d, g, 1, l);
  if (!l.disableMultiStroke) {
    const b = oh(y, c, h, u, f, d, g, 1.5, l);
    x.push(...b);
  }
  return s && (o ? x.push(...Ye(c, h, c + u * Math.cos(d), h + f * Math.sin(d), l), ...Ye(c, h, c + u * Math.cos(g), h + f * Math.sin(g), l)) : x.push({ op: "lineTo", data: [c, h] }, { op: "lineTo", data: [c + u * Math.cos(d), h + f * Math.sin(d)] })), { type: "path", ops: x };
}
function nh(e, t) {
  const r = bp(xp(xl(e))), i = [];
  let n = [0, 0], a = [0, 0];
  for (const { key: s, data: o } of r) switch (s) {
    case "M":
      a = [o[0], o[1]], n = [o[0], o[1]];
      break;
    case "L":
      i.push(...Ye(a[0], a[1], o[0], o[1], t)), a = [o[0], o[1]];
      break;
    case "C": {
      const [l, c, h, u, f, d] = o;
      i.push(...Tv(l, c, h, u, f, d, a, t)), a = [f, d];
      break;
    }
    case "Z":
      i.push(...Ye(a[0], a[1], n[0], n[1], t)), a = [n[0], n[1]];
  }
  return { type: "path", ops: i };
}
function xs(e, t) {
  const r = [];
  for (const i of e) if (i.length) {
    const n = t.maxRandomnessOffset || 0, a = i.length;
    if (a > 2) {
      r.push({ op: "move", data: [i[0][0] + nt(n, t), i[0][1] + nt(n, t)] });
      for (let s = 1; s < a; s++) r.push({ op: "lineTo", data: [i[s][0] + nt(n, t), i[s][1] + nt(n, t)] });
    }
  }
  return { type: "fillPath", ops: r };
}
function Ar(e, t) {
  return (function(r, i) {
    let n = r.fillStyle || "hachure";
    if (!Ut[n]) switch (n) {
      case "zigzag":
        Ut[n] || (Ut[n] = new yv(i));
        break;
      case "cross-hatch":
        Ut[n] || (Ut[n] = new xv(i));
        break;
      case "dots":
        Ut[n] || (Ut[n] = new bv(i));
        break;
      case "dashed":
        Ut[n] || (Ut[n] = new Cv(i));
        break;
      case "zigzag-line":
        Ut[n] || (Ut[n] = new _v(i));
        break;
      default:
        n = "hachure", Ut[n] || (Ut[n] = new yl(i));
    }
    return Ut[n];
  })(t, vv).fillPolygons(e, t);
}
function ah(e) {
  const t = Object.assign({}, e);
  return t.randomizer = void 0, e.seed && (t.seed = e.seed + 1), t;
}
function kp(e) {
  return e.randomizer || (e.randomizer = new wv(e.seed || 0)), e.randomizer.next();
}
function da(e, t, r, i = 1) {
  return r.roughness * i * (kp(r) * (t - e) + e);
}
function nt(e, t, r = 1) {
  return da(-e, e, t, r);
}
function Ye(e, t, r, i, n, a = !1) {
  const s = a ? n.disableMultiStrokeFill : n.disableMultiStroke, o = co(e, t, r, i, n, !0, !1);
  if (s) return o;
  const l = co(e, t, r, i, n, !0, !0);
  return o.concat(l);
}
function co(e, t, r, i, n, a, s) {
  const o = Math.pow(e - r, 2) + Math.pow(t - i, 2), l = Math.sqrt(o);
  let c = 1;
  c = l < 200 ? 1 : l > 500 ? 0.4 : -16668e-7 * l + 1.233334;
  let h = n.maxRandomnessOffset || 0;
  h * h * 100 > o && (h = l / 10);
  const u = h / 2, f = 0.2 + 0.2 * kp(n);
  let d = n.bowing * n.maxRandomnessOffset * (i - t) / 200, g = n.bowing * n.maxRandomnessOffset * (e - r) / 200;
  d = nt(d, n, c), g = nt(g, n, c);
  const m = [], y = () => nt(u, n, c), x = () => nt(h, n, c), b = n.preserveVertices;
  return s ? m.push({ op: "move", data: [e + (b ? 0 : y()), t + (b ? 0 : y())] }) : m.push({ op: "move", data: [e + (b ? 0 : nt(h, n, c)), t + (b ? 0 : nt(h, n, c))] }), s ? m.push({ op: "bcurveTo", data: [d + e + (r - e) * f + y(), g + t + (i - t) * f + y(), d + e + 2 * (r - e) * f + y(), g + t + 2 * (i - t) * f + y(), r + (b ? 0 : y()), i + (b ? 0 : y())] }) : m.push({ op: "bcurveTo", data: [d + e + (r - e) * f + x(), g + t + (i - t) * f + x(), d + e + 2 * (r - e) * f + x(), g + t + 2 * (i - t) * f + x(), r + (b ? 0 : x()), i + (b ? 0 : x())] }), m;
}
function xn(e, t, r) {
  if (!e.length) return [];
  const i = [];
  i.push([e[0][0] + nt(t, r), e[0][1] + nt(t, r)]), i.push([e[0][0] + nt(t, r), e[0][1] + nt(t, r)]);
  for (let n = 1; n < e.length; n++) i.push([e[n][0] + nt(t, r), e[n][1] + nt(t, r)]), n === e.length - 1 && i.push([e[n][0] + nt(t, r), e[n][1] + nt(t, r)]);
  return pa(i, null, r);
}
function pa(e, t, r) {
  const i = e.length, n = [];
  if (i > 3) {
    const a = [], s = 1 - r.curveTightness;
    n.push({ op: "move", data: [e[1][0], e[1][1]] });
    for (let o = 1; o + 2 < i; o++) {
      const l = e[o];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (s * e[o + 1][0] - s * e[o - 1][0]) / 6, l[1] + (s * e[o + 1][1] - s * e[o - 1][1]) / 6], a[2] = [e[o + 1][0] + (s * e[o][0] - s * e[o + 2][0]) / 6, e[o + 1][1] + (s * e[o][1] - s * e[o + 2][1]) / 6], a[3] = [e[o + 1][0], e[o + 1][1]], n.push({ op: "bcurveTo", data: [a[1][0], a[1][1], a[2][0], a[2][1], a[3][0], a[3][1]] });
    }
  } else i === 3 ? (n.push({ op: "move", data: [e[1][0], e[1][1]] }), n.push({ op: "bcurveTo", data: [e[1][0], e[1][1], e[2][0], e[2][1], e[2][0], e[2][1]] })) : i === 2 && n.push(...co(e[0][0], e[0][1], e[1][0], e[1][1], r, !0, !0));
  return n;
}
function sh(e, t, r, i, n, a, s, o) {
  const l = [], c = [];
  if (o.roughness === 0) {
    e /= 4, c.push([t + i * Math.cos(-e), r + n * Math.sin(-e)]);
    for (let h = 0; h <= 2 * Math.PI; h += e) {
      const u = [t + i * Math.cos(h), r + n * Math.sin(h)];
      l.push(u), c.push(u);
    }
    c.push([t + i * Math.cos(0), r + n * Math.sin(0)]), c.push([t + i * Math.cos(e), r + n * Math.sin(e)]);
  } else {
    const h = nt(0.5, o) - Math.PI / 2;
    c.push([nt(a, o) + t + 0.9 * i * Math.cos(h - e), nt(a, o) + r + 0.9 * n * Math.sin(h - e)]);
    const u = 2 * Math.PI + h - 0.01;
    for (let f = h; f < u; f += e) {
      const d = [nt(a, o) + t + i * Math.cos(f), nt(a, o) + r + n * Math.sin(f)];
      l.push(d), c.push(d);
    }
    c.push([nt(a, o) + t + i * Math.cos(h + 2 * Math.PI + 0.5 * s), nt(a, o) + r + n * Math.sin(h + 2 * Math.PI + 0.5 * s)]), c.push([nt(a, o) + t + 0.98 * i * Math.cos(h + s), nt(a, o) + r + 0.98 * n * Math.sin(h + s)]), c.push([nt(a, o) + t + 0.9 * i * Math.cos(h + 0.5 * s), nt(a, o) + r + 0.9 * n * Math.sin(h + 0.5 * s)]);
  }
  return [c, l];
}
function oh(e, t, r, i, n, a, s, o, l) {
  const c = a + nt(0.1, l), h = [];
  h.push([nt(o, l) + t + 0.9 * i * Math.cos(c - e), nt(o, l) + r + 0.9 * n * Math.sin(c - e)]);
  for (let u = c; u <= s; u += e) h.push([nt(o, l) + t + i * Math.cos(u), nt(o, l) + r + n * Math.sin(u)]);
  return h.push([t + i * Math.cos(s), r + n * Math.sin(s)]), h.push([t + i * Math.cos(s), r + n * Math.sin(s)]), pa(h, null, l);
}
function Tv(e, t, r, i, n, a, s, o) {
  const l = [], c = [o.maxRandomnessOffset || 1, (o.maxRandomnessOffset || 1) + 0.3];
  let h = [0, 0];
  const u = o.disableMultiStroke ? 1 : 2, f = o.preserveVertices;
  for (let d = 0; d < u; d++) d === 0 ? l.push({ op: "move", data: [s[0], s[1]] }) : l.push({ op: "move", data: [s[0] + (f ? 0 : nt(c[0], o)), s[1] + (f ? 0 : nt(c[0], o))] }), h = f ? [n, a] : [n + nt(c[d], o), a + nt(c[d], o)], l.push({ op: "bcurveTo", data: [e + nt(c[d], o), t + nt(c[d], o), r + nt(c[d], o), i + nt(c[d], o), h[0], h[1]] });
  return l;
}
function mi(e) {
  return [...e];
}
function lh(e, t = 0) {
  const r = e.length;
  if (r < 3) throw new Error("A curve must have at least three points.");
  const i = [];
  if (r === 3) i.push(mi(e[0]), mi(e[1]), mi(e[2]), mi(e[2]));
  else {
    const n = [];
    n.push(e[0], e[0]);
    for (let o = 1; o < e.length; o++) n.push(e[o]), o === e.length - 1 && n.push(e[o]);
    const a = [], s = 1 - t;
    i.push(mi(n[0]));
    for (let o = 1; o + 2 < n.length; o++) {
      const l = n[o];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (s * n[o + 1][0] - s * n[o - 1][0]) / 6, l[1] + (s * n[o + 1][1] - s * n[o - 1][1]) / 6], a[2] = [n[o + 1][0] + (s * n[o][0] - s * n[o + 2][0]) / 6, n[o + 1][1] + (s * n[o][1] - s * n[o + 2][1]) / 6], a[3] = [n[o + 1][0], n[o + 1][1]], i.push(a[1], a[2], a[3]);
    }
  }
  return i;
}
function Fn(e, t) {
  return Math.pow(e[0] - t[0], 2) + Math.pow(e[1] - t[1], 2);
}
function Bv(e, t, r) {
  const i = Fn(t, r);
  if (i === 0) return Fn(e, t);
  let n = ((e[0] - t[0]) * (r[0] - t[0]) + (e[1] - t[1]) * (r[1] - t[1])) / i;
  return n = Math.max(0, Math.min(1, n)), Fn(e, er(t, r, n));
}
function er(e, t, r) {
  return [e[0] + (t[0] - e[0]) * r, e[1] + (t[1] - e[1]) * r];
}
function ho(e, t, r, i) {
  const n = i || [];
  if ((function(o, l) {
    const c = o[l + 0], h = o[l + 1], u = o[l + 2], f = o[l + 3];
    let d = 3 * h[0] - 2 * c[0] - f[0];
    d *= d;
    let g = 3 * h[1] - 2 * c[1] - f[1];
    g *= g;
    let m = 3 * u[0] - 2 * f[0] - c[0];
    m *= m;
    let y = 3 * u[1] - 2 * f[1] - c[1];
    return y *= y, d < m && (d = m), g < y && (g = y), d + g;
  })(e, t) < r) {
    const o = e[t + 0];
    n.length ? (a = n[n.length - 1], s = o, Math.sqrt(Fn(a, s)) > 1 && n.push(o)) : n.push(o), n.push(e[t + 3]);
  } else {
    const l = e[t + 0], c = e[t + 1], h = e[t + 2], u = e[t + 3], f = er(l, c, 0.5), d = er(c, h, 0.5), g = er(h, u, 0.5), m = er(f, d, 0.5), y = er(d, g, 0.5), x = er(m, y, 0.5);
    ho([l, f, m, x], 0, r, n), ho([x, y, g, u], 0, r, n);
  }
  var a, s;
  return n;
}
function Av(e, t) {
  return ga(e, 0, e.length, t);
}
function ga(e, t, r, i, n) {
  const a = n || [], s = e[t], o = e[r - 1];
  let l = 0, c = 1;
  for (let h = t + 1; h < r - 1; ++h) {
    const u = Bv(e[h], s, o);
    u > l && (l = u, c = h);
  }
  return Math.sqrt(l) > i ? (ga(e, t, c + 1, i, a), ga(e, c, r, i, a)) : (a.length || a.push(s), a.push(o)), a;
}
function bs(e, t = 0.15, r) {
  const i = [], n = (e.length - 1) / 3;
  for (let a = 0; a < n; a++)
    ho(e, 3 * a, t, i);
  return r && r > 0 ? ga(i, 0, i.length, r) : i;
}
const Zt = "none";
class ma {
  constructor(t) {
    this.defaultOptions = { maxRandomnessOffset: 2, roughness: 1, bowing: 1, stroke: "#000", strokeWidth: 1, curveTightness: 0, curveFitting: 0.95, curveStepCount: 9, fillStyle: "hachure", fillWeight: -1, hachureAngle: -41, hachureGap: -1, dashOffset: -1, dashGap: -1, zigzagOffset: -1, seed: 0, disableMultiStroke: !1, disableMultiStrokeFill: !1, preserveVertices: !1, fillShapeRoughnessGain: 0.8 }, this.config = t || {}, this.config.options && (this.defaultOptions = this._o(this.config.options));
  }
  static newSeed() {
    return Math.floor(Math.random() * 2 ** 31);
  }
  _o(t) {
    return t ? Object.assign({}, this.defaultOptions, t) : this.defaultOptions;
  }
  _d(t, r, i) {
    return { shape: t, sets: r || [], options: i || this.defaultOptions };
  }
  line(t, r, i, n, a) {
    const s = this._o(a);
    return this._d("line", [_p(t, r, i, n, s)], s);
  }
  rectangle(t, r, i, n, a) {
    const s = this._o(a), o = [], l = Sv(t, r, i, n, s);
    if (s.fill) {
      const c = [[t, r], [t + i, r], [t + i, r + n], [t, r + n]];
      s.fillStyle === "solid" ? o.push(xs([c], s)) : o.push(Ar([c], s));
    }
    return s.stroke !== Zt && o.push(l), this._d("rectangle", o, s);
  }
  ellipse(t, r, i, n, a) {
    const s = this._o(a), o = [], l = wp(i, n, s), c = lo(t, r, s, l);
    if (s.fill) if (s.fillStyle === "solid") {
      const h = lo(t, r, s, l).opset;
      h.type = "fillPath", o.push(h);
    } else o.push(Ar([c.estimatedPoints], s));
    return s.stroke !== Zt && o.push(c.opset), this._d("ellipse", o, s);
  }
  circle(t, r, i, n) {
    const a = this.ellipse(t, r, i, i, n);
    return a.shape = "circle", a;
  }
  linearPath(t, r) {
    const i = this._o(r);
    return this._d("linearPath", [En(t, !1, i)], i);
  }
  arc(t, r, i, n, a, s, o = !1, l) {
    const c = this._o(l), h = [], u = ih(t, r, i, n, a, s, o, !0, c);
    if (o && c.fill) if (c.fillStyle === "solid") {
      const f = Object.assign({}, c);
      f.disableMultiStroke = !0;
      const d = ih(t, r, i, n, a, s, !0, !1, f);
      d.type = "fillPath", h.push(d);
    } else h.push((function(f, d, g, m, y, x, b) {
      const C = f, k = d;
      let w = Math.abs(g / 2), A = Math.abs(m / 2);
      w += nt(0.01 * w, b), A += nt(0.01 * A, b);
      let S = y, D = x;
      for (; S < 0; ) S += 2 * Math.PI, D += 2 * Math.PI;
      D - S > 2 * Math.PI && (S = 0, D = 2 * Math.PI);
      const I = (D - S) / b.curveStepCount, O = [];
      for (let $ = S; $ <= D; $ += I) O.push([C + w * Math.cos($), k + A * Math.sin($)]);
      return O.push([C + w * Math.cos(D), k + A * Math.sin(D)]), O.push([C, k]), Ar([O], b);
    })(t, r, i, n, a, s, c));
    return c.stroke !== Zt && h.push(u), this._d("arc", h, c);
  }
  curve(t, r) {
    const i = this._o(r), n = [], a = rh(t, i);
    if (i.fill && i.fill !== Zt) if (i.fillStyle === "solid") {
      const s = rh(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(s.ops) });
    } else {
      const s = [], o = t;
      if (o.length) {
        const l = typeof o[0][0] == "number" ? [o] : o;
        for (const c of l) c.length < 3 ? s.push(...c) : c.length === 3 ? s.push(...bs(lh([c[0], c[0], c[1], c[2]]), 10, (1 + i.roughness) / 2)) : s.push(...bs(lh(c), 10, (1 + i.roughness) / 2));
      }
      s.length && n.push(Ar([s], i));
    }
    return i.stroke !== Zt && n.push(a), this._d("curve", n, i);
  }
  polygon(t, r) {
    const i = this._o(r), n = [], a = En(t, !0, i);
    return i.fill && (i.fillStyle === "solid" ? n.push(xs([t], i)) : n.push(Ar([t], i))), i.stroke !== Zt && n.push(a), this._d("polygon", n, i);
  }
  path(t, r) {
    const i = this._o(r), n = [];
    if (!t) return this._d("path", n, i);
    t = (t || "").replace(/\n/g, " ").replace(/(-\s)/g, "-").replace("/(ss)/g", " ");
    const a = i.fill && i.fill !== "transparent" && i.fill !== Zt, s = i.stroke !== Zt, o = !!(i.simplification && i.simplification < 1), l = (function(h, u, f) {
      const d = bp(xp(xl(h))), g = [];
      let m = [], y = [0, 0], x = [];
      const b = () => {
        x.length >= 4 && m.push(...bs(x, u)), x = [];
      }, C = () => {
        b(), m.length && (g.push(m), m = []);
      };
      for (const { key: w, data: A } of d) switch (w) {
        case "M":
          C(), y = [A[0], A[1]], m.push(y);
          break;
        case "L":
          b(), m.push([A[0], A[1]]);
          break;
        case "C":
          if (!x.length) {
            const S = m.length ? m[m.length - 1] : y;
            x.push([S[0], S[1]]);
          }
          x.push([A[0], A[1]]), x.push([A[2], A[3]]), x.push([A[4], A[5]]);
          break;
        case "Z":
          b(), m.push([y[0], y[1]]);
      }
      if (C(), !f) return g;
      const k = [];
      for (const w of g) {
        const A = Av(w, f);
        A.length && k.push(A);
      }
      return k;
    })(t, 1, o ? 4 - 4 * (i.simplification || 1) : (1 + i.roughness) / 2), c = nh(t, i);
    if (a) if (i.fillStyle === "solid") if (l.length === 1) {
      const h = nh(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(h.ops) });
    } else n.push(xs(l, i));
    else n.push(Ar(l, i));
    return s && (o ? l.forEach(((h) => {
      n.push(En(h, !1, i));
    })) : n.push(c)), this._d("path", n, i);
  }
  opsToPath(t, r) {
    let i = "";
    for (const n of t.ops) {
      const a = typeof r == "number" && r >= 0 ? n.data.map(((s) => +s.toFixed(r))) : n.data;
      switch (n.op) {
        case "move":
          i += `M${a[0]} ${a[1]} `;
          break;
        case "bcurveTo":
          i += `C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;
          break;
        case "lineTo":
          i += `L${a[0]} ${a[1]} `;
      }
    }
    return i.trim();
  }
  toPaths(t) {
    const r = t.sets || [], i = t.options || this.defaultOptions, n = [];
    for (const a of r) {
      let s = null;
      switch (a.type) {
        case "path":
          s = { d: this.opsToPath(a), stroke: i.stroke, strokeWidth: i.strokeWidth, fill: Zt };
          break;
        case "fillPath":
          s = { d: this.opsToPath(a), stroke: Zt, strokeWidth: 0, fill: i.fill || Zt };
          break;
        case "fillSketch":
          s = this.fillSketch(a, i);
      }
      s && n.push(s);
    }
    return n;
  }
  fillSketch(t, r) {
    let i = r.fillWeight;
    return i < 0 && (i = r.strokeWidth / 2), { d: this.opsToPath(t), stroke: r.fill || Zt, strokeWidth: i, fill: Zt };
  }
  _mergedShape(t) {
    return t.filter(((r, i) => i === 0 || r.op !== "move"));
  }
}
class Lv {
  constructor(t, r) {
    this.canvas = t, this.ctx = this.canvas.getContext("2d"), this.gen = new ma(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.ctx, a = t.options.fixedDecimalPlaceDigits;
    for (const s of r) switch (s.type) {
      case "path":
        n.save(), n.strokeStyle = i.stroke === "none" ? "transparent" : i.stroke, n.lineWidth = i.strokeWidth, i.strokeLineDash && n.setLineDash(i.strokeLineDash), i.strokeLineDashOffset && (n.lineDashOffset = i.strokeLineDashOffset), this._drawToContext(n, s, a), n.restore();
        break;
      case "fillPath": {
        n.save(), n.fillStyle = i.fill || "";
        const o = t.shape === "curve" || t.shape === "polygon" || t.shape === "path" ? "evenodd" : "nonzero";
        this._drawToContext(n, s, a, o), n.restore();
        break;
      }
      case "fillSketch":
        this.fillSketch(n, s, i);
    }
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2), t.save(), i.fillLineDash && t.setLineDash(i.fillLineDash), i.fillLineDashOffset && (t.lineDashOffset = i.fillLineDashOffset), t.strokeStyle = i.fill || "", t.lineWidth = n, this._drawToContext(t, r, i.fixedDecimalPlaceDigits), t.restore();
  }
  _drawToContext(t, r, i, n = "nonzero") {
    t.beginPath();
    for (const a of r.ops) {
      const s = typeof i == "number" && i >= 0 ? a.data.map(((o) => +o.toFixed(i))) : a.data;
      switch (a.op) {
        case "move":
          t.moveTo(s[0], s[1]);
          break;
        case "bcurveTo":
          t.bezierCurveTo(s[0], s[1], s[2], s[3], s[4], s[5]);
          break;
        case "lineTo":
          t.lineTo(s[0], s[1]);
      }
    }
    r.type === "fillPath" ? t.fill(n) : t.stroke();
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  line(t, r, i, n, a) {
    const s = this.gen.line(t, r, i, n, a);
    return this.draw(s), s;
  }
  rectangle(t, r, i, n, a) {
    const s = this.gen.rectangle(t, r, i, n, a);
    return this.draw(s), s;
  }
  ellipse(t, r, i, n, a) {
    const s = this.gen.ellipse(t, r, i, n, a);
    return this.draw(s), s;
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a), a;
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i), i;
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i), i;
  }
  arc(t, r, i, n, a, s, o = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, s, o, l);
    return this.draw(c), c;
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i), i;
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i), i;
  }
}
const bn = "http://www.w3.org/2000/svg";
class Mv {
  constructor(t, r) {
    this.svg = t, this.gen = new ma(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.svg.ownerDocument || window.document, a = n.createElementNS(bn, "g"), s = t.options.fixedDecimalPlaceDigits;
    for (const o of r) {
      let l = null;
      switch (o.type) {
        case "path":
          l = n.createElementNS(bn, "path"), l.setAttribute("d", this.opsToPath(o, s)), l.setAttribute("stroke", i.stroke), l.setAttribute("stroke-width", i.strokeWidth + ""), l.setAttribute("fill", "none"), i.strokeLineDash && l.setAttribute("stroke-dasharray", i.strokeLineDash.join(" ").trim()), i.strokeLineDashOffset && l.setAttribute("stroke-dashoffset", `${i.strokeLineDashOffset}`);
          break;
        case "fillPath":
          l = n.createElementNS(bn, "path"), l.setAttribute("d", this.opsToPath(o, s)), l.setAttribute("stroke", "none"), l.setAttribute("stroke-width", "0"), l.setAttribute("fill", i.fill || ""), t.shape !== "curve" && t.shape !== "polygon" || l.setAttribute("fill-rule", "evenodd");
          break;
        case "fillSketch":
          l = this.fillSketch(n, o, i);
      }
      l && a.appendChild(l);
    }
    return a;
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2);
    const a = t.createElementNS(bn, "path");
    return a.setAttribute("d", this.opsToPath(r, i.fixedDecimalPlaceDigits)), a.setAttribute("stroke", i.fill || ""), a.setAttribute("stroke-width", n + ""), a.setAttribute("fill", "none"), i.fillLineDash && a.setAttribute("stroke-dasharray", i.fillLineDash.join(" ").trim()), i.fillLineDashOffset && a.setAttribute("stroke-dashoffset", `${i.fillLineDashOffset}`), a;
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  opsToPath(t, r) {
    return this.gen.opsToPath(t, r);
  }
  line(t, r, i, n, a) {
    const s = this.gen.line(t, r, i, n, a);
    return this.draw(s);
  }
  rectangle(t, r, i, n, a) {
    const s = this.gen.rectangle(t, r, i, n, a);
    return this.draw(s);
  }
  ellipse(t, r, i, n, a) {
    const s = this.gen.ellipse(t, r, i, n, a);
    return this.draw(s);
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a);
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i);
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i);
  }
  arc(t, r, i, n, a, s, o = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, s, o, l);
    return this.draw(c);
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i);
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i);
  }
}
var j = { canvas: (e, t) => new Lv(e, t), svg: (e, t) => new Mv(e, t), generator: (e) => new ma(e), newSeed: () => ma.newSeed() }, it = /* @__PURE__ */ p(async (e, t, r) => {
  let i;
  const n = t.useHtmlLabels || Bt(ft()?.htmlLabels);
  r ? i = r : i = "node default";
  const a = e.insert("g").attr("class", i).attr("id", t.domId || t.id), s = a.insert("g").attr("class", "label").attr("style", Rt(t.labelStyle));
  let o;
  t.label === void 0 ? o = "" : o = typeof t.label == "string" ? t.label : t.label[0];
  const l = await Xe(s, te(Cr(o), ft()), {
    useHtmlLabels: n,
    width: t.width || ft().flowchart?.wrappingWidth,
    // @ts-expect-error -- This is currently not used. Should this be `classes` instead?
    cssClasses: "markdown-node-label",
    style: t.labelStyle,
    addSvgBackground: !!t.icon || !!t.img
  });
  let c = l.getBBox();
  const h = (t?.padding ?? 0) / 2;
  if (n) {
    const u = l.children[0], f = ht(l), d = u.getElementsByTagName("img");
    if (d) {
      const g = o.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...d].map(
          (m) => new Promise((y) => {
            function x() {
              if (m.style.display = "flex", m.style.flexDirection = "column", g) {
                const b = ft().fontSize ? ft().fontSize : window.getComputedStyle(document.body).fontSize, C = 5, [k = Rh.fontSize] = Oa(b), w = k * C + "px";
                m.style.minWidth = w, m.style.maxWidth = w;
              } else
                m.style.width = "100%";
              y(m);
            }
            p(x, "setupImage"), setTimeout(() => {
              m.complete && x();
            }), m.addEventListener("error", x), m.addEventListener("load", x);
          })
        )
      );
    }
    c = u.getBoundingClientRect(), f.attr("width", c.width), f.attr("height", c.height);
  }
  return n ? s.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")") : s.attr("transform", "translate(0, " + -c.height / 2 + ")"), t.centerLabel && s.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")"), s.insert("rect", ":first-child"), { shapeSvg: a, bbox: c, halfPadding: h, label: s };
}, "labelHelper"), Cs = /* @__PURE__ */ p(async (e, t, r) => {
  const i = r.useHtmlLabels || Bt(ft()?.flowchart?.htmlLabels), n = e.insert("g").attr("class", "label").attr("style", r.labelStyle || ""), a = await Xe(n, te(Cr(t), ft()), {
    useHtmlLabels: i,
    width: r.width || ft()?.flowchart?.wrappingWidth,
    style: r.labelStyle,
    addSvgBackground: !!r.icon || !!r.img
  });
  let s = a.getBBox();
  const o = r.padding / 2;
  if (Bt(ft()?.flowchart?.htmlLabels)) {
    const l = a.children[0], c = ht(a);
    s = l.getBoundingClientRect(), c.attr("width", s.width), c.attr("height", s.height);
  }
  return i ? n.attr("transform", "translate(" + -s.width / 2 + ", " + -s.height / 2 + ")") : n.attr("transform", "translate(0, " + -s.height / 2 + ")"), r.centerLabel && n.attr("transform", "translate(" + -s.width / 2 + ", " + -s.height / 2 + ")"), n.insert("rect", ":first-child"), { shapeSvg: e, bbox: s, halfPadding: o, label: n };
}, "insertLabel"), G = /* @__PURE__ */ p((e, t) => {
  const r = t.node().getBBox();
  e.width = r.width, e.height = r.height;
}, "updateNodeBounds"), rt = /* @__PURE__ */ p((e, t) => (e.look === "handDrawn" ? "rough-node" : "node") + " " + e.cssClasses + " " + (t || ""), "getNodeClasses");
function lt(e) {
  const t = e.map((r, i) => `${i === 0 ? "M" : "L"}${r.x},${r.y}`);
  return t.push("Z"), t.join(" ");
}
p(lt, "createPathFromPoints");
function Ue(e, t, r, i, n, a) {
  const s = [], l = r - e, c = i - t, h = l / a, u = 2 * Math.PI / h, f = t + c / 2;
  for (let d = 0; d <= 50; d++) {
    const g = d / 50, m = e + g * l, y = f + n * Math.sin(u * (m - e));
    s.push({ x: m, y });
  }
  return s;
}
p(Ue, "generateFullSineWavePoints");
function qi(e, t, r, i, n, a) {
  const s = [], o = n * Math.PI / 180, h = (a * Math.PI / 180 - o) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = o + u * h, d = e + r * Math.cos(f), g = t + r * Math.sin(f);
    s.push({ x: -d, y: -g });
  }
  return s;
}
p(qi, "generateCirclePoints");
var $v = /* @__PURE__ */ p((e, t) => {
  var r = e.x, i = e.y, n = t.x - r, a = t.y - i, s = e.width / 2, o = e.height / 2, l, c;
  return Math.abs(a) * s > Math.abs(n) * o ? (a < 0 && (o = -o), l = a === 0 ? 0 : o * n / a, c = o) : (n < 0 && (s = -s), l = s, c = n === 0 ? 0 : s * a / n), { x: r + l, y: i + c };
}, "intersectRect"), ri = $v;
function vp(e, t) {
  t && e.attr("style", t);
}
p(vp, "applyStyle");
async function Sp(e) {
  const t = ht(document.createElementNS("http://www.w3.org/2000/svg", "foreignObject")), r = t.append("xhtml:div"), i = ft();
  let n = e.label;
  e.label && Yr(e.label) && (n = await So(e.label.replace(Qr.lineBreakRegex, `
`), i));
  const s = '<span class="' + (e.isNode ? "nodeLabel" : "edgeLabel") + '" ' + (e.labelStyle ? 'style="' + e.labelStyle + '"' : "") + // codeql [js/html-constructed-from-input] : false positive
  ">" + n + "</span>";
  return r.html(te(s, i)), vp(r, e.labelStyle), r.style("display", "inline-block"), r.style("padding-right", "1px"), r.style("white-space", "nowrap"), r.attr("xmlns", "http://www.w3.org/1999/xhtml"), t.node();
}
p(Sp, "addHtmlLabel");
var Ev = /* @__PURE__ */ p(async (e, t, r, i) => {
  let n = e || "";
  if (typeof n == "object" && (n = n[0]), Bt(ft().flowchart.htmlLabels)) {
    n = n.replace(/\\n|\n/g, "<br />"), F.info("vertexText" + n);
    const a = {
      isNode: i,
      label: Cr(n).replace(
        /fa[blrs]?:fa-[\w-]+/g,
        (o) => `<i class='${o.replace(":", " ")}'></i>`
      ),
      labelStyle: t && t.replace("fill:", "color:")
    };
    return await Sp(a);
  } else {
    const a = document.createElementNS("http://www.w3.org/2000/svg", "text");
    a.setAttribute("style", t.replace("color:", "fill:"));
    let s = [];
    typeof n == "string" ? s = n.split(/\\n|\n|<br\s*\/?>/gi) : Array.isArray(n) ? s = n : s = [];
    for (const o of s) {
      const l = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
      l.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), l.setAttribute("dy", "1em"), l.setAttribute("x", "0"), r ? l.setAttribute("class", "title-row") : l.setAttribute("class", "row"), l.textContent = o.trim(), a.appendChild(l);
    }
    return a;
  }
}, "createLabel"), or = Ev, Ve = /* @__PURE__ */ p((e, t, r, i, n) => [
  "M",
  e + n,
  t,
  // Move to the first point
  "H",
  e + r - n,
  // Draw horizontal line to the beginning of the right corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r,
  t + n,
  // Draw arc to the right top corner
  "V",
  t + i - n,
  // Draw vertical line down to the beginning of the right bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r - n,
  t + i,
  // Draw arc to the right bottom corner
  "H",
  e + n,
  // Draw horizontal line to the beginning of the left bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e,
  t + i - n,
  // Draw arc to the left bottom corner
  "V",
  t + n,
  // Draw vertical line up to the beginning of the left top corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + n,
  t,
  // Draw arc to the left top corner
  "Z"
  // Close the path
].join(" "), "createRoundedRectPathD"), Tp = /* @__PURE__ */ p(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: s } = i, { labelStyles: o, nodeStyles: l, borderStyles: c, backgroundStyles: h } = U(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = Bt(r.flowchart.htmlLabels), d = u.insert("g").attr("class", "cluster-label "), g = await Xe(d, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0
  });
  let m = g.getBBox();
  if (Bt(r.flowchart.htmlLabels)) {
    const S = g.children[0], D = ht(g);
    m = S.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, C = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let k;
  if (t.look === "handDrawn") {
    const S = j.svg(u), D = Y(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: s,
      fillWeight: 3,
      seed: n
    }), I = S.path(Ve(b, C, y, x, 0), D);
    k = u.insert(() => (F.debug("Rough node insert CXC", I), I), ":first-child"), k.select("path:nth-child(2)").attr("style", c.join(";")), k.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    k = u.insert("rect", ":first-child"), k.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", C).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: w } = Zo(r);
  if (d.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + w})`
  ), o) {
    const S = d.select("span");
    S && S.attr("style", o);
  }
  const A = k.node().getBBox();
  return t.offsetX = 0, t.width = A.width, t.height = A.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(S) {
    return ri(t, S);
  }, { cluster: u, labelBBox: m };
}, "rect"), Fv = /* @__PURE__ */ p((e, t) => {
  const r = e.insert("g").attr("class", "note-cluster").attr("id", t.id), i = r.insert("rect", ":first-child"), n = 0 * t.padding, a = n / 2;
  i.attr("rx", t.rx).attr("ry", t.ry).attr("x", t.x - t.width / 2 - a).attr("y", t.y - t.height / 2 - a).attr("width", t.width + n).attr("height", t.height + n).attr("fill", "none");
  const s = i.node().getBBox();
  return t.width = s.width, t.height = s.height, t.intersect = function(o) {
    return ri(t, o);
  }, { cluster: r, labelBBox: { width: 0, height: 0 } };
}, "noteGroup"), Dv = /* @__PURE__ */ p(async (e, t) => {
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { altBackground: a, compositeBackground: s, compositeTitleBackground: o, nodeBorder: l } = i, c = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-id", t.id).attr("data-look", t.look), h = c.insert("g", ":first-child"), u = c.insert("g").attr("class", "cluster-label");
  let f = c.append("rect");
  const d = u.node().appendChild(await or(t.label, t.labelStyle, void 0, !0));
  let g = d.getBBox();
  if (Bt(r.flowchart.htmlLabels)) {
    const I = d.children[0], O = ht(d);
    g = I.getBoundingClientRect(), O.attr("width", g.width), O.attr("height", g.height);
  }
  const m = 0 * t.padding, y = m / 2, x = (t.width <= g.width + t.padding ? g.width + t.padding : t.width) + m;
  t.width <= g.width + t.padding ? t.diff = (x - t.width) / 2 - t.padding : t.diff = -t.padding;
  const b = t.height + m, C = t.height + m - g.height - 6, k = t.x - x / 2, w = t.y - b / 2;
  t.width = x;
  const A = t.y - t.height / 2 - y + g.height + 2;
  let S;
  if (t.look === "handDrawn") {
    const I = t.cssClasses.includes("statediagram-cluster-alt"), O = j.svg(c), $ = t.rx || t.ry ? O.path(Ve(k, w, x, b, 10), {
      roughness: 0.7,
      fill: o,
      fillStyle: "solid",
      stroke: l,
      seed: n
    }) : O.rectangle(k, w, x, b, { seed: n });
    S = c.insert(() => $, ":first-child");
    const N = O.rectangle(k, A, x, C, {
      fill: I ? a : s,
      fillStyle: I ? "hachure" : "solid",
      stroke: l,
      seed: n
    });
    S = c.insert(() => $, ":first-child"), f = c.insert(() => N);
  } else
    S = h.insert("rect", ":first-child"), S.attr("class", "outer").attr("x", k).attr("y", w).attr("width", x).attr("height", b).attr("data-look", t.look), f.attr("class", "inner").attr("x", k).attr("y", A).attr("width", x).attr("height", C);
  u.attr(
    "transform",
    `translate(${t.x - g.width / 2}, ${w + 1 - (Bt(r.flowchart.htmlLabels) ? 0 : 3)})`
  );
  const D = S.node().getBBox();
  return t.height = D.height, t.offsetX = 0, t.offsetY = g.height - t.padding / 2, t.labelBBox = g, t.intersect = function(I) {
    return ri(t, I);
  }, { cluster: c, labelBBox: g };
}, "roundedWithTitle"), Ov = /* @__PURE__ */ p(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: s } = i, { labelStyles: o, nodeStyles: l, borderStyles: c, backgroundStyles: h } = U(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = Bt(r.flowchart.htmlLabels), d = u.insert("g").attr("class", "cluster-label "), g = await Xe(d, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0,
    width: t.width
  });
  let m = g.getBBox();
  if (Bt(r.flowchart.htmlLabels)) {
    const S = g.children[0], D = ht(g);
    m = S.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, C = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let k;
  if (t.look === "handDrawn") {
    const S = j.svg(u), D = Y(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: s,
      fillWeight: 4,
      seed: n
    }), I = S.path(Ve(b, C, y, x, t.rx), D);
    k = u.insert(() => (F.debug("Rough node insert CXC", I), I), ":first-child"), k.select("path:nth-child(2)").attr("style", c.join(";")), k.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    k = u.insert("rect", ":first-child"), k.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", C).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: w } = Zo(r);
  if (d.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + w})`
  ), o) {
    const S = d.select("span");
    S && S.attr("style", o);
  }
  const A = k.node().getBBox();
  return t.offsetX = 0, t.width = A.width, t.height = A.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(S) {
    return ri(t, S);
  }, { cluster: u, labelBBox: m };
}, "kanbanSection"), Rv = /* @__PURE__ */ p((e, t) => {
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { nodeBorder: a } = i, s = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-look", t.look), o = s.insert("g", ":first-child"), l = 0 * t.padding, c = t.width + l;
  t.diff = -t.padding;
  const h = t.height + l, u = t.x - c / 2, f = t.y - h / 2;
  t.width = c;
  let d;
  if (t.look === "handDrawn") {
    const y = j.svg(s).rectangle(u, f, c, h, {
      fill: "lightgrey",
      roughness: 0.5,
      strokeLineDash: [5],
      stroke: a,
      seed: n
    });
    d = s.insert(() => y, ":first-child");
  } else
    d = o.insert("rect", ":first-child"), d.attr("class", "divider").attr("x", u).attr("y", f).attr("width", c).attr("height", h).attr("data-look", t.look);
  const g = d.node().getBBox();
  return t.height = g.height, t.offsetX = 0, t.offsetY = 0, t.intersect = function(m) {
    return ri(t, m);
  }, { cluster: s, labelBBox: {} };
}, "divider"), Iv = Tp, Pv = {
  rect: Tp,
  squareRect: Iv,
  roundedWithTitle: Dv,
  noteGroup: Fv,
  divider: Rv,
  kanbanSection: Ov
}, Bp = /* @__PURE__ */ new Map(), Nv = /* @__PURE__ */ p(async (e, t) => {
  const r = t.shape || "rect", i = await Pv[r](e, t);
  return Bp.set(t.id, i), i;
}, "insertCluster"), dL = /* @__PURE__ */ p(() => {
  Bp = /* @__PURE__ */ new Map();
}, "clear");
function Ap(e, t) {
  return e.intersect(t);
}
p(Ap, "intersectNode");
var zv = Ap;
function Lp(e, t, r, i) {
  var n = e.x, a = e.y, s = n - i.x, o = a - i.y, l = Math.sqrt(t * t * o * o + r * r * s * s), c = Math.abs(t * r * s / l);
  i.x < n && (c = -c);
  var h = Math.abs(t * r * o / l);
  return i.y < a && (h = -h), { x: n + c, y: a + h };
}
p(Lp, "intersectEllipse");
var Mp = Lp;
function $p(e, t, r) {
  return Mp(e, t, t, r);
}
p($p, "intersectCircle");
var Wv = $p;
function Ep(e, t, r, i) {
  {
    const n = t.y - e.y, a = e.x - t.x, s = t.x * e.y - e.x * t.y, o = n * r.x + a * r.y + s, l = n * i.x + a * i.y + s, c = 1e-6;
    if (o !== 0 && l !== 0 && uo(o, l))
      return;
    const h = i.y - r.y, u = r.x - i.x, f = i.x * r.y - r.x * i.y, d = h * e.x + u * e.y + f, g = h * t.x + u * t.y + f;
    if (Math.abs(d) < c && Math.abs(g) < c && uo(d, g))
      return;
    const m = n * u - h * a;
    if (m === 0)
      return;
    const y = Math.abs(m / 2);
    let x = a * f - u * s;
    const b = x < 0 ? (x - y) / m : (x + y) / m;
    x = h * s - n * f;
    const C = x < 0 ? (x - y) / m : (x + y) / m;
    return { x: b, y: C };
  }
}
p(Ep, "intersectLine");
function uo(e, t) {
  return e * t > 0;
}
p(uo, "sameSign");
var qv = Ep;
function Fp(e, t, r) {
  let i = e.x, n = e.y, a = [], s = Number.POSITIVE_INFINITY, o = Number.POSITIVE_INFINITY;
  typeof t.forEach == "function" ? t.forEach(function(h) {
    s = Math.min(s, h.x), o = Math.min(o, h.y);
  }) : (s = Math.min(s, t.x), o = Math.min(o, t.y));
  let l = i - e.width / 2 - s, c = n - e.height / 2 - o;
  for (let h = 0; h < t.length; h++) {
    let u = t[h], f = t[h < t.length - 1 ? h + 1 : 0], d = qv(
      e,
      r,
      { x: l + u.x, y: c + u.y },
      { x: l + f.x, y: c + f.y }
    );
    d && a.push(d);
  }
  return a.length ? (a.length > 1 && a.sort(function(h, u) {
    let f = h.x - r.x, d = h.y - r.y, g = Math.sqrt(f * f + d * d), m = u.x - r.x, y = u.y - r.y, x = Math.sqrt(m * m + y * y);
    return g < x ? -1 : g === x ? 0 : 1;
  }), a[0]) : e;
}
p(Fp, "intersectPolygon");
var Hv = Fp, W = {
  node: zv,
  circle: Wv,
  ellipse: Mp,
  polygon: Hv,
  rect: ri
};
function Dp(e, t) {
  const { labelStyles: r } = U(t);
  t.labelStyle = r;
  const i = rt(t);
  let n = i;
  i || (n = "anchor");
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), s = 1, { cssStyles: o } = t, l = j.svg(a), c = Y(t, { fill: "black", stroke: "none", fillStyle: "solid" });
  t.look !== "handDrawn" && (c.roughness = 0);
  const h = l.circle(0, 0, s * 2, c), u = a.insert(() => h, ":first-child");
  return u.attr("class", "anchor").attr("style", Rt(o)), G(t, u), t.intersect = function(f) {
    return F.info("Circle intersect", t, s, f), W.circle(t, s, f);
  }, a;
}
p(Dp, "anchor");
function fo(e, t, r, i, n, a, s) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, d = u / n, g = f / a, m = Math.sqrt(d ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const y = Math.sqrt(1 - m ** 2), x = l + y * a * Math.sin(h) * (s ? -1 : 1), b = c - y * n * Math.cos(h) * (s ? -1 : 1), C = Math.atan2((t - b) / a, (e - x) / n);
  let w = Math.atan2((i - b) / a, (r - x) / n) - C;
  s && w < 0 && (w += 2 * Math.PI), !s && w > 0 && (w -= 2 * Math.PI);
  const A = [];
  for (let S = 0; S < 20; S++) {
    const D = S / 19, I = C + D * w, O = x + n * Math.cos(I), $ = b + a * Math.sin(I);
    A.push({ x: O, y: $ });
  }
  return A;
}
p(fo, "generateArcPoints");
async function Op(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.width + t.padding + 20, o = a.height + t.padding, l = o / 2, c = l / (2.5 + o / 50), { cssStyles: h } = t, u = [
    { x: s / 2, y: -o / 2 },
    { x: -s / 2, y: -o / 2 },
    ...fo(-s / 2, -o / 2, -s / 2, o / 2, c, l, !1),
    { x: s / 2, y: o / 2 },
    ...fo(s / 2, o / 2, s / 2, -o / 2, c, l, !0)
  ], f = j.svg(n), d = Y(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = lt(u), m = f.path(g, d), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(${c / 2}, 0)`), G(t, y), t.intersect = function(x) {
    return W.polygon(t, u, x);
  }, n;
}
p(Op, "bowTieRect");
function Ze(e, t, r, i) {
  return e.insert("polygon", ":first-child").attr(
    "points",
    i.map(function(n) {
      return n.x + "," + n.y;
    }).join(" ")
  ).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + r / 2 + ")");
}
p(Ze, "insertPolygonShape");
async function Rp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.height + t.padding, o = 12, l = a.width + t.padding + o, c = 0, h = l, u = -s, f = 0, d = [
    { x: c + o, y: u },
    { x: h, y: u },
    { x: h, y: f },
    { x: c, y: f },
    { x: c, y: u + o },
    { x: c + o, y: u }
  ];
  let g;
  const { cssStyles: m } = t;
  if (t.look === "handDrawn") {
    const y = j.svg(n), x = Y(t, {}), b = lt(d), C = y.path(b, x);
    g = n.insert(() => C, ":first-child").attr("transform", `translate(${-l / 2}, ${s / 2})`), m && g.attr("style", m);
  } else
    g = Ze(n, l, s, d);
  return i && g.attr("style", i), G(t, g), t.intersect = function(y) {
    return W.polygon(t, d, y);
  }, n;
}
p(Rp, "card");
function Ip(e, t) {
  const { nodeStyles: r } = U(t);
  t.label = "";
  const i = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), { cssStyles: n } = t, a = Math.max(28, t.width ?? 0), s = [
    { x: 0, y: a / 2 },
    { x: a / 2, y: 0 },
    { x: 0, y: -a / 2 },
    { x: -a / 2, y: 0 }
  ], o = j.svg(i), l = Y(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = lt(s), h = o.path(c, l), u = i.insert(() => h, ":first-child");
  return n && t.look !== "handDrawn" && u.selectAll("path").attr("style", n), r && t.look !== "handDrawn" && u.selectAll("path").attr("style", r), t.width = 28, t.height = 28, t.intersect = function(f) {
    return W.polygon(t, s, f);
  }, i;
}
p(Ip, "choice");
async function bl(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = U(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: s, halfPadding: o } = await it(e, t, rt(t)), l = r?.padding ?? o, c = s.width / 2 + l;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const f = j.svg(a), d = Y(t, {}), g = f.circle(0, 0, c * 2, d);
    h = a.insert(() => g, ":first-child"), h.attr("class", "basic label-container").attr("style", Rt(u));
  } else
    h = a.insert("circle", ":first-child").attr("class", "basic label-container").attr("style", n).attr("r", c).attr("cx", 0).attr("cy", 0);
  return G(t, h), t.calcIntersect = function(f, d) {
    const g = f.width / 2;
    return W.circle(f, g, d);
  }, t.intersect = function(f) {
    return F.info("Circle intersect", t, c, f), W.circle(t, c, f);
  }, a;
}
p(bl, "circle");
function Pp(e) {
  const t = Math.cos(Math.PI / 4), r = Math.sin(Math.PI / 4), i = e * 2, n = { x: i / 2 * t, y: i / 2 * r }, a = { x: -(i / 2) * t, y: i / 2 * r }, s = { x: -(i / 2) * t, y: -(i / 2) * r }, o = { x: i / 2 * t, y: -(i / 2) * r };
  return `M ${a.x},${a.y} L ${o.x},${o.y}
                   M ${n.x},${n.y} L ${s.x},${s.y}`;
}
p(Pp, "createLine");
function Np(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r, t.label = "";
  const n = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), a = Math.max(30, t?.width ?? 0), { cssStyles: s } = t, o = j.svg(n), l = Y(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = o.circle(0, 0, a * 2, l), h = Pp(a), u = o.path(h, l), f = n.insert(() => c, ":first-child");
  return f.insert(() => u), s && t.look !== "handDrawn" && f.selectAll("path").attr("style", s), i && t.look !== "handDrawn" && f.selectAll("path").attr("style", i), G(t, f), t.intersect = function(d) {
    return F.info("crossedCircle intersect", t, { radius: a, point: d }), W.circle(t, a, d);
  }, n;
}
p(Np, "crossedCircle");
function Me(e, t, r, i = 100, n = 0, a = 180) {
  const s = [], o = n * Math.PI / 180, h = (a * Math.PI / 180 - o) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = o + u * h, d = e + r * Math.cos(f), g = t + r * Math.sin(f);
    s.push({ x: -d, y: -g });
  }
  return s;
}
p(Me, "generateCirclePoints");
async function zp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...Me(o / 2, -l / 2, c, 30, -90, 0),
    { x: -o / 2 - c, y: c },
    ...Me(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...Me(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: -o / 2 - c, y: -l / 2 },
    ...Me(o / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: o / 2, y: -l / 2 - c },
    { x: -o / 2, y: -l / 2 - c },
    ...Me(o / 2, -l / 2, c, 20, -90, 0),
    { x: -o / 2 - c, y: -c },
    ...Me(o / 2 + o * 0.1, -c, c, 20, -180, -270),
    ...Me(o / 2 + o * 0.1, c, c, 20, -90, -180),
    { x: -o / 2 - c, y: l / 2 },
    ...Me(o / 2, l / 2, c, 20, 0, 90),
    { x: -o / 2, y: l / 2 + c },
    { x: o / 2, y: l / 2 + c }
  ], d = j.svg(n), g = Y(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = lt(u).replace("Z", ""), x = d.path(y, g), b = lt(f), C = d.path(b, { ...g }), k = n.insert("g", ":first-child");
  return k.insert(() => C, ":first-child").attr("stroke-opacity", 0), k.insert(() => x, ":first-child"), k.attr("class", "text"), h && t.look !== "handDrawn" && k.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(${c}, 0)`), s.attr(
    "transform",
    `translate(${-o / 2 + c - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), G(t, k), t.intersect = function(w) {
    return W.polygon(t, f, w);
  }, n;
}
p(zp, "curlyBraceLeft");
function $e(e, t, r, i = 100, n = 0, a = 180) {
  const s = [], o = n * Math.PI / 180, h = (a * Math.PI / 180 - o) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = o + u * h, d = e + r * Math.cos(f), g = t + r * Math.sin(f);
    s.push({ x: d, y: g });
  }
  return s;
}
p($e, "generateCirclePoints");
async function Wp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...$e(o / 2, -l / 2, c, 20, -90, 0),
    { x: o / 2 + c, y: -c },
    ...$e(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...$e(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: o / 2 + c, y: l / 2 },
    ...$e(o / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: -o / 2, y: -l / 2 - c },
    { x: o / 2, y: -l / 2 - c },
    ...$e(o / 2, -l / 2, c, 20, -90, 0),
    { x: o / 2 + c, y: -c },
    ...$e(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...$e(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: o / 2 + c, y: l / 2 },
    ...$e(o / 2, l / 2, c, 20, 0, 90),
    { x: o / 2, y: l / 2 + c },
    { x: -o / 2, y: l / 2 + c }
  ], d = j.svg(n), g = Y(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = lt(u).replace("Z", ""), x = d.path(y, g), b = lt(f), C = d.path(b, { ...g }), k = n.insert("g", ":first-child");
  return k.insert(() => C, ":first-child").attr("stroke-opacity", 0), k.insert(() => x, ":first-child"), k.attr("class", "text"), h && t.look !== "handDrawn" && k.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(${-c}, 0)`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), G(t, k), t.intersect = function(w) {
    return W.polygon(t, f, w);
  }, n;
}
p(Wp, "curlyBraceRight");
function Lt(e, t, r, i = 100, n = 0, a = 180) {
  const s = [], o = n * Math.PI / 180, h = (a * Math.PI / 180 - o) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = o + u * h, d = e + r * Math.cos(f), g = t + r * Math.sin(f);
    s.push({ x: -d, y: -g });
  }
  return s;
}
p(Lt, "generateCirclePoints");
async function qp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...Lt(o / 2, -l / 2, c, 30, -90, 0),
    { x: -o / 2 - c, y: c },
    ...Lt(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...Lt(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: -o / 2 - c, y: -l / 2 },
    ...Lt(o / 2, l / 2, c, 20, 0, 90)
  ], f = [
    ...Lt(-o / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: o / 2 - c / 2, y: c },
    ...Lt(-o / 2 - c / 2, -c, c, 20, 0, 90),
    ...Lt(-o / 2 - c / 2, c, c, 20, -90, 0),
    { x: o / 2 - c / 2, y: -c },
    ...Lt(-o / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], d = [
    { x: o / 2, y: -l / 2 - c },
    { x: -o / 2, y: -l / 2 - c },
    ...Lt(o / 2, -l / 2, c, 20, -90, 0),
    { x: -o / 2 - c, y: -c },
    ...Lt(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...Lt(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: -o / 2 - c, y: l / 2 },
    ...Lt(o / 2, l / 2, c, 20, 0, 90),
    { x: -o / 2, y: l / 2 + c },
    { x: o / 2 - c - c / 2, y: l / 2 + c },
    ...Lt(-o / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: o / 2 - c / 2, y: c },
    ...Lt(-o / 2 - c / 2, -c, c, 20, 0, 90),
    ...Lt(-o / 2 - c / 2, c, c, 20, -90, 0),
    { x: o / 2 - c / 2, y: -c },
    ...Lt(-o / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], g = j.svg(n), m = Y(t, { fill: "none" });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = lt(u).replace("Z", ""), b = g.path(x, m), k = lt(f).replace("Z", ""), w = g.path(k, m), A = lt(d), S = g.path(A, { ...m }), D = n.insert("g", ":first-child");
  return D.insert(() => S, ":first-child").attr("stroke-opacity", 0), D.insert(() => b, ":first-child"), D.insert(() => w, ":first-child"), D.attr("class", "text"), h && t.look !== "handDrawn" && D.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(${c - c / 4}, 0)`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), G(t, D), t.intersect = function(I) {
    return W.polygon(t, d, I);
  }, n;
}
p(qp, "curlyBraces");
async function Hp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = 80, o = 20, l = Math.max(s, (a.width + (t.padding ?? 0) * 2) * 1.25, t?.width ?? 0), c = Math.max(o, a.height + (t.padding ?? 0) * 2, t?.height ?? 0), h = c / 2, { cssStyles: u } = t, f = j.svg(n), d = Y(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = l, m = c, y = g - h, x = m / 4, b = [
    { x: y, y: 0 },
    { x, y: 0 },
    { x: 0, y: m / 2 },
    { x, y: m },
    { x: y, y: m },
    ...qi(-y, -m / 2, h, 50, 270, 90)
  ], C = lt(b), k = f.path(C, d), w = n.insert(() => k, ":first-child");
  return w.attr("class", "basic label-container"), u && t.look !== "handDrawn" && w.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && w.selectChildren("path").attr("style", i), w.attr("transform", `translate(${-l / 2}, ${-c / 2})`), G(t, w), t.intersect = function(A) {
    return W.polygon(t, b, A);
  }, n;
}
p(Hp, "curvedTrapezoid");
var jv = /* @__PURE__ */ p((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createCylinderPathD"), Yv = /* @__PURE__ */ p((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createOuterCylinderPathD"), Uv = /* @__PURE__ */ p((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function jp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + t.padding, t.width ?? 0), l = o / 2, c = l / (2.5 + o / 50), h = Math.max(a.height + c + t.padding, t.height ?? 0);
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const d = j.svg(n), g = Yv(0, 0, o, h, l, c), m = Uv(0, c, o, h, l, c), y = d.path(g, Y(t, {})), x = d.path(m, Y(t, { fill: "none" }));
    u = n.insert(() => x, ":first-child"), u = n.insert(() => y, ":first-child"), u.attr("class", "basic label-container"), f && u.attr("style", f);
  } else {
    const d = jv(0, 0, o, h, l, c);
    u = n.insert("path", ":first-child").attr("d", d).attr("class", "basic label-container").attr("style", Rt(f)).attr("style", i);
  }
  return u.attr("label-offset-y", c), u.attr("transform", `translate(${-o / 2}, ${-(h / 2 + c)})`), G(t, u), s.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + (t.padding ?? 0) / 1.5 - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(d) {
    const g = W.rect(t, d), m = g.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(m) < (t.width ?? 0) / 2 || Math.abs(m) == (t.width ?? 0) / 2 && Math.abs(g.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let y = c * c * (1 - m * m / (l * l));
      y > 0 && (y = Math.sqrt(y)), y = c - y, d.y - (t.y ?? 0) > 0 && (y = -y), g.y += y;
    }
    return g;
  }, n;
}
p(jp, "cylinder");
async function Yp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + t.padding, l = a.height + t.padding, c = l * 0.2, h = -o / 2, u = -l / 2 - c / 2, { cssStyles: f } = t, d = j.svg(n), g = Y(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u + c },
    { x: -h, y: u + c },
    { x: -h, y: -u },
    { x: h, y: -u },
    { x: h, y: u },
    { x: -h, y: u },
    { x: -h, y: u + c }
  ], y = d.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), f && t.look !== "handDrawn" && x.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), s.attr(
    "transform",
    `translate(${h + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))}, ${u + c + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), G(t, x), t.intersect = function(b) {
    return W.rect(t, b);
  }, n;
}
p(Yp, "dividedRectangle");
async function Up(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: s } = await it(e, t, rt(t)), l = a.width / 2 + s + 5, c = a.width / 2 + s;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const f = j.svg(n), d = Y(t, { roughness: 0.2, strokeWidth: 2.5 }), g = Y(t, { roughness: 0.2, strokeWidth: 1.5 }), m = f.circle(0, 0, l * 2, d), y = f.circle(0, 0, c * 2, g);
    h = n.insert("g", ":first-child"), h.attr("class", Rt(t.cssClasses)).attr("style", Rt(u)), h.node()?.appendChild(m), h.node()?.appendChild(y);
  } else {
    h = n.insert("g", ":first-child");
    const f = h.insert("circle", ":first-child"), d = h.insert("circle");
    h.attr("class", "basic label-container").attr("style", i), f.attr("class", "outer-circle").attr("style", i).attr("r", l).attr("cx", 0).attr("cy", 0), d.attr("class", "inner-circle").attr("style", i).attr("r", c).attr("cx", 0).attr("cy", 0);
  }
  return G(t, h), t.intersect = function(f) {
    return F.info("DoubleCircle intersect", t, l, f), W.circle(t, l, f);
  }, n;
}
p(Up, "doublecircle");
function Gp(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = U(t);
  t.label = "", t.labelStyle = i;
  const a = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), s = 7, { cssStyles: o } = t, l = j.svg(a), { nodeBorder: c } = r, h = Y(t, { fillStyle: "solid" });
  t.look !== "handDrawn" && (h.roughness = 0);
  const u = l.circle(0, 0, s * 2, h), f = a.insert(() => u, ":first-child");
  return f.selectAll("path").attr("style", `fill: ${c} !important;`), o && o.length > 0 && t.look !== "handDrawn" && f.selectAll("path").attr("style", o), n && t.look !== "handDrawn" && f.selectAll("path").attr("style", n), G(t, f), t.intersect = function(d) {
    return F.info("filledCircle intersect", t, { radius: s, point: d }), W.circle(t, s, d);
  }, a;
}
p(Gp, "filledCircle");
async function Xp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + (t.padding ?? 0), l = o + a.height, c = o + a.height, h = [
    { x: 0, y: -l },
    { x: c, y: -l },
    { x: c / 2, y: 0 }
  ], { cssStyles: u } = t, f = j.svg(n), d = Y(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = lt(h), m = f.path(g, d), y = n.insert(() => m, ":first-child").attr("transform", `translate(${-l / 2}, ${l / 2})`);
  return u && t.look !== "handDrawn" && y.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), t.width = o, t.height = l, G(t, y), s.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${-l / 2 + (t.padding ?? 0) / 2 + (a.y - (a.top ?? 0))})`
  ), t.intersect = function(x) {
    return F.info("Triangle intersect", t, h, x), W.polygon(t, h, x);
  }, n;
}
p(Xp, "flippedTriangle");
function Vp(e, t, { dir: r, config: { state: i, themeVariables: n } }) {
  const { nodeStyles: a } = U(t);
  t.label = "";
  const s = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), { cssStyles: o } = t;
  let l = Math.max(70, t?.width ?? 0), c = Math.max(10, t?.height ?? 0);
  r === "LR" && (l = Math.max(10, t?.width ?? 0), c = Math.max(70, t?.height ?? 0));
  const h = -1 * l / 2, u = -1 * c / 2, f = j.svg(s), d = Y(t, {
    stroke: n.lineColor,
    fill: n.lineColor
  });
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = f.rectangle(h, u, l, c, d), m = s.insert(() => g, ":first-child");
  o && t.look !== "handDrawn" && m.selectAll("path").attr("style", o), a && t.look !== "handDrawn" && m.selectAll("path").attr("style", a), G(t, m);
  const y = i?.padding ?? 0;
  return t.width && t.height && (t.width += y / 2 || 0, t.height += y / 2 || 0), t.intersect = function(x) {
    return W.rect(t, x);
  }, s;
}
p(Vp, "forkJoin");
async function Zp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const n = 80, a = 50, { shapeSvg: s, bbox: o } = await it(e, t, rt(t)), l = Math.max(n, o.width + (t.padding ?? 0) * 2, t?.width ?? 0), c = Math.max(a, o.height + (t.padding ?? 0) * 2, t?.height ?? 0), h = c / 2, { cssStyles: u } = t, f = j.svg(s), d = Y(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = [
    { x: -l / 2, y: -c / 2 },
    { x: l / 2 - h, y: -c / 2 },
    ...qi(-l / 2 + h, 0, h, 50, 90, 270),
    { x: l / 2 - h, y: c / 2 },
    { x: -l / 2, y: c / 2 }
  ], m = lt(g), y = f.path(m, d), x = s.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), G(t, x), t.intersect = function(b) {
    return F.info("Pill intersect", t, { radius: h, point: b }), W.polygon(t, g, b);
  }, s;
}
p(Zp, "halfRoundedRectangle");
async function Kp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.height + (t.padding ?? 0), o = a.width + (t.padding ?? 0) * 2.5, { cssStyles: l } = t, c = j.svg(n), h = Y(t, {});
  t.look !== "handDrawn" && (h.roughness = 0, h.fillStyle = "solid");
  let u = o / 2;
  const f = u / 6;
  u = u + f;
  const d = s / 2, g = d / 2, m = u - g, y = [
    { x: -m, y: -d },
    { x: 0, y: -d },
    { x: m, y: -d },
    { x: u, y: 0 },
    { x: m, y: d },
    { x: 0, y: d },
    { x: -m, y: d },
    { x: -u, y: 0 }
  ], x = lt(y), b = c.path(x, h), C = n.insert(() => b, ":first-child");
  return C.attr("class", "basic label-container"), l && t.look !== "handDrawn" && C.selectChildren("path").attr("style", l), i && t.look !== "handDrawn" && C.selectChildren("path").attr("style", i), t.width = o, t.height = s, G(t, C), t.intersect = function(k) {
    return W.polygon(t, y, k);
  }, n;
}
p(Kp, "hexagon");
async function Qp(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.label = "", t.labelStyle = r;
  const { shapeSvg: n } = await it(e, t, rt(t)), a = Math.max(30, t?.width ?? 0), s = Math.max(30, t?.height ?? 0), { cssStyles: o } = t, l = j.svg(n), c = Y(t, {});
  t.look !== "handDrawn" && (c.roughness = 0, c.fillStyle = "solid");
  const h = [
    { x: 0, y: 0 },
    { x: a, y: 0 },
    { x: 0, y: s },
    { x: a, y: s }
  ], u = lt(h), f = l.path(u, c), d = n.insert(() => f, ":first-child");
  return d.attr("class", "basic label-container"), o && t.look !== "handDrawn" && d.selectChildren("path").attr("style", o), i && t.look !== "handDrawn" && d.selectChildren("path").attr("style", i), d.attr("transform", `translate(${-a / 2}, ${-s / 2})`), G(t, d), t.intersect = function(g) {
    return F.info("Pill intersect", t, { points: h }), W.polygon(t, h, g);
  }, n;
}
p(Qp, "hourglass");
async function Jp(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = U(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, s = t.assetWidth ?? 48, o = Math.max(a, s), l = i?.wrappingWidth;
  t.width = Math.max(o, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await it(e, t, "icon-shape default"), f = t.pos === "t", d = o, g = o, { nodeBorder: m } = r, { stylesMap: y } = Jr(t), x = -g / 2, b = -d / 2, C = t.label ? 8 : 0, k = j.svg(c), w = Y(t, { stroke: "none", fill: "none" });
  t.look !== "handDrawn" && (w.roughness = 0, w.fillStyle = "solid");
  const A = k.rectangle(x, b, g, d, w), S = Math.max(g, h.width), D = d + h.height + C, I = k.rectangle(-S / 2, -D / 2, S, D, {
    ...w,
    fill: "transparent",
    stroke: "none"
  }), O = c.insert(() => A, ":first-child"), $ = c.insert(() => I);
  if (t.icon) {
    const N = c.append("g");
    N.html(
      `<g>${await Ji(t.icon, {
        height: o,
        width: o,
        fallbackPrefix: ""
      })}</g>`
    );
    const R = N.node().getBBox(), B = R.width, L = R.height, T = R.x, E = R.y;
    N.attr(
      "transform",
      `translate(${-B / 2 - T},${f ? h.height / 2 + C / 2 - L / 2 - E : -h.height / 2 - C / 2 - L / 2 - E})`
    ), N.attr("style", `color: ${y.get("stroke") ?? m};`);
  }
  return u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${f ? -D / 2 : D / 2 - h.height})`
  ), O.attr(
    "transform",
    `translate(0,${f ? h.height / 2 + C / 2 : -h.height / 2 - C / 2})`
  ), G(t, $), t.intersect = function(N) {
    if (F.info("iconSquare intersect", t, N), !t.label)
      return W.rect(t, N);
    const R = t.x ?? 0, B = t.y ?? 0, L = t.height ?? 0;
    let T = [];
    return f ? T = [
      { x: R - h.width / 2, y: B - L / 2 },
      { x: R + h.width / 2, y: B - L / 2 },
      { x: R + h.width / 2, y: B - L / 2 + h.height + C },
      { x: R + g / 2, y: B - L / 2 + h.height + C },
      { x: R + g / 2, y: B + L / 2 },
      { x: R - g / 2, y: B + L / 2 },
      { x: R - g / 2, y: B - L / 2 + h.height + C },
      { x: R - h.width / 2, y: B - L / 2 + h.height + C }
    ] : T = [
      { x: R - g / 2, y: B - L / 2 },
      { x: R + g / 2, y: B - L / 2 },
      { x: R + g / 2, y: B - L / 2 + d },
      { x: R + h.width / 2, y: B - L / 2 + d },
      { x: R + h.width / 2 / 2, y: B + L / 2 },
      { x: R - h.width / 2, y: B + L / 2 },
      { x: R - h.width / 2, y: B - L / 2 + d },
      { x: R - g / 2, y: B - L / 2 + d }
    ], W.polygon(t, T, N);
  }, c;
}
p(Jp, "icon");
async function tg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = U(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, s = t.assetWidth ?? 48, o = Math.max(a, s), l = i?.wrappingWidth;
  t.width = Math.max(o, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await it(e, t, "icon-shape default"), f = 20, d = t.label ? 8 : 0, g = t.pos === "t", { nodeBorder: m, mainBkg: y } = r, { stylesMap: x } = Jr(t), b = j.svg(c), C = Y(t, {});
  t.look !== "handDrawn" && (C.roughness = 0, C.fillStyle = "solid");
  const k = x.get("fill");
  C.stroke = k ?? y;
  const w = c.append("g");
  t.icon && w.html(
    `<g>${await Ji(t.icon, {
      height: o,
      width: o,
      fallbackPrefix: ""
    })}</g>`
  );
  const A = w.node().getBBox(), S = A.width, D = A.height, I = A.x, O = A.y, $ = Math.max(S, D) * Math.SQRT2 + f * 2, N = b.circle(0, 0, $, C), R = Math.max($, h.width), B = $ + h.height + d, L = b.rectangle(-R / 2, -B / 2, R, B, {
    ...C,
    fill: "transparent",
    stroke: "none"
  }), T = c.insert(() => N, ":first-child"), E = c.insert(() => L);
  return w.attr(
    "transform",
    `translate(${-S / 2 - I},${g ? h.height / 2 + d / 2 - D / 2 - O : -h.height / 2 - d / 2 - D / 2 - O})`
  ), w.attr("style", `color: ${x.get("stroke") ?? m};`), u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${g ? -B / 2 : B / 2 - h.height})`
  ), T.attr(
    "transform",
    `translate(0,${g ? h.height / 2 + d / 2 : -h.height / 2 - d / 2})`
  ), G(t, E), t.intersect = function(M) {
    return F.info("iconSquare intersect", t, M), W.rect(t, M);
  }, c;
}
p(tg, "iconCircle");
async function eg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = U(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, s = t.assetWidth ?? 48, o = Math.max(a, s), l = i?.wrappingWidth;
  t.width = Math.max(o, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await it(
    e,
    t,
    "icon-shape default"
  ), d = t.pos === "t", g = o + u * 2, m = o + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = Jr(t), C = -m / 2, k = -g / 2, w = t.label ? 8 : 0, A = j.svg(c), S = Y(t, {});
  t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid");
  const D = b.get("fill");
  S.stroke = D ?? x;
  const I = A.path(Ve(C, k, m, g, 5), S), O = Math.max(m, h.width), $ = g + h.height + w, N = A.rectangle(-O / 2, -$ / 2, O, $, {
    ...S,
    fill: "transparent",
    stroke: "none"
  }), R = c.insert(() => I, ":first-child").attr("class", "icon-shape2"), B = c.insert(() => N);
  if (t.icon) {
    const L = c.append("g");
    L.html(
      `<g>${await Ji(t.icon, {
        height: o,
        width: o,
        fallbackPrefix: ""
      })}</g>`
    );
    const T = L.node().getBBox(), E = T.width, M = T.height, q = T.x, X = T.y;
    L.attr(
      "transform",
      `translate(${-E / 2 - q},${d ? h.height / 2 + w / 2 - M / 2 - X : -h.height / 2 - w / 2 - M / 2 - X})`
    ), L.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${d ? -$ / 2 : $ / 2 - h.height})`
  ), R.attr(
    "transform",
    `translate(0,${d ? h.height / 2 + w / 2 : -h.height / 2 - w / 2})`
  ), G(t, B), t.intersect = function(L) {
    if (F.info("iconSquare intersect", t, L), !t.label)
      return W.rect(t, L);
    const T = t.x ?? 0, E = t.y ?? 0, M = t.height ?? 0;
    let q = [];
    return d ? q = [
      { x: T - h.width / 2, y: E - M / 2 },
      { x: T + h.width / 2, y: E - M / 2 },
      { x: T + h.width / 2, y: E - M / 2 + h.height + w },
      { x: T + m / 2, y: E - M / 2 + h.height + w },
      { x: T + m / 2, y: E + M / 2 },
      { x: T - m / 2, y: E + M / 2 },
      { x: T - m / 2, y: E - M / 2 + h.height + w },
      { x: T - h.width / 2, y: E - M / 2 + h.height + w }
    ] : q = [
      { x: T - m / 2, y: E - M / 2 },
      { x: T + m / 2, y: E - M / 2 },
      { x: T + m / 2, y: E - M / 2 + g },
      { x: T + h.width / 2, y: E - M / 2 + g },
      { x: T + h.width / 2 / 2, y: E + M / 2 },
      { x: T - h.width / 2, y: E + M / 2 },
      { x: T - h.width / 2, y: E - M / 2 + g },
      { x: T - m / 2, y: E - M / 2 + g }
    ], W.polygon(t, q, L);
  }, c;
}
p(eg, "iconRounded");
async function rg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = U(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, s = t.assetWidth ?? 48, o = Math.max(a, s), l = i?.wrappingWidth;
  t.width = Math.max(o, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await it(
    e,
    t,
    "icon-shape default"
  ), d = t.pos === "t", g = o + u * 2, m = o + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = Jr(t), C = -m / 2, k = -g / 2, w = t.label ? 8 : 0, A = j.svg(c), S = Y(t, {});
  t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid");
  const D = b.get("fill");
  S.stroke = D ?? x;
  const I = A.path(Ve(C, k, m, g, 0.1), S), O = Math.max(m, h.width), $ = g + h.height + w, N = A.rectangle(-O / 2, -$ / 2, O, $, {
    ...S,
    fill: "transparent",
    stroke: "none"
  }), R = c.insert(() => I, ":first-child"), B = c.insert(() => N);
  if (t.icon) {
    const L = c.append("g");
    L.html(
      `<g>${await Ji(t.icon, {
        height: o,
        width: o,
        fallbackPrefix: ""
      })}</g>`
    );
    const T = L.node().getBBox(), E = T.width, M = T.height, q = T.x, X = T.y;
    L.attr(
      "transform",
      `translate(${-E / 2 - q},${d ? h.height / 2 + w / 2 - M / 2 - X : -h.height / 2 - w / 2 - M / 2 - X})`
    ), L.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${d ? -$ / 2 : $ / 2 - h.height})`
  ), R.attr(
    "transform",
    `translate(0,${d ? h.height / 2 + w / 2 : -h.height / 2 - w / 2})`
  ), G(t, B), t.intersect = function(L) {
    if (F.info("iconSquare intersect", t, L), !t.label)
      return W.rect(t, L);
    const T = t.x ?? 0, E = t.y ?? 0, M = t.height ?? 0;
    let q = [];
    return d ? q = [
      { x: T - h.width / 2, y: E - M / 2 },
      { x: T + h.width / 2, y: E - M / 2 },
      { x: T + h.width / 2, y: E - M / 2 + h.height + w },
      { x: T + m / 2, y: E - M / 2 + h.height + w },
      { x: T + m / 2, y: E + M / 2 },
      { x: T - m / 2, y: E + M / 2 },
      { x: T - m / 2, y: E - M / 2 + h.height + w },
      { x: T - h.width / 2, y: E - M / 2 + h.height + w }
    ] : q = [
      { x: T - m / 2, y: E - M / 2 },
      { x: T + m / 2, y: E - M / 2 },
      { x: T + m / 2, y: E - M / 2 + g },
      { x: T + h.width / 2, y: E - M / 2 + g },
      { x: T + h.width / 2 / 2, y: E + M / 2 },
      { x: T - h.width / 2, y: E + M / 2 },
      { x: T - h.width / 2, y: E - M / 2 + g },
      { x: T - m / 2, y: E - M / 2 + g }
    ], W.polygon(t, q, L);
  }, c;
}
p(rg, "iconSquare");
async function ig(e, t, { config: { flowchart: r } }) {
  const i = new Image();
  i.src = t?.img ?? "", await i.decode();
  const n = Number(i.naturalWidth.toString().replace("px", "")), a = Number(i.naturalHeight.toString().replace("px", ""));
  t.imageAspectRatio = n / a;
  const { labelStyles: s } = U(t);
  t.labelStyle = s;
  const o = r?.wrappingWidth;
  t.defaultWidth = r?.wrappingWidth;
  const l = Math.max(
    t.label ? o ?? 0 : 0,
    t?.assetWidth ?? n
  ), c = t.constraint === "on" && t?.assetHeight ? t.assetHeight * t.imageAspectRatio : l, h = t.constraint === "on" ? c / t.imageAspectRatio : t?.assetHeight ?? a;
  t.width = Math.max(c, o ?? 0);
  const { shapeSvg: u, bbox: f, label: d } = await it(e, t, "image-shape default"), g = t.pos === "t", m = -c / 2, y = -h / 2, x = t.label ? 8 : 0, b = j.svg(u), C = Y(t, {});
  t.look !== "handDrawn" && (C.roughness = 0, C.fillStyle = "solid");
  const k = b.rectangle(m, y, c, h, C), w = Math.max(c, f.width), A = h + f.height + x, S = b.rectangle(-w / 2, -A / 2, w, A, {
    ...C,
    fill: "none",
    stroke: "none"
  }), D = u.insert(() => k, ":first-child"), I = u.insert(() => S);
  if (t.img) {
    const O = u.append("image");
    O.attr("href", t.img), O.attr("width", c), O.attr("height", h), O.attr("preserveAspectRatio", "none"), O.attr(
      "transform",
      `translate(${-c / 2},${g ? A / 2 - h : -A / 2})`
    );
  }
  return d.attr(
    "transform",
    `translate(${-f.width / 2 - (f.x - (f.left ?? 0))},${g ? -h / 2 - f.height / 2 - x / 2 : h / 2 - f.height / 2 + x / 2})`
  ), D.attr(
    "transform",
    `translate(0,${g ? f.height / 2 + x / 2 : -f.height / 2 - x / 2})`
  ), G(t, I), t.intersect = function(O) {
    if (F.info("iconSquare intersect", t, O), !t.label)
      return W.rect(t, O);
    const $ = t.x ?? 0, N = t.y ?? 0, R = t.height ?? 0;
    let B = [];
    return g ? B = [
      { x: $ - f.width / 2, y: N - R / 2 },
      { x: $ + f.width / 2, y: N - R / 2 },
      { x: $ + f.width / 2, y: N - R / 2 + f.height + x },
      { x: $ + c / 2, y: N - R / 2 + f.height + x },
      { x: $ + c / 2, y: N + R / 2 },
      { x: $ - c / 2, y: N + R / 2 },
      { x: $ - c / 2, y: N - R / 2 + f.height + x },
      { x: $ - f.width / 2, y: N - R / 2 + f.height + x }
    ] : B = [
      { x: $ - c / 2, y: N - R / 2 },
      { x: $ + c / 2, y: N - R / 2 },
      { x: $ + c / 2, y: N - R / 2 + h },
      { x: $ + f.width / 2, y: N - R / 2 + h },
      { x: $ + f.width / 2 / 2, y: N + R / 2 },
      { x: $ - f.width / 2, y: N + R / 2 },
      { x: $ - f.width / 2, y: N - R / 2 + h },
      { x: $ - c / 2, y: N - R / 2 + h }
    ], W.polygon(t, B, O);
  }, u;
}
p(ig, "imageSquare");
async function ng(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), o = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), l = [
    { x: 0, y: 0 },
    { x: s, y: 0 },
    { x: s + 3 * o / 6, y: -o },
    { x: -3 * o / 6, y: -o }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), f = Y(t, {}), d = lt(l), g = u.path(d, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-s / 2}, ${o / 2})`), h && c.attr("style", h);
  } else
    c = Ze(n, s, o, l);
  return i && c.attr("style", i), t.width = s, t.height = o, G(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
p(ng, "inv_trapezoid");
async function Wa(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = U(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: s } = await it(e, t, rt(t)), o = Math.max(s.width + r.labelPaddingX * 2, t?.width || 0), l = Math.max(s.height + r.labelPaddingY * 2, t?.height || 0), c = -o / 2, h = -l / 2;
  let u, { rx: f, ry: d } = t;
  const { cssStyles: g } = t;
  if (r?.rx && r.ry && (f = r.rx, d = r.ry), t.look === "handDrawn") {
    const m = j.svg(a), y = Y(t, {}), x = f || d ? m.path(Ve(c, h, o, l, f || 0), y) : m.rectangle(c, h, o, l, y);
    u = a.insert(() => x, ":first-child"), u.attr("class", "basic label-container").attr("style", Rt(g));
  } else
    u = a.insert("rect", ":first-child"), u.attr("class", "basic label-container").attr("style", n).attr("rx", Rt(f)).attr("ry", Rt(d)).attr("x", c).attr("y", h).attr("width", o).attr("height", l);
  return G(t, u), t.calcIntersect = function(m, y) {
    return W.rect(m, y);
  }, t.intersect = function(m) {
    return W.rect(t, m);
  }, a;
}
p(Wa, "drawRect");
async function ag(e, t) {
  const { shapeSvg: r, bbox: i, label: n } = await it(e, t, "label"), a = r.insert("rect", ":first-child");
  return a.attr("width", 0.1).attr("height", 0.1), r.attr("class", "label edgeLabel"), n.attr(
    "transform",
    `translate(${-(i.width / 2) - (i.x - (i.left ?? 0))}, ${-(i.height / 2) - (i.y - (i.top ?? 0))})`
  ), G(t, a), t.intersect = function(l) {
    return W.rect(t, l);
  }, r;
}
p(ag, "labelRect");
async function sg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + (t.padding ?? 0), t?.width ?? 0), o = Math.max(a.height + (t.padding ?? 0), t?.height ?? 0), l = [
    { x: 0, y: 0 },
    { x: s + 3 * o / 6, y: 0 },
    { x: s, y: -o },
    { x: -(3 * o) / 6, y: -o }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), f = Y(t, {}), d = lt(l), g = u.path(d, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-s / 2}, ${o / 2})`), h && c.attr("style", h);
  } else
    c = Ze(n, s, o, l);
  return i && c.attr("style", i), t.width = s, t.height = o, G(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
p(sg, "lean_left");
async function og(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + (t.padding ?? 0), t?.width ?? 0), o = Math.max(a.height + (t.padding ?? 0), t?.height ?? 0), l = [
    { x: -3 * o / 6, y: 0 },
    { x: s, y: 0 },
    { x: s + 3 * o / 6, y: -o },
    { x: 0, y: -o }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), f = Y(t, {}), d = lt(l), g = u.path(d, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-s / 2}, ${o / 2})`), h && c.attr("style", h);
  } else
    c = Ze(n, s, o, l);
  return i && c.attr("style", i), t.width = s, t.height = o, G(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
p(og, "lean_right");
function lg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.label = "", t.labelStyle = r;
  const n = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), { cssStyles: a } = t, s = Math.max(35, t?.width ?? 0), o = Math.max(35, t?.height ?? 0), l = 7, c = [
    { x: s, y: 0 },
    { x: 0, y: o + l / 2 },
    { x: s - 2 * l, y: o + l / 2 },
    { x: 0, y: 2 * o },
    { x: s, y: o - l / 2 },
    { x: 2 * l, y: o - l / 2 }
  ], h = j.svg(n), u = Y(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = lt(c), d = h.path(f, u), g = n.insert(() => d, ":first-child");
  return a && t.look !== "handDrawn" && g.selectAll("path").attr("style", a), i && t.look !== "handDrawn" && g.selectAll("path").attr("style", i), g.attr("transform", `translate(-${s / 2},${-o})`), G(t, g), t.intersect = function(m) {
    return F.info("lightningBolt intersect", t, m), W.polygon(t, c, m);
  }, n;
}
p(lg, "lightningBolt");
var Gv = /* @__PURE__ */ p((e, t, r, i, n, a, s) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + s}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createCylinderPathD"), Xv = /* @__PURE__ */ p((e, t, r, i, n, a, s) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + s}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createOuterCylinderPathD"), Vv = /* @__PURE__ */ p((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function cg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0), t.width ?? 0), l = o / 2, c = l / (2.5 + o / 50), h = Math.max(a.height + c + (t.padding ?? 0), t.height ?? 0), u = h * 0.1;
  let f;
  const { cssStyles: d } = t;
  if (t.look === "handDrawn") {
    const g = j.svg(n), m = Xv(0, 0, o, h, l, c, u), y = Vv(0, c, o, h, l, c), x = Y(t, {}), b = g.path(m, x), C = g.path(y, x);
    n.insert(() => C, ":first-child").attr("class", "line"), f = n.insert(() => b, ":first-child"), f.attr("class", "basic label-container"), d && f.attr("style", d);
  } else {
    const g = Gv(0, 0, o, h, l, c, u);
    f = n.insert("path", ":first-child").attr("d", g).attr("class", "basic label-container").attr("style", Rt(d)).attr("style", i);
  }
  return f.attr("label-offset-y", c), f.attr("transform", `translate(${-o / 2}, ${-(h / 2 + c)})`), G(t, f), s.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(g) {
    const m = W.rect(t, g), y = m.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(y) < (t.width ?? 0) / 2 || Math.abs(y) == (t.width ?? 0) / 2 && Math.abs(m.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let x = c * c * (1 - y * y / (l * l));
      x > 0 && (x = Math.sqrt(x)), x = c - x, g.y - (t.y ?? 0) > 0 && (x = -x), m.y += x;
    }
    return m;
  }, n;
}
p(cg, "linedCylinder");
async function hg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = l / 4, h = l + c, { cssStyles: u } = t, f = j.svg(n), d = Y(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = [
    { x: -o / 2 - o / 2 * 0.1, y: -h / 2 },
    { x: -o / 2 - o / 2 * 0.1, y: h / 2 },
    ...Ue(
      -o / 2 - o / 2 * 0.1,
      h / 2,
      o / 2 + o / 2 * 0.1,
      h / 2,
      c,
      0.8
    ),
    { x: o / 2 + o / 2 * 0.1, y: -h / 2 },
    { x: -o / 2 - o / 2 * 0.1, y: -h / 2 },
    { x: -o / 2, y: -h / 2 },
    { x: -o / 2, y: h / 2 * 1.1 },
    { x: -o / 2, y: -h / 2 }
  ], m = f.polygon(
    g.map((x) => [x.x, x.y]),
    d
  ), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), u && t.look !== "handDrawn" && y.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(0,${-c / 2})`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) + o / 2 * 0.1 / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), G(t, y), t.intersect = function(x) {
    return W.polygon(t, g, x);
  }, n;
}
p(hg, "linedWaveEdgedRect");
async function ug(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = 5, h = -o / 2, u = -l / 2, { cssStyles: f } = t, d = j.svg(n), g = Y(t, {}), m = [
    { x: h - c, y: u + c },
    { x: h - c, y: u + l + c },
    { x: h + o - c, y: u + l + c },
    { x: h + o - c, y: u + l },
    { x: h + o, y: u + l },
    { x: h + o, y: u + l - c },
    { x: h + o + c, y: u + l - c },
    { x: h + o + c, y: u - c },
    { x: h + c, y: u - c },
    { x: h + c, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], y = [
    { x: h, y: u + c },
    { x: h + o - c, y: u + c },
    { x: h + o - c, y: u + l },
    { x: h + o, y: u + l },
    { x: h + o, y: u },
    { x: h, y: u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = lt(m), b = d.path(x, g), C = lt(y), k = d.path(C, { ...g, fill: "none" }), w = n.insert(() => k, ":first-child");
  return w.insert(() => b, ":first-child"), w.attr("class", "basic label-container"), f && t.look !== "handDrawn" && w.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), s.attr(
    "transform",
    `translate(${-(a.width / 2) - c - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), G(t, w), t.intersect = function(A) {
    return W.polygon(t, m, A);
  }, n;
}
p(ug, "multiRect");
async function fg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = l / 4, h = l + c, u = -o / 2, f = -h / 2, d = 5, { cssStyles: g } = t, m = Ue(
    u - d,
    f + h + d,
    u + o - d,
    f + h + d,
    c,
    0.8
  ), y = m?.[m.length - 1], x = [
    { x: u - d, y: f + d },
    { x: u - d, y: f + h + d },
    ...m,
    { x: u + o - d, y: y.y - d },
    { x: u + o, y: y.y - d },
    { x: u + o, y: y.y - 2 * d },
    { x: u + o + d, y: y.y - 2 * d },
    { x: u + o + d, y: f - d },
    { x: u + d, y: f - d },
    { x: u + d, y: f },
    { x: u, y: f },
    { x: u, y: f + d }
  ], b = [
    { x: u, y: f + d },
    { x: u + o - d, y: f + d },
    { x: u + o - d, y: y.y - d },
    { x: u + o, y: y.y - d },
    { x: u + o, y: f },
    { x: u, y: f }
  ], C = j.svg(n), k = Y(t, {});
  t.look !== "handDrawn" && (k.roughness = 0, k.fillStyle = "solid");
  const w = lt(x), A = C.path(w, k), S = lt(b), D = C.path(S, k), I = n.insert(() => A, ":first-child");
  return I.insert(() => D), I.attr("class", "basic label-container"), g && t.look !== "handDrawn" && I.selectAll("path").attr("style", g), i && t.look !== "handDrawn" && I.selectAll("path").attr("style", i), I.attr("transform", `translate(0,${-c / 2})`), s.attr(
    "transform",
    `translate(${-(a.width / 2) - d - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + d - c / 2 - (a.y - (a.top ?? 0))})`
  ), G(t, I), t.intersect = function(O) {
    return W.polygon(t, x, O);
  }, n;
}
p(fg, "multiWaveEdgedRectangle");
async function dg(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = U(t);
  t.labelStyle = i, t.useHtmlLabels || Dt().flowchart?.htmlLabels !== !1 || (t.centerLabel = !0);
  const { shapeSvg: s, bbox: o, label: l } = await it(e, t, rt(t)), c = Math.max(o.width + (t.padding ?? 0) * 2, t?.width ?? 0), h = Math.max(o.height + (t.padding ?? 0) * 2, t?.height ?? 0), u = -c / 2, f = -h / 2, { cssStyles: d } = t, g = j.svg(s), m = Y(t, {
    fill: r.noteBkgColor,
    stroke: r.noteBorderColor
  });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = g.rectangle(u, f, c, h, m), x = s.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), d && t.look !== "handDrawn" && x.selectAll("path").attr("style", d), n && t.look !== "handDrawn" && x.selectAll("path").attr("style", n), l.attr(
    "transform",
    `translate(${-o.width / 2 - (o.x - (o.left ?? 0))}, ${-(o.height / 2) - (o.y - (o.top ?? 0))})`
  ), G(t, x), t.intersect = function(b) {
    return W.rect(t, b);
  }, s;
}
p(dg, "note");
var Zv = /* @__PURE__ */ p((e, t, r) => [
  `M${e + r / 2},${t}`,
  `L${e + r},${t - r / 2}`,
  `L${e + r / 2},${t - r}`,
  `L${e},${t - r / 2}`,
  "Z"
].join(" "), "createDecisionBoxPathD");
async function pg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.width + t.padding, o = a.height + t.padding, l = s + o, c = 0.5, h = [
    { x: l / 2, y: 0 },
    { x: l, y: -l / 2 },
    { x: l / 2, y: -l },
    { x: 0, y: -l / 2 }
  ];
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const d = j.svg(n), g = Y(t, {}), m = Zv(0, 0, l), y = d.path(m, g);
    u = n.insert(() => y, ":first-child").attr("transform", `translate(${-l / 2 + c}, ${l / 2})`), f && u.attr("style", f);
  } else
    u = Ze(n, l, l, h), u.attr("transform", `translate(${-l / 2 + c}, ${l / 2})`);
  return i && u.attr("style", i), G(t, u), t.calcIntersect = function(d, g) {
    const m = d.width, y = [
      { x: m / 2, y: 0 },
      { x: m, y: -m / 2 },
      { x: m / 2, y: -m },
      { x: 0, y: -m / 2 }
    ], x = W.polygon(d, y, g);
    return { x: x.x - 0.5, y: x.y - 0.5 };
  }, t.intersect = function(d) {
    return this.calcIntersect(t, d);
  }, n;
}
p(pg, "question");
async function gg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0), t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0), t?.height ?? 0), c = -o / 2, h = -l / 2, u = h / 2, f = [
    { x: c + u, y: h },
    { x: c, y: 0 },
    { x: c + u, y: -h },
    { x: -c, y: -h },
    { x: -c, y: h }
  ], { cssStyles: d } = t, g = j.svg(n), m = Y(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = lt(f), x = g.path(y, m), b = n.insert(() => x, ":first-child");
  return b.attr("class", "basic label-container"), d && t.look !== "handDrawn" && b.selectAll("path").attr("style", d), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), b.attr("transform", `translate(${-u / 2},0)`), s.attr(
    "transform",
    `translate(${-u / 2 - a.width / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), G(t, b), t.intersect = function(C) {
    return W.polygon(t, f, C);
  }, n;
}
p(gg, "rect_left_inv_arrow");
async function mg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  let n;
  t.cssClasses ? n = "node " + t.cssClasses : n = "node default";
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), s = a.insert("g"), o = a.insert("g").attr("class", "label").attr("style", i), l = t.description, c = t.label, h = o.node().appendChild(await or(c, t.labelStyle, !0, !0));
  let u = { width: 0, height: 0 };
  if (Bt(ft()?.flowchart?.htmlLabels)) {
    const D = h.children[0], I = ht(h);
    u = D.getBoundingClientRect(), I.attr("width", u.width), I.attr("height", u.height);
  }
  F.info("Text 2", l);
  const f = l || [], d = h.getBBox(), g = o.node().appendChild(
    await or(
      f.join ? f.join("<br/>") : f,
      t.labelStyle,
      !0,
      !0
    )
  ), m = g.children[0], y = ht(g);
  u = m.getBoundingClientRect(), y.attr("width", u.width), y.attr("height", u.height);
  const x = (t.padding || 0) / 2;
  ht(g).attr(
    "transform",
    "translate( " + (u.width > d.width ? 0 : (d.width - u.width) / 2) + ", " + (d.height + x + 5) + ")"
  ), ht(h).attr(
    "transform",
    "translate( " + (u.width < d.width ? 0 : -(d.width - u.width) / 2) + ", 0)"
  ), u = o.node().getBBox(), o.attr(
    "transform",
    "translate(" + -u.width / 2 + ", " + (-u.height / 2 - x + 3) + ")"
  );
  const b = u.width + (t.padding || 0), C = u.height + (t.padding || 0), k = -u.width / 2 - x, w = -u.height / 2 - x;
  let A, S;
  if (t.look === "handDrawn") {
    const D = j.svg(a), I = Y(t, {}), O = D.path(
      Ve(k, w, b, C, t.rx || 0),
      I
    ), $ = D.line(
      -u.width / 2 - x,
      -u.height / 2 - x + d.height + x,
      u.width / 2 + x,
      -u.height / 2 - x + d.height + x,
      I
    );
    S = a.insert(() => (F.debug("Rough node insert CXC", O), $), ":first-child"), A = a.insert(() => (F.debug("Rough node insert CXC", O), O), ":first-child");
  } else
    A = s.insert("rect", ":first-child"), S = s.insert("line"), A.attr("class", "outer title-state").attr("style", i).attr("x", -u.width / 2 - x).attr("y", -u.height / 2 - x).attr("width", u.width + (t.padding || 0)).attr("height", u.height + (t.padding || 0)), S.attr("class", "divider").attr("x1", -u.width / 2 - x).attr("x2", u.width / 2 + x).attr("y1", -u.height / 2 - x + d.height + x).attr("y2", -u.height / 2 - x + d.height + x);
  return G(t, A), t.intersect = function(D) {
    return W.rect(t, D);
  }, a;
}
p(mg, "rectWithTitle");
function ki(e, t, r, i, n, a, s) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, d = u / n, g = f / a, m = Math.sqrt(d ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const y = Math.sqrt(1 - m ** 2), x = l + y * a * Math.sin(h) * (s ? -1 : 1), b = c - y * n * Math.cos(h) * (s ? -1 : 1), C = Math.atan2((t - b) / a, (e - x) / n);
  let w = Math.atan2((i - b) / a, (r - x) / n) - C;
  s && w < 0 && (w += 2 * Math.PI), !s && w > 0 && (w -= 2 * Math.PI);
  const A = [];
  for (let S = 0; S < 20; S++) {
    const D = S / 19, I = C + D * w, O = x + n * Math.cos(I), $ = b + a * Math.sin(I);
    A.push({ x: O, y: $ });
  }
  return A;
}
p(ki, "generateArcPoints");
async function yg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = t?.padding ?? 0, o = t?.padding ?? 0, l = (t?.width ? t?.width : a.width) + s * 2, c = (t?.height ? t?.height : a.height) + o * 2, h = t.radius || 5, u = t.taper || 5, { cssStyles: f } = t, d = j.svg(n), g = Y(t, {});
  t.stroke && (g.stroke = t.stroke), t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    // Top edge (left to right)
    { x: -l / 2 + u, y: -c / 2 },
    // Top-left corner start (1)
    { x: l / 2 - u, y: -c / 2 },
    // Top-right corner start (2)
    ...ki(l / 2 - u, -c / 2, l / 2, -c / 2 + u, h, h, !0),
    // Top-left arc (2 to 3)
    // Right edge (top to bottom)
    { x: l / 2, y: -c / 2 + u },
    // Top-right taper point (3)
    { x: l / 2, y: c / 2 - u },
    // Bottom-right taper point (4)
    ...ki(l / 2, c / 2 - u, l / 2 - u, c / 2, h, h, !0),
    // Top-left arc (4 to 5)
    // Bottom edge (right to left)
    { x: l / 2 - u, y: c / 2 },
    // Bottom-right corner start (5)
    { x: -l / 2 + u, y: c / 2 },
    // Bottom-left corner start (6)
    ...ki(-l / 2 + u, c / 2, -l / 2, c / 2 - u, h, h, !0),
    // Top-left arc (4 to 5)
    // Left edge (bottom to top)
    { x: -l / 2, y: c / 2 - u },
    // Bottom-left taper point (7)
    { x: -l / 2, y: -c / 2 + u },
    // Top-left taper point (8)
    ...ki(-l / 2, -c / 2 + u, -l / 2 + u, -c / 2, h, h, !0)
    // Top-left arc (4 to 5)
  ], y = lt(m), x = d.path(y, g), b = n.insert(() => x, ":first-child");
  return b.attr("class", "basic label-container outer-path"), f && t.look !== "handDrawn" && b.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && b.selectChildren("path").attr("style", i), G(t, b), t.intersect = function(C) {
    return W.polygon(t, m, C);
  }, n;
}
p(yg, "roundedRect");
async function xg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = t?.padding ?? 0, l = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), h = -a.width / 2 - o, u = -a.height / 2 - o, { cssStyles: f } = t, d = j.svg(n), g = Y(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u },
    { x: h + l + 8, y: u },
    { x: h + l + 8, y: u + c },
    { x: h - 8, y: u + c },
    { x: h - 8, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], y = d.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container").attr("style", Rt(f)), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), f && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), s.attr(
    "transform",
    `translate(${-l / 2 + 4 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), G(t, x), t.intersect = function(b) {
    return W.rect(t, b);
  }, n;
}
p(xg, "shadedProcess");
async function bg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = -o / 2, h = -l / 2, { cssStyles: u } = t, f = j.svg(n), d = Y(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = [
    { x: c, y: h },
    { x: c, y: h + l },
    { x: c + o, y: h + l },
    { x: c + o, y: h - l / 2 }
  ], m = lt(g), y = f.path(m, d), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), x.attr("transform", `translate(0, ${l / 4})`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))}, ${-l / 4 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), G(t, x), t.intersect = function(b) {
    return W.polygon(t, g, b);
  }, n;
}
p(bg, "slopedRect");
async function Cg(e, t) {
  const r = {
    rx: 0,
    ry: 0,
    labelPaddingX: t.labelPaddingX ?? (t?.padding || 0) * 2,
    labelPaddingY: (t?.padding || 0) * 1
  };
  return Wa(e, t, r);
}
p(Cg, "squareRect");
async function _g(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.height + t.padding, o = a.width + s / 4 + t.padding, l = s / 2, { cssStyles: c } = t, h = j.svg(n), u = Y(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = [
    { x: -o / 2 + l, y: -s / 2 },
    { x: o / 2 - l, y: -s / 2 },
    ...qi(-o / 2 + l, 0, l, 50, 90, 270),
    { x: o / 2 - l, y: s / 2 },
    ...qi(o / 2 - l, 0, l, 50, 270, 450)
  ], d = lt(f), g = h.path(d, u), m = n.insert(() => g, ":first-child");
  return m.attr("class", "basic label-container outer-path"), c && t.look !== "handDrawn" && m.selectChildren("path").attr("style", c), i && t.look !== "handDrawn" && m.selectChildren("path").attr("style", i), G(t, m), t.intersect = function(y) {
    return W.polygon(t, f, y);
  }, n;
}
p(_g, "stadium");
async function wg(e, t) {
  return Wa(e, t, {
    rx: 5,
    ry: 5
  });
}
p(wg, "state");
function kg(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = U(t);
  t.labelStyle = i;
  const { cssStyles: a } = t, { lineColor: s, stateBorder: o, nodeBorder: l } = r, c = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), h = j.svg(c), u = Y(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = h.circle(0, 0, 14, {
    ...u,
    stroke: s,
    strokeWidth: 2
  }), d = o ?? l, g = h.circle(0, 0, 5, {
    ...u,
    fill: d,
    stroke: d,
    strokeWidth: 2,
    fillStyle: "solid"
  }), m = c.insert(() => f, ":first-child");
  return m.insert(() => g), a && m.selectAll("path").attr("style", a), n && m.selectAll("path").attr("style", n), G(t, m), t.intersect = function(y) {
    return W.circle(t, 7, y);
  }, c;
}
p(kg, "stateEnd");
function vg(e, t, { config: { themeVariables: r } }) {
  const { lineColor: i } = r, n = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id);
  let a;
  if (t.look === "handDrawn") {
    const o = j.svg(n).circle(0, 0, 14, uC(i));
    a = n.insert(() => o), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  } else
    a = n.insert("circle", ":first-child"), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  return G(t, a), t.intersect = function(s) {
    return W.circle(t, 7, s);
  }, n;
}
p(vg, "stateStart");
async function Sg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = (t?.padding || 0) / 2, o = a.width + t.padding, l = a.height + t.padding, c = -a.width / 2 - s, h = -a.height / 2 - s, u = [
    { x: 0, y: 0 },
    { x: o, y: 0 },
    { x: o, y: -l },
    { x: 0, y: -l },
    { x: 0, y: 0 },
    { x: -8, y: 0 },
    { x: o + 8, y: 0 },
    { x: o + 8, y: -l },
    { x: -8, y: -l },
    { x: -8, y: 0 }
  ];
  if (t.look === "handDrawn") {
    const f = j.svg(n), d = Y(t, {}), g = f.rectangle(c - 8, h, o + 16, l, d), m = f.line(c, h, c, h + l, d), y = f.line(c + o, h, c + o, h + l, d);
    n.insert(() => m, ":first-child"), n.insert(() => y, ":first-child");
    const x = n.insert(() => g, ":first-child"), { cssStyles: b } = t;
    x.attr("class", "basic label-container").attr("style", Rt(b)), G(t, x);
  } else {
    const f = Ze(n, o, l, u);
    i && f.attr("style", i), G(t, f);
  }
  return t.intersect = function(f) {
    return W.polygon(t, u, f);
  }, n;
}
p(Sg, "subroutine");
async function Tg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), o = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), l = -s / 2, c = -o / 2, h = 0.2 * o, u = 0.2 * o, { cssStyles: f } = t, d = j.svg(n), g = Y(t, {}), m = [
    { x: l - h / 2, y: c },
    { x: l + s + h / 2, y: c },
    { x: l + s + h / 2, y: c + o },
    { x: l - h / 2, y: c + o }
  ], y = [
    { x: l + s - h / 2, y: c + o },
    { x: l + s + h / 2, y: c + o },
    { x: l + s + h / 2, y: c + o - u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = lt(m), b = d.path(x, g), C = lt(y), k = d.path(C, { ...g, fillStyle: "solid" }), w = n.insert(() => k, ":first-child");
  return w.insert(() => b, ":first-child"), w.attr("class", "basic label-container"), f && t.look !== "handDrawn" && w.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), G(t, w), t.intersect = function(A) {
    return W.polygon(t, m, A);
  }, n;
}
p(Tg, "taggedRect");
async function Bg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = l / 4, h = 0.2 * o, u = 0.2 * l, f = l + c, { cssStyles: d } = t, g = j.svg(n), m = Y(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = [
    { x: -o / 2 - o / 2 * 0.1, y: f / 2 },
    ...Ue(
      -o / 2 - o / 2 * 0.1,
      f / 2,
      o / 2 + o / 2 * 0.1,
      f / 2,
      c,
      0.8
    ),
    { x: o / 2 + o / 2 * 0.1, y: -f / 2 },
    { x: -o / 2 - o / 2 * 0.1, y: -f / 2 }
  ], x = -o / 2 + o / 2 * 0.1, b = -f / 2 - u * 0.4, C = [
    { x: x + o - h, y: (b + l) * 1.4 },
    { x: x + o, y: b + l - u },
    { x: x + o, y: (b + l) * 0.9 },
    ...Ue(
      x + o,
      (b + l) * 1.3,
      x + o - h,
      (b + l) * 1.5,
      -l * 0.03,
      0.5
    )
  ], k = lt(y), w = g.path(k, m), A = lt(C), S = g.path(A, {
    ...m,
    fillStyle: "solid"
  }), D = n.insert(() => S, ":first-child");
  return D.insert(() => w, ":first-child"), D.attr("class", "basic label-container"), d && t.look !== "handDrawn" && D.selectAll("path").attr("style", d), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(0,${-c / 2})`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), G(t, D), t.intersect = function(I) {
    return W.polygon(t, y, I);
  }, n;
}
p(Bg, "taggedWaveEdgedRectangle");
async function Ag(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + t.padding, t?.width || 0), o = Math.max(a.height + t.padding, t?.height || 0), l = -s / 2, c = -o / 2, h = n.insert("rect", ":first-child");
  return h.attr("class", "text").attr("style", i).attr("rx", 0).attr("ry", 0).attr("x", l).attr("y", c).attr("width", s).attr("height", o), G(t, h), t.intersect = function(u) {
    return W.rect(t, u);
  }, n;
}
p(Ag, "text");
var Kv = /* @__PURE__ */ p((e, t, r, i, n, a) => `M${e},${t}
    a${n},${a} 0,0,1 0,${-i}
    l${r},0
    a${n},${a} 0,0,1 0,${i}
    M${r},${-i}
    a${n},${a} 0,0,0 0,${i}
    l${-r},0`, "createCylinderPathD"), Qv = /* @__PURE__ */ p((e, t, r, i, n, a) => [
  `M${e},${t}`,
  `M${e + r},${t}`,
  `a${n},${a} 0,0,0 0,${-i}`,
  `l${-r},0`,
  `a${n},${a} 0,0,0 0,${i}`,
  `l${r},0`
].join(" "), "createOuterCylinderPathD"), Jv = /* @__PURE__ */ p((e, t, r, i, n, a) => [`M${e + r / 2},${-i / 2}`, `a${n},${a} 0,0,0 0,${i}`].join(" "), "createInnerCylinderPathD");
async function Lg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s, halfPadding: o } = await it(
    e,
    t,
    rt(t)
  ), l = t.look === "neo" ? o * 2 : o, c = a.height + l, h = c / 2, u = h / (2.5 + c / 50), f = a.width + u + l, { cssStyles: d } = t;
  let g;
  if (t.look === "handDrawn") {
    const m = j.svg(n), y = Qv(0, 0, f, c, u, h), x = Jv(0, 0, f, c, u, h), b = m.path(y, Y(t, {})), C = m.path(x, Y(t, { fill: "none" }));
    g = n.insert(() => C, ":first-child"), g = n.insert(() => b, ":first-child"), g.attr("class", "basic label-container"), d && g.attr("style", d);
  } else {
    const m = Kv(0, 0, f, c, u, h);
    g = n.insert("path", ":first-child").attr("d", m).attr("class", "basic label-container").attr("style", Rt(d)).attr("style", i), g.attr("class", "basic label-container"), d && g.selectAll("path").attr("style", d), i && g.selectAll("path").attr("style", i);
  }
  return g.attr("label-offset-x", u), g.attr("transform", `translate(${-f / 2}, ${c / 2} )`), s.attr(
    "transform",
    `translate(${-(a.width / 2) - u - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), G(t, g), t.intersect = function(m) {
    const y = W.rect(t, m), x = y.y - (t.y ?? 0);
    if (h != 0 && (Math.abs(x) < (t.height ?? 0) / 2 || Math.abs(x) == (t.height ?? 0) / 2 && Math.abs(y.x - (t.x ?? 0)) > (t.width ?? 0) / 2 - u)) {
      let b = u * u * (1 - x * x / (h * h));
      b != 0 && (b = Math.sqrt(Math.abs(b))), b = u - b, m.x - (t.x ?? 0) > 0 && (b = -b), y.x += b;
    }
    return y;
  }, n;
}
p(Lg, "tiltedCylinder");
async function Mg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.width + t.padding, o = a.height + t.padding, l = [
    { x: -3 * o / 6, y: 0 },
    { x: s + 3 * o / 6, y: 0 },
    { x: s, y: -o },
    { x: 0, y: -o }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), f = Y(t, {}), d = lt(l), g = u.path(d, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-s / 2}, ${o / 2})`), h && c.attr("style", h);
  } else
    c = Ze(n, s, o, l);
  return i && c.attr("style", i), t.width = s, t.height = o, G(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
p(Mg, "trapezoid");
async function $g(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = 60, o = 20, l = Math.max(s, a.width + (t.padding ?? 0) * 2, t?.width ?? 0), c = Math.max(o, a.height + (t.padding ?? 0) * 2, t?.height ?? 0), { cssStyles: h } = t, u = j.svg(n), f = Y(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const d = [
    { x: -l / 2 * 0.8, y: -c / 2 },
    { x: l / 2 * 0.8, y: -c / 2 },
    { x: l / 2, y: -c / 2 * 0.6 },
    { x: l / 2, y: c / 2 },
    { x: -l / 2, y: c / 2 },
    { x: -l / 2, y: -c / 2 * 0.6 }
  ], g = lt(d), m = u.path(g, f), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectChildren("path").attr("style", h), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), G(t, y), t.intersect = function(x) {
    return W.polygon(t, d, x);
  }, n;
}
p($g, "trapezoidalPentagon");
async function Eg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Bt(ft().flowchart?.htmlLabels), l = a.width + (t.padding ?? 0), c = l + a.height, h = l + a.height, u = [
    { x: 0, y: 0 },
    { x: h, y: 0 },
    { x: h / 2, y: -c }
  ], { cssStyles: f } = t, d = j.svg(n), g = Y(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = lt(u), y = d.path(m, g), x = n.insert(() => y, ":first-child").attr("transform", `translate(${-c / 2}, ${c / 2})`);
  return f && t.look !== "handDrawn" && x.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), t.width = l, t.height = c, G(t, x), s.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${c / 2 - (a.height + (t.padding ?? 0) / (o ? 2 : 1) - (a.y - (a.top ?? 0)))})`
  ), t.intersect = function(b) {
    return F.info("Triangle intersect", t, u, b), W.polygon(t, u, b);
  }, n;
}
p(Eg, "triangle");
async function Fg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = l / 8, h = l + c, { cssStyles: u } = t, d = 70 - o, g = d > 0 ? d / 2 : 0, m = j.svg(n), y = Y(t, {});
  t.look !== "handDrawn" && (y.roughness = 0, y.fillStyle = "solid");
  const x = [
    { x: -o / 2 - g, y: h / 2 },
    ...Ue(
      -o / 2 - g,
      h / 2,
      o / 2 + g,
      h / 2,
      c,
      0.8
    ),
    { x: o / 2 + g, y: -h / 2 },
    { x: -o / 2 - g, y: -h / 2 }
  ], b = lt(x), C = m.path(b, y), k = n.insert(() => C, ":first-child");
  return k.attr("class", "basic label-container"), u && t.look !== "handDrawn" && k.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(0,${-c / 2})`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c - (a.y - (a.top ?? 0))})`
  ), G(t, k), t.intersect = function(w) {
    return W.polygon(t, x, w);
  }, n;
}
p(Fg, "waveEdgedRectangle");
async function Dg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = 100, o = 50, l = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), h = l / c;
  let u = l, f = c;
  u > f * h ? f = u / h : u = f * h, u = Math.max(u, s), f = Math.max(f, o);
  const d = Math.min(f * 0.2, f / 4), g = f + d * 2, { cssStyles: m } = t, y = j.svg(n), x = Y(t, {});
  t.look !== "handDrawn" && (x.roughness = 0, x.fillStyle = "solid");
  const b = [
    { x: -u / 2, y: g / 2 },
    ...Ue(-u / 2, g / 2, u / 2, g / 2, d, 1),
    { x: u / 2, y: -g / 2 },
    ...Ue(u / 2, -g / 2, -u / 2, -g / 2, d, -1)
  ], C = lt(b), k = y.path(C, x), w = n.insert(() => k, ":first-child");
  return w.attr("class", "basic label-container"), m && t.look !== "handDrawn" && w.selectAll("path").attr("style", m), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), G(t, w), t.intersect = function(A) {
    return W.polygon(t, b, A);
  }, n;
}
p(Dg, "waveRectangle");
async function Og(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = 5, h = -o / 2, u = -l / 2, { cssStyles: f } = t, d = j.svg(n), g = Y(t, {}), m = [
    { x: h - c, y: u - c },
    { x: h - c, y: u + l },
    { x: h + o, y: u + l },
    { x: h + o, y: u - c }
  ], y = `M${h - c},${u - c} L${h + o},${u - c} L${h + o},${u + l} L${h - c},${u + l} L${h - c},${u - c}
                M${h - c},${u} L${h + o},${u}
                M${h},${u - c} L${h},${u + l}`;
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = d.path(y, g), b = n.insert(() => x, ":first-child");
  return b.attr("transform", `translate(${c / 2}, ${c / 2})`), b.attr("class", "basic label-container"), f && t.look !== "handDrawn" && b.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), s.attr(
    "transform",
    `translate(${-(a.width / 2) + c / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c / 2 - (a.y - (a.top ?? 0))})`
  ), G(t, b), t.intersect = function(C) {
    return W.polygon(t, m, C);
  }, n;
}
p(Og, "windowPane");
async function Cl(e, t) {
  const r = t;
  if (r.alias && (t.label = r.alias), t.look === "handDrawn") {
    const { themeVariables: J } = Dt(), { background: Z } = J, ct = {
      ...t,
      id: t.id + "-background",
      look: "default",
      cssStyles: ["stroke: none", `fill: ${Z}`]
    };
    await Cl(e, ct);
  }
  const i = Dt();
  t.useHtmlLabels = i.htmlLabels;
  let n = i.er?.diagramPadding ?? 10, a = i.er?.entityPadding ?? 6;
  const { cssStyles: s } = t, { labelStyles: o, nodeStyles: l } = U(t);
  if (r.attributes.length === 0 && t.label) {
    const J = {
      rx: 0,
      ry: 0,
      labelPaddingX: n,
      labelPaddingY: n * 1.5
    };
    Oe(t.label, i) + J.labelPaddingX * 2 < i.er.minEntityWidth && (t.width = i.er.minEntityWidth);
    const Z = await Wa(e, t, J);
    if (!Bt(i.htmlLabels)) {
      const ct = Z.select("text"), at = ct.node()?.getBBox();
      ct.attr("transform", `translate(${-at.width / 2}, 0)`);
    }
    return Z;
  }
  i.htmlLabels || (n *= 1.25, a *= 1.25);
  let c = rt(t);
  c || (c = "node default");
  const h = e.insert("g").attr("class", c).attr("id", t.domId || t.id), u = await Mr(h, t.label ?? "", i, 0, 0, ["name"], o);
  u.height += a;
  let f = 0;
  const d = [], g = [];
  let m = 0, y = 0, x = 0, b = 0, C = !0, k = !0;
  for (const J of r.attributes) {
    const Z = await Mr(
      h,
      J.type,
      i,
      0,
      f,
      ["attribute-type"],
      o
    );
    m = Math.max(m, Z.width + n);
    const ct = await Mr(
      h,
      J.name,
      i,
      0,
      f,
      ["attribute-name"],
      o
    );
    y = Math.max(y, ct.width + n);
    const at = await Mr(
      h,
      J.keys.join(),
      i,
      0,
      f,
      ["attribute-keys"],
      o
    );
    x = Math.max(x, at.width + n);
    const bt = await Mr(
      h,
      J.comment,
      i,
      0,
      f,
      ["attribute-comment"],
      o
    );
    b = Math.max(b, bt.width + n);
    const Ct = Math.max(Z.height, ct.height, at.height, bt.height) + a;
    g.push({ yOffset: f, rowHeight: Ct }), f += Ct;
  }
  let w = 4;
  x <= n && (C = !1, x = 0, w--), b <= n && (k = !1, b = 0, w--);
  const A = h.node().getBBox();
  if (u.width + n * 2 - (m + y + x + b) > 0) {
    const J = u.width + n * 2 - (m + y + x + b);
    m += J / w, y += J / w, x > 0 && (x += J / w), b > 0 && (b += J / w);
  }
  const S = m + y + x + b, D = j.svg(h), I = Y(t, {});
  t.look !== "handDrawn" && (I.roughness = 0, I.fillStyle = "solid");
  let O = 0;
  g.length > 0 && (O = g.reduce((J, Z) => J + (Z?.rowHeight ?? 0), 0));
  const $ = Math.max(A.width + n * 2, t?.width || 0, S), N = Math.max((O ?? 0) + u.height, t?.height || 0), R = -$ / 2, B = -N / 2;
  h.selectAll("g:not(:first-child)").each((J, Z, ct) => {
    const at = ht(ct[Z]), bt = at.attr("transform");
    let Ct = 0, Pt = 0;
    if (bt) {
      const yt = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(bt);
      yt && (Ct = parseFloat(yt[1]), Pt = parseFloat(yt[2]), at.attr("class").includes("attribute-name") ? Ct += m : at.attr("class").includes("attribute-keys") ? Ct += m + y : at.attr("class").includes("attribute-comment") && (Ct += m + y + x));
    }
    at.attr(
      "transform",
      `translate(${R + n / 2 + Ct}, ${Pt + B + u.height + a / 2})`
    );
  }), h.select(".name").attr("transform", "translate(" + -u.width / 2 + ", " + (B + a / 2) + ")");
  const L = D.rectangle(R, B, $, N, I), T = h.insert(() => L, ":first-child").attr("style", s.join("")), { themeVariables: E } = Dt(), { rowEven: M, rowOdd: q, nodeBorder: X } = E;
  d.push(0);
  for (const [J, Z] of g.entries()) {
    const at = (J + 1) % 2 === 0 && Z.yOffset !== 0, bt = D.rectangle(R, u.height + B + Z?.yOffset, $, Z?.rowHeight, {
      ...I,
      fill: at ? M : q,
      stroke: X
    });
    h.insert(() => bt, "g.label").attr("style", s.join("")).attr("class", `row-rect-${at ? "even" : "odd"}`);
  }
  let K = D.line(R, u.height + B, $ + R, u.height + B, I);
  h.insert(() => K).attr("class", "divider"), K = D.line(m + R, u.height + B, m + R, N + B, I), h.insert(() => K).attr("class", "divider"), C && (K = D.line(
    m + y + R,
    u.height + B,
    m + y + R,
    N + B,
    I
  ), h.insert(() => K).attr("class", "divider")), k && (K = D.line(
    m + y + x + R,
    u.height + B,
    m + y + x + R,
    N + B,
    I
  ), h.insert(() => K).attr("class", "divider"));
  for (const J of d)
    K = D.line(
      R,
      u.height + B + J,
      $ + R,
      u.height + B + J,
      I
    ), h.insert(() => K).attr("class", "divider");
  if (G(t, T), l && t.look !== "handDrawn") {
    const Z = l.split(";")?.filter((ct) => ct.includes("stroke"))?.map((ct) => `${ct}`).join("; ");
    h.selectAll("path").attr("style", Z ?? ""), h.selectAll(".row-rect-even path").attr("style", l);
  }
  return t.intersect = function(J) {
    return W.rect(t, J);
  }, h;
}
p(Cl, "erBox");
async function Mr(e, t, r, i = 0, n = 0, a = [], s = "") {
  const o = e.insert("g").attr("class", `label ${a.join(" ")}`).attr("transform", `translate(${i}, ${n})`).attr("style", s);
  t !== tc(t) && (t = tc(t), t = t.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
  const l = o.node().appendChild(
    await Xe(
      o,
      t,
      {
        width: Oe(t, r) + 100,
        style: s,
        useHtmlLabels: r.htmlLabels
      },
      r
    )
  );
  if (t.includes("&lt;") || t.includes("&gt;")) {
    let h = l.children[0];
    for (h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">"); h.childNodes[0]; )
      h = h.childNodes[0], h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
  }
  let c = l.getBBox();
  if (Bt(r.htmlLabels)) {
    const h = l.children[0];
    h.style.textAlign = "start";
    const u = ht(l);
    c = h.getBoundingClientRect(), u.attr("width", c.width), u.attr("height", c.height);
  }
  return c;
}
p(Mr, "addText");
async function Rg(e, t, r, i, n = r.class.padding ?? 12) {
  const a = i ? 0 : 3, s = e.insert("g").attr("class", rt(t)).attr("id", t.domId || t.id);
  let o = null, l = null, c = null, h = null, u = 0, f = 0, d = 0;
  if (o = s.insert("g").attr("class", "annotation-group text"), t.annotations.length > 0) {
    const b = t.annotations[0];
    await vi(o, { text: `«${b}»` }, 0), u = o.node().getBBox().height;
  }
  l = s.insert("g").attr("class", "label-group text"), await vi(l, t, 0, ["font-weight: bolder"]);
  const g = l.node().getBBox();
  f = g.height, c = s.insert("g").attr("class", "members-group text");
  let m = 0;
  for (const b of t.members) {
    const C = await vi(c, b, m, [b.parseClassifier()]);
    m += C + a;
  }
  d = c.node().getBBox().height, d <= 0 && (d = n / 2), h = s.insert("g").attr("class", "methods-group text");
  let y = 0;
  for (const b of t.methods) {
    const C = await vi(h, b, y, [b.parseClassifier()]);
    y += C + a;
  }
  let x = s.node().getBBox();
  if (o !== null) {
    const b = o.node().getBBox();
    o.attr("transform", `translate(${-b.width / 2})`);
  }
  return l.attr("transform", `translate(${-g.width / 2}, ${u})`), x = s.node().getBBox(), c.attr(
    "transform",
    `translate(0, ${u + f + n * 2})`
  ), x = s.node().getBBox(), h.attr(
    "transform",
    `translate(0, ${u + f + (d ? d + n * 4 : n * 2)})`
  ), x = s.node().getBBox(), { shapeSvg: s, bbox: x };
}
p(Rg, "textHelper");
async function vi(e, t, r, i = []) {
  const n = e.insert("g").attr("class", "label").attr("style", i.join("; ")), a = Dt();
  let s = "useHtmlLabels" in t ? t.useHtmlLabels : Bt(a.htmlLabels) ?? !0, o = "";
  "text" in t ? o = t.text : o = t.label, !s && o.startsWith("\\") && (o = o.substring(1)), Yr(o) && (s = !0);
  const l = await Xe(
    n,
    Mo(Cr(o)),
    {
      width: Oe(o, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: s
    },
    a
  );
  let c, h = 1;
  if (s) {
    const u = l.children[0], f = ht(l);
    h = u.innerHTML.split("<br>").length, u.innerHTML.includes("</math>") && (h += u.innerHTML.split("<mrow>").length - 1);
    const d = u.getElementsByTagName("img");
    if (d) {
      const g = o.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...d].map(
          (m) => new Promise((y) => {
            function x() {
              if (m.style.display = "flex", m.style.flexDirection = "column", g) {
                const b = a.fontSize?.toString() ?? window.getComputedStyle(document.body).fontSize, k = parseInt(b, 10) * 5 + "px";
                m.style.minWidth = k, m.style.maxWidth = k;
              } else
                m.style.width = "100%";
              y(m);
            }
            p(x, "setupImage"), setTimeout(() => {
              m.complete && x();
            }), m.addEventListener("error", x), m.addEventListener("load", x);
          })
        )
      );
    }
    c = u.getBoundingClientRect(), f.attr("width", c.width), f.attr("height", c.height);
  } else {
    i.includes("font-weight: bolder") && ht(l).selectAll("tspan").attr("font-weight", ""), h = l.children.length;
    const u = l.children[0];
    (l.textContent === "" || l.textContent.includes("&gt")) && (u.textContent = o[0] + o.substring(1).replaceAll("&gt;", ">").replaceAll("&lt;", "<").trim(), o[1] === " " && (u.textContent = u.textContent[0] + " " + u.textContent.substring(1))), u.textContent === "undefined" && (u.textContent = ""), c = l.getBBox();
  }
  return n.attr("transform", "translate(0," + (-c.height / (2 * h) + r) + ")"), c.height;
}
p(vi, "addText");
async function Ig(e, t) {
  const r = ft(), i = r.class.padding ?? 12, n = i, a = t.useHtmlLabels ?? Bt(r.htmlLabels) ?? !0, s = t;
  s.annotations = s.annotations ?? [], s.members = s.members ?? [], s.methods = s.methods ?? [];
  const { shapeSvg: o, bbox: l } = await Rg(e, t, r, a, n), { labelStyles: c, nodeStyles: h } = U(t);
  t.labelStyle = c, t.cssStyles = s.styles || "";
  const u = s.styles?.join(";") || h || "";
  t.cssStyles || (t.cssStyles = u.replaceAll("!important", "").split(";"));
  const f = s.members.length === 0 && s.methods.length === 0 && !r.class?.hideEmptyMembersBox, d = j.svg(o), g = Y(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = l.width;
  let y = l.height;
  s.members.length === 0 && s.methods.length === 0 ? y += n : s.members.length > 0 && s.methods.length === 0 && (y += n * 2);
  const x = -m / 2, b = -y / 2, C = d.rectangle(
    x - i,
    b - i - (f ? i : s.members.length === 0 && s.methods.length === 0 ? -i / 2 : 0),
    m + 2 * i,
    y + 2 * i + (f ? i * 2 : s.members.length === 0 && s.methods.length === 0 ? -i : 0),
    g
  ), k = o.insert(() => C, ":first-child");
  k.attr("class", "basic label-container");
  const w = k.node().getBBox();
  o.selectAll(".text").each((I, O, $) => {
    const N = ht($[O]), R = N.attr("transform");
    let B = 0;
    if (R) {
      const M = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(R);
      M && (B = parseFloat(M[2]));
    }
    let L = B + b + i - (f ? i : s.members.length === 0 && s.methods.length === 0 ? -i / 2 : 0);
    a || (L -= 4);
    let T = x;
    (N.attr("class").includes("label-group") || N.attr("class").includes("annotation-group")) && (T = -N.node()?.getBBox().width / 2 || 0, o.selectAll("text").each(function(E, M, q) {
      window.getComputedStyle(q[M]).textAnchor === "middle" && (T = 0);
    })), N.attr("transform", `translate(${T}, ${L})`);
  });
  const A = o.select(".annotation-group").node().getBBox().height - (f ? i / 2 : 0) || 0, S = o.select(".label-group").node().getBBox().height - (f ? i / 2 : 0) || 0, D = o.select(".members-group").node().getBBox().height - (f ? i / 2 : 0) || 0;
  if (s.members.length > 0 || s.methods.length > 0 || f) {
    const I = d.line(
      w.x,
      A + S + b + i,
      w.x + w.width,
      A + S + b + i,
      g
    );
    o.insert(() => I).attr("class", "divider").attr("style", u);
  }
  if (f || s.members.length > 0 || s.methods.length > 0) {
    const I = d.line(
      w.x,
      A + S + D + b + n * 2 + i,
      w.x + w.width,
      A + S + D + b + i + n * 2,
      g
    );
    o.insert(() => I).attr("class", "divider").attr("style", u);
  }
  if (s.look !== "handDrawn" && o.selectAll("path").attr("style", u), k.select(":nth-child(2)").attr("style", u), o.selectAll(".divider").select("path").attr("style", u), t.labelStyle ? o.selectAll("span").attr("style", t.labelStyle) : o.selectAll("span").attr("style", u), !a) {
    const I = RegExp(/color\s*:\s*([^;]*)/), O = I.exec(u);
    if (O) {
      const $ = O[0].replace("color", "fill");
      o.selectAll("tspan").attr("style", $);
    } else if (c) {
      const $ = I.exec(c);
      if ($) {
        const N = $[0].replace("color", "fill");
        o.selectAll("tspan").attr("style", N);
      }
    }
  }
  return G(t, k), t.intersect = function(I) {
    return W.rect(t, I);
  }, o;
}
p(Ig, "classBox");
async function Pg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const n = t, a = t, s = 20, o = 20, l = "verifyMethod" in t, c = rt(t), h = e.insert("g").attr("class", c).attr("id", t.domId ?? t.id);
  let u;
  l ? u = await xe(
    h,
    `&lt;&lt;${n.type}&gt;&gt;`,
    0,
    t.labelStyle
  ) : u = await xe(h, "&lt;&lt;Element&gt;&gt;", 0, t.labelStyle);
  let f = u;
  const d = await xe(
    h,
    n.name,
    f,
    t.labelStyle + "; font-weight: bold;"
  );
  if (f += d + o, l) {
    const A = await xe(
      h,
      `${n.requirementId ? `ID: ${n.requirementId}` : ""}`,
      f,
      t.labelStyle
    );
    f += A;
    const S = await xe(
      h,
      `${n.text ? `Text: ${n.text}` : ""}`,
      f,
      t.labelStyle
    );
    f += S;
    const D = await xe(
      h,
      `${n.risk ? `Risk: ${n.risk}` : ""}`,
      f,
      t.labelStyle
    );
    f += D, await xe(
      h,
      `${n.verifyMethod ? `Verification: ${n.verifyMethod}` : ""}`,
      f,
      t.labelStyle
    );
  } else {
    const A = await xe(
      h,
      `${a.type ? `Type: ${a.type}` : ""}`,
      f,
      t.labelStyle
    );
    f += A, await xe(
      h,
      `${a.docRef ? `Doc Ref: ${a.docRef}` : ""}`,
      f,
      t.labelStyle
    );
  }
  const g = (h.node()?.getBBox().width ?? 200) + s, m = (h.node()?.getBBox().height ?? 200) + s, y = -g / 2, x = -m / 2, b = j.svg(h), C = Y(t, {});
  t.look !== "handDrawn" && (C.roughness = 0, C.fillStyle = "solid");
  const k = b.rectangle(y, x, g, m, C), w = h.insert(() => k, ":first-child");
  if (w.attr("class", "basic label-container").attr("style", i), h.selectAll(".label").each((A, S, D) => {
    const I = ht(D[S]), O = I.attr("transform");
    let $ = 0, N = 0;
    if (O) {
      const T = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(O);
      T && ($ = parseFloat(T[1]), N = parseFloat(T[2]));
    }
    const R = N - m / 2;
    let B = y + s / 2;
    (S === 0 || S === 1) && (B = $), I.attr("transform", `translate(${B}, ${R + s})`);
  }), f > u + d + o) {
    const A = b.line(
      y,
      x + u + d + o,
      y + g,
      x + u + d + o,
      C
    );
    h.insert(() => A).attr("style", i);
  }
  return G(t, w), t.intersect = function(A) {
    return W.rect(t, A);
  }, h;
}
p(Pg, "requirementBox");
async function xe(e, t, r, i = "") {
  if (t === "")
    return 0;
  const n = e.insert("g").attr("class", "label").attr("style", i), a = ft(), s = a.htmlLabels ?? !0, o = await Xe(
    n,
    Mo(Cr(t)),
    {
      width: Oe(t, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: s,
      style: i
    },
    a
  );
  let l;
  if (s) {
    const c = o.children[0], h = ht(o);
    l = c.getBoundingClientRect(), h.attr("width", l.width), h.attr("height", l.height);
  } else {
    const c = o.children[0];
    for (const h of c.children)
      h.textContent = h.textContent.replaceAll("&gt;", ">").replaceAll("&lt;", "<"), i && h.setAttribute("style", i);
    l = o.getBBox(), l.height += 6;
  }
  return n.attr("transform", `translate(${-l.width / 2},${-l.height / 2 + r})`), l.height;
}
p(xe, "addText");
var tS = /* @__PURE__ */ p((e) => {
  switch (e) {
    case "Very High":
      return "red";
    case "High":
      return "orange";
    case "Medium":
      return null;
    // no stroke
    case "Low":
      return "blue";
    case "Very Low":
      return "lightblue";
  }
}, "colorFromPriority");
async function Ng(e, t, { config: r }) {
  const { labelStyles: i, nodeStyles: n } = U(t);
  t.labelStyle = i || "";
  const a = 10, s = t.width;
  t.width = (t.width ?? 200) - 10;
  const {
    shapeSvg: o,
    bbox: l,
    label: c
  } = await it(e, t, rt(t)), h = t.padding || 10;
  let u = "", f;
  "ticket" in t && t.ticket && r?.kanban?.ticketBaseUrl && (u = r?.kanban?.ticketBaseUrl.replace("#TICKET#", t.ticket), f = o.insert("svg:a", ":first-child").attr("class", "kanban-ticket-link").attr("xlink:href", u).attr("target", "_blank"));
  const d = {
    useHtmlLabels: t.useHtmlLabels,
    labelStyle: t.labelStyle || "",
    width: t.width,
    img: t.img,
    padding: t.padding || 8,
    centerLabel: !1
  };
  let g, m;
  f ? { label: g, bbox: m } = await Cs(
    f,
    "ticket" in t && t.ticket || "",
    d
  ) : { label: g, bbox: m } = await Cs(
    o,
    "ticket" in t && t.ticket || "",
    d
  );
  const { label: y, bbox: x } = await Cs(
    o,
    "assigned" in t && t.assigned || "",
    d
  );
  t.width = s;
  const b = 10, C = t?.width || 0, k = Math.max(m.height, x.height) / 2, w = Math.max(l.height + b * 2, t?.height || 0) + k, A = -C / 2, S = -w / 2;
  c.attr(
    "transform",
    "translate(" + (h - C / 2) + ", " + (-k - l.height / 2) + ")"
  ), g.attr(
    "transform",
    "translate(" + (h - C / 2) + ", " + (-k + l.height / 2) + ")"
  ), y.attr(
    "transform",
    "translate(" + (h + C / 2 - x.width - 2 * a) + ", " + (-k + l.height / 2) + ")"
  );
  let D;
  const { rx: I, ry: O } = t, { cssStyles: $ } = t;
  if (t.look === "handDrawn") {
    const N = j.svg(o), R = Y(t, {}), B = I || O ? N.path(Ve(A, S, C, w, I || 0), R) : N.rectangle(A, S, C, w, R);
    D = o.insert(() => B, ":first-child"), D.attr("class", "basic label-container").attr("style", $ || null);
  } else {
    D = o.insert("rect", ":first-child"), D.attr("class", "basic label-container __APA__").attr("style", n).attr("rx", I ?? 5).attr("ry", O ?? 5).attr("x", A).attr("y", S).attr("width", C).attr("height", w);
    const N = "priority" in t && t.priority;
    if (N) {
      const R = o.append("line"), B = A + 2, L = S + Math.floor((I ?? 0) / 2), T = S + w - Math.floor((I ?? 0) / 2);
      R.attr("x1", B).attr("y1", L).attr("x2", B).attr("y2", T).attr("stroke-width", "4").attr("stroke", tS(N));
    }
  }
  return G(t, D), t.height = w, t.intersect = function(N) {
    return W.rect(t, N);
  }, o;
}
p(Ng, "kanbanItem");
async function zg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: s, label: o } = await it(
    e,
    t,
    rt(t)
  ), l = a.width + 10 * s, c = a.height + 8 * s, h = 0.15 * l, { cssStyles: u } = t, f = a.width + 20, d = a.height + 20, g = Math.max(l, f), m = Math.max(c, d);
  o.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`);
  let y;
  const x = `M0 0 
    a${h},${h} 1 0,0 ${g * 0.25},${-1 * m * 0.1}
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},${m * 0.1}

    a${h},${h} 1 0,0 ${g * 0.15},${m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${m * 0.34}
    a${h},${h} 1 0,0 ${-1 * g * 0.15},${m * 0.33}

    a${h},${h} 1 0,0 ${-1 * g * 0.25},${m * 0.15}
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},${-1 * m * 0.15}

    a${h},${h} 1 0,0 ${-1 * g * 0.1},${-1 * m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${-1 * m * 0.34}
    a${h},${h} 1 0,0 ${g * 0.1},${-1 * m * 0.33}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const b = j.svg(n), C = Y(t, {}), k = b.path(x, C);
    y = n.insert(() => k, ":first-child"), y.attr("class", "basic label-container").attr("style", Rt(u));
  } else
    y = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", x);
  return y.attr("transform", `translate(${-g / 2}, ${-m / 2})`), G(t, y), t.calcIntersect = function(b, C) {
    return W.rect(b, C);
  }, t.intersect = function(b) {
    return F.info("Bang intersect", t, b), W.rect(t, b);
  }, n;
}
p(zg, "bang");
async function Wg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: s, label: o } = await it(
    e,
    t,
    rt(t)
  ), l = a.width + 2 * s, c = a.height + 2 * s, h = 0.15 * l, u = 0.25 * l, f = 0.35 * l, d = 0.2 * l, { cssStyles: g } = t;
  let m;
  const y = `M0 0 
    a${h},${h} 0 0,1 ${l * 0.25},${-1 * l * 0.1}
    a${f},${f} 1 0,1 ${l * 0.4},${-1 * l * 0.1}
    a${u},${u} 1 0,1 ${l * 0.35},${l * 0.2}

    a${h},${h} 1 0,1 ${l * 0.15},${c * 0.35}
    a${d},${d} 1 0,1 ${-1 * l * 0.15},${c * 0.65}

    a${u},${h} 1 0,1 ${-1 * l * 0.25},${l * 0.15}
    a${f},${f} 1 0,1 ${-1 * l * 0.5},0
    a${h},${h} 1 0,1 ${-1 * l * 0.25},${-1 * l * 0.15}

    a${h},${h} 1 0,1 ${-1 * l * 0.1},${-1 * c * 0.35}
    a${d},${d} 1 0,1 ${l * 0.1},${-1 * c * 0.65}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const x = j.svg(n), b = Y(t, {}), C = x.path(y, b);
    m = n.insert(() => C, ":first-child"), m.attr("class", "basic label-container").attr("style", Rt(g));
  } else
    m = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", y);
  return o.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), m.attr("transform", `translate(${-l / 2}, ${-c / 2})`), G(t, m), t.calcIntersect = function(x, b) {
    return W.rect(x, b);
  }, t.intersect = function(x) {
    return F.info("Cloud intersect", t, x), W.rect(t, x);
  }, n;
}
p(Wg, "cloud");
async function qg(e, t) {
  const { labelStyles: r, nodeStyles: i } = U(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: s, label: o } = await it(
    e,
    t,
    rt(t)
  ), l = a.width + 8 * s, c = a.height + 2 * s, h = 5, u = `
    M${-l / 2} ${c / 2 - h}
    v${-c + 2 * h}
    q0,-${h} ${h},-${h}
    h${l - 2 * h}
    q${h},0 ${h},${h}
    v${c - 2 * h}
    q0,${h} -${h},${h}
    h${-l + 2 * h}
    q-${h},0 -${h},-${h}
    Z
  `, f = n.append("path").attr("id", "node-" + t.id).attr("class", "node-bkg node-" + t.type).attr("style", i).attr("d", u);
  return n.append("line").attr("class", "node-line-").attr("x1", -l / 2).attr("y1", c / 2).attr("x2", l / 2).attr("y2", c / 2), o.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), n.append(() => o.node()), G(t, f), t.calcIntersect = function(d, g) {
    return W.rect(d, g);
  }, t.intersect = function(d) {
    return W.rect(t, d);
  }, n;
}
p(qg, "defaultMindmapNode");
async function Hg(e, t) {
  const r = {
    padding: t.padding ?? 0
  };
  return bl(e, t, r);
}
p(Hg, "mindmapCircle");
var eS = [
  {
    semanticName: "Process",
    name: "Rectangle",
    shortName: "rect",
    description: "Standard process shape",
    aliases: ["proc", "process", "rectangle"],
    internalAliases: ["squareRect"],
    handler: Cg
  },
  {
    semanticName: "Event",
    name: "Rounded Rectangle",
    shortName: "rounded",
    description: "Represents an event",
    aliases: ["event"],
    internalAliases: ["roundedRect"],
    handler: yg
  },
  {
    semanticName: "Terminal Point",
    name: "Stadium",
    shortName: "stadium",
    description: "Terminal point",
    aliases: ["terminal", "pill"],
    handler: _g
  },
  {
    semanticName: "Subprocess",
    name: "Framed Rectangle",
    shortName: "fr-rect",
    description: "Subprocess",
    aliases: ["subprocess", "subproc", "framed-rectangle", "subroutine"],
    handler: Sg
  },
  {
    semanticName: "Database",
    name: "Cylinder",
    shortName: "cyl",
    description: "Database storage",
    aliases: ["db", "database", "cylinder"],
    handler: jp
  },
  {
    semanticName: "Start",
    name: "Circle",
    shortName: "circle",
    description: "Starting point",
    aliases: ["circ"],
    handler: bl
  },
  {
    semanticName: "Bang",
    name: "Bang",
    shortName: "bang",
    description: "Bang",
    aliases: ["bang"],
    handler: zg
  },
  {
    semanticName: "Cloud",
    name: "Cloud",
    shortName: "cloud",
    description: "cloud",
    aliases: ["cloud"],
    handler: Wg
  },
  {
    semanticName: "Decision",
    name: "Diamond",
    shortName: "diam",
    description: "Decision-making step",
    aliases: ["decision", "diamond", "question"],
    handler: pg
  },
  {
    semanticName: "Prepare Conditional",
    name: "Hexagon",
    shortName: "hex",
    description: "Preparation or condition step",
    aliases: ["hexagon", "prepare"],
    handler: Kp
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Right",
    shortName: "lean-r",
    description: "Represents input or output",
    aliases: ["lean-right", "in-out"],
    internalAliases: ["lean_right"],
    handler: og
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Left",
    shortName: "lean-l",
    description: "Represents output or input",
    aliases: ["lean-left", "out-in"],
    internalAliases: ["lean_left"],
    handler: sg
  },
  {
    semanticName: "Priority Action",
    name: "Trapezoid Base Bottom",
    shortName: "trap-b",
    description: "Priority action",
    aliases: ["priority", "trapezoid-bottom", "trapezoid"],
    handler: Mg
  },
  {
    semanticName: "Manual Operation",
    name: "Trapezoid Base Top",
    shortName: "trap-t",
    description: "Represents a manual task",
    aliases: ["manual", "trapezoid-top", "inv-trapezoid"],
    internalAliases: ["inv_trapezoid"],
    handler: ng
  },
  {
    semanticName: "Stop",
    name: "Double Circle",
    shortName: "dbl-circ",
    description: "Represents a stop point",
    aliases: ["double-circle"],
    internalAliases: ["doublecircle"],
    handler: Up
  },
  {
    semanticName: "Text Block",
    name: "Text Block",
    shortName: "text",
    description: "Text block",
    handler: Ag
  },
  {
    semanticName: "Card",
    name: "Notched Rectangle",
    shortName: "notch-rect",
    description: "Represents a card",
    aliases: ["card", "notched-rectangle"],
    handler: Rp
  },
  {
    semanticName: "Lined/Shaded Process",
    name: "Lined Rectangle",
    shortName: "lin-rect",
    description: "Lined process shape",
    aliases: ["lined-rectangle", "lined-process", "lin-proc", "shaded-process"],
    handler: xg
  },
  {
    semanticName: "Start",
    name: "Small Circle",
    shortName: "sm-circ",
    description: "Small starting point",
    aliases: ["start", "small-circle"],
    internalAliases: ["stateStart"],
    handler: vg
  },
  {
    semanticName: "Stop",
    name: "Framed Circle",
    shortName: "fr-circ",
    description: "Stop point",
    aliases: ["stop", "framed-circle"],
    internalAliases: ["stateEnd"],
    handler: kg
  },
  {
    semanticName: "Fork/Join",
    name: "Filled Rectangle",
    shortName: "fork",
    description: "Fork or join in process flow",
    aliases: ["join"],
    internalAliases: ["forkJoin"],
    handler: Vp
  },
  {
    semanticName: "Collate",
    name: "Hourglass",
    shortName: "hourglass",
    description: "Represents a collate operation",
    aliases: ["hourglass", "collate"],
    handler: Qp
  },
  {
    semanticName: "Comment",
    name: "Curly Brace",
    shortName: "brace",
    description: "Adds a comment",
    aliases: ["comment", "brace-l"],
    handler: zp
  },
  {
    semanticName: "Comment Right",
    name: "Curly Brace",
    shortName: "brace-r",
    description: "Adds a comment",
    handler: Wp
  },
  {
    semanticName: "Comment with braces on both sides",
    name: "Curly Braces",
    shortName: "braces",
    description: "Adds a comment",
    handler: qp
  },
  {
    semanticName: "Com Link",
    name: "Lightning Bolt",
    shortName: "bolt",
    description: "Communication link",
    aliases: ["com-link", "lightning-bolt"],
    handler: lg
  },
  {
    semanticName: "Document",
    name: "Document",
    shortName: "doc",
    description: "Represents a document",
    aliases: ["doc", "document"],
    handler: Fg
  },
  {
    semanticName: "Delay",
    name: "Half-Rounded Rectangle",
    shortName: "delay",
    description: "Represents a delay",
    aliases: ["half-rounded-rectangle"],
    handler: Zp
  },
  {
    semanticName: "Direct Access Storage",
    name: "Horizontal Cylinder",
    shortName: "h-cyl",
    description: "Direct access storage",
    aliases: ["das", "horizontal-cylinder"],
    handler: Lg
  },
  {
    semanticName: "Disk Storage",
    name: "Lined Cylinder",
    shortName: "lin-cyl",
    description: "Disk storage",
    aliases: ["disk", "lined-cylinder"],
    handler: cg
  },
  {
    semanticName: "Display",
    name: "Curved Trapezoid",
    shortName: "curv-trap",
    description: "Represents a display",
    aliases: ["curved-trapezoid", "display"],
    handler: Hp
  },
  {
    semanticName: "Divided Process",
    name: "Divided Rectangle",
    shortName: "div-rect",
    description: "Divided process shape",
    aliases: ["div-proc", "divided-rectangle", "divided-process"],
    handler: Yp
  },
  {
    semanticName: "Extract",
    name: "Triangle",
    shortName: "tri",
    description: "Extraction process",
    aliases: ["extract", "triangle"],
    handler: Eg
  },
  {
    semanticName: "Internal Storage",
    name: "Window Pane",
    shortName: "win-pane",
    description: "Internal storage",
    aliases: ["internal-storage", "window-pane"],
    handler: Og
  },
  {
    semanticName: "Junction",
    name: "Filled Circle",
    shortName: "f-circ",
    description: "Junction point",
    aliases: ["junction", "filled-circle"],
    handler: Gp
  },
  {
    semanticName: "Loop Limit",
    name: "Trapezoidal Pentagon",
    shortName: "notch-pent",
    description: "Loop limit step",
    aliases: ["loop-limit", "notched-pentagon"],
    handler: $g
  },
  {
    semanticName: "Manual File",
    name: "Flipped Triangle",
    shortName: "flip-tri",
    description: "Manual file operation",
    aliases: ["manual-file", "flipped-triangle"],
    handler: Xp
  },
  {
    semanticName: "Manual Input",
    name: "Sloped Rectangle",
    shortName: "sl-rect",
    description: "Manual input step",
    aliases: ["manual-input", "sloped-rectangle"],
    handler: bg
  },
  {
    semanticName: "Multi-Document",
    name: "Stacked Document",
    shortName: "docs",
    description: "Multiple documents",
    aliases: ["documents", "st-doc", "stacked-document"],
    handler: fg
  },
  {
    semanticName: "Multi-Process",
    name: "Stacked Rectangle",
    shortName: "st-rect",
    description: "Multiple processes",
    aliases: ["procs", "processes", "stacked-rectangle"],
    handler: ug
  },
  {
    semanticName: "Stored Data",
    name: "Bow Tie Rectangle",
    shortName: "bow-rect",
    description: "Stored data",
    aliases: ["stored-data", "bow-tie-rectangle"],
    handler: Op
  },
  {
    semanticName: "Summary",
    name: "Crossed Circle",
    shortName: "cross-circ",
    description: "Summary",
    aliases: ["summary", "crossed-circle"],
    handler: Np
  },
  {
    semanticName: "Tagged Document",
    name: "Tagged Document",
    shortName: "tag-doc",
    description: "Tagged document",
    aliases: ["tag-doc", "tagged-document"],
    handler: Bg
  },
  {
    semanticName: "Tagged Process",
    name: "Tagged Rectangle",
    shortName: "tag-rect",
    description: "Tagged process",
    aliases: ["tagged-rectangle", "tag-proc", "tagged-process"],
    handler: Tg
  },
  {
    semanticName: "Paper Tape",
    name: "Flag",
    shortName: "flag",
    description: "Paper tape",
    aliases: ["paper-tape"],
    handler: Dg
  },
  {
    semanticName: "Odd",
    name: "Odd",
    shortName: "odd",
    description: "Odd shape",
    internalAliases: ["rect_left_inv_arrow"],
    handler: gg
  },
  {
    semanticName: "Lined Document",
    name: "Lined Document",
    shortName: "lin-doc",
    description: "Lined document",
    aliases: ["lined-document"],
    handler: hg
  }
], rS = /* @__PURE__ */ p(() => {
  const t = [
    ...Object.entries({
      // States
      state: wg,
      choice: Ip,
      note: dg,
      // Rectangles
      rectWithTitle: mg,
      labelRect: ag,
      // Icons
      iconSquare: rg,
      iconCircle: tg,
      icon: Jp,
      iconRounded: eg,
      imageSquare: ig,
      anchor: Dp,
      // Kanban diagram
      kanbanItem: Ng,
      //Mindmap diagram
      mindmapCircle: Hg,
      defaultMindmapNode: qg,
      // class diagram
      classBox: Ig,
      // er diagram
      erBox: Cl,
      // Requirement diagram
      requirementBox: Pg
    }),
    ...eS.flatMap((r) => [
      r.shortName,
      ..."aliases" in r ? r.aliases : [],
      ..."internalAliases" in r ? r.internalAliases : []
    ].map((n) => [n, r.handler]))
  ];
  return Object.fromEntries(t);
}, "generateShapeMap"), jg = rS();
function iS(e) {
  return e in jg;
}
p(iS, "isValidShape");
var qa = /* @__PURE__ */ new Map();
async function Yg(e, t, r) {
  let i, n;
  t.shape === "rect" && (t.rx && t.ry ? t.shape = "roundedRect" : t.shape = "squareRect");
  const a = t.shape ? jg[t.shape] : void 0;
  if (!a)
    throw new Error(`No such shape: ${t.shape}. Please check your syntax.`);
  if (t.link) {
    let s;
    r.config.securityLevel === "sandbox" ? s = "_top" : t.linkTarget && (s = t.linkTarget || "_blank"), i = e.insert("svg:a").attr("xlink:href", t.link).attr("target", s ?? null), n = await a(i, t, r);
  } else
    n = await a(e, t, r), i = n;
  return t.tooltip && n.attr("title", t.tooltip), qa.set(t.id, i), t.haveCallback && i.attr("class", i.attr("class") + " clickable"), i;
}
p(Yg, "insertNode");
var pL = /* @__PURE__ */ p((e, t) => {
  qa.set(t.id, e);
}, "setNodeElem"), gL = /* @__PURE__ */ p(() => {
  qa.clear();
}, "clear"), mL = /* @__PURE__ */ p((e) => {
  const t = qa.get(e.id);
  F.trace(
    "Transforming node",
    e.diff,
    e,
    "translate(" + (e.x - e.width / 2 - 5) + ", " + e.width / 2 + ")"
  );
  const r = 8, i = e.diff || 0;
  return e.clusterNode ? t.attr(
    "transform",
    "translate(" + (e.x + i - e.width / 2) + ", " + (e.y - e.height / 2 - r) + ")"
  ) : t.attr("transform", "translate(" + e.x + ", " + e.y + ")"), i;
}, "positionNode"), nS = /* @__PURE__ */ p((e, t, r, i, n, a) => {
  t.arrowTypeStart && ch(e, "start", t.arrowTypeStart, r, i, n, a), t.arrowTypeEnd && ch(e, "end", t.arrowTypeEnd, r, i, n, a);
}, "addEdgeMarkers"), aS = {
  arrow_cross: { type: "cross", fill: !1 },
  arrow_point: { type: "point", fill: !0 },
  arrow_barb: { type: "barb", fill: !0 },
  arrow_circle: { type: "circle", fill: !1 },
  aggregation: { type: "aggregation", fill: !1 },
  extension: { type: "extension", fill: !1 },
  composition: { type: "composition", fill: !0 },
  dependency: { type: "dependency", fill: !0 },
  lollipop: { type: "lollipop", fill: !1 },
  only_one: { type: "onlyOne", fill: !1 },
  zero_or_one: { type: "zeroOrOne", fill: !1 },
  one_or_more: { type: "oneOrMore", fill: !1 },
  zero_or_more: { type: "zeroOrMore", fill: !1 },
  requirement_arrow: { type: "requirement_arrow", fill: !1 },
  requirement_contains: { type: "requirement_contains", fill: !1 }
}, ch = /* @__PURE__ */ p((e, t, r, i, n, a, s) => {
  const o = aS[r];
  if (!o) {
    F.warn(`Unknown arrow type: ${r}`);
    return;
  }
  const l = o.type, h = `${n}_${a}-${l}${t === "start" ? "Start" : "End"}`;
  if (s && s.trim() !== "") {
    const u = s.replace(/[^\dA-Za-z]/g, "_"), f = `${h}_${u}`;
    if (!document.getElementById(f)) {
      const d = document.getElementById(h);
      if (d) {
        const g = d.cloneNode(!0);
        g.id = f, g.querySelectorAll("path, circle, line").forEach((y) => {
          y.setAttribute("stroke", s), o.fill && y.setAttribute("fill", s);
        }), d.parentNode?.appendChild(g);
      }
    }
    e.attr(`marker-${t}`, `url(${i}#${f})`);
  } else
    e.attr(`marker-${t}`, `url(${i}#${h})`);
}, "addEdgeMarker"), ya = /* @__PURE__ */ new Map(), Mt = /* @__PURE__ */ new Map(), yL = /* @__PURE__ */ p(() => {
  ya.clear(), Mt.clear();
}, "clear"), Cn = /* @__PURE__ */ p((e) => e ? e.reduce((r, i) => r + ";" + i, "") : "", "getLabelStyles"), sS = /* @__PURE__ */ p(async (e, t) => {
  let r = Bt(ft().flowchart.htmlLabels);
  const { labelStyles: i } = U(t);
  t.labelStyle = i;
  const n = await Xe(e, t.label, {
    style: t.labelStyle,
    useHtmlLabels: r,
    addSvgBackground: !0,
    isNode: !1
  });
  F.info("abc82", t, t.labelType);
  const a = e.insert("g").attr("class", "edgeLabel"), s = a.insert("g").attr("class", "label").attr("data-id", t.id);
  s.node().appendChild(n);
  let o = n.getBBox();
  if (r) {
    const c = n.children[0], h = ht(n);
    o = c.getBoundingClientRect(), h.attr("width", o.width), h.attr("height", o.height);
  }
  s.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), ya.set(t.id, a), t.width = o.width, t.height = o.height;
  let l;
  if (t.startLabelLeft) {
    const c = await or(
      t.startLabelLeft,
      Cn(t.labelStyle)
    ), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    l = u.node().appendChild(c);
    const f = c.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), Mt.get(t.id) || Mt.set(t.id, {}), Mt.get(t.id).startLeft = h, Si(l, t.startLabelLeft);
  }
  if (t.startLabelRight) {
    const c = await or(
      t.startLabelRight,
      Cn(t.labelStyle)
    ), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    l = h.node().appendChild(c), u.node().appendChild(c);
    const f = c.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), Mt.get(t.id) || Mt.set(t.id, {}), Mt.get(t.id).startRight = h, Si(l, t.startLabelRight);
  }
  if (t.endLabelLeft) {
    const c = await or(t.endLabelLeft, Cn(t.labelStyle)), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    l = u.node().appendChild(c);
    const f = c.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), h.node().appendChild(c), Mt.get(t.id) || Mt.set(t.id, {}), Mt.get(t.id).endLeft = h, Si(l, t.endLabelLeft);
  }
  if (t.endLabelRight) {
    const c = await or(t.endLabelRight, Cn(t.labelStyle)), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    l = u.node().appendChild(c);
    const f = c.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), h.node().appendChild(c), Mt.get(t.id) || Mt.set(t.id, {}), Mt.get(t.id).endRight = h, Si(l, t.endLabelRight);
  }
  return n;
}, "insertEdgeLabel");
function Si(e, t) {
  ft().flowchart.htmlLabels && e && (e.style.width = t.length * 9 + "px", e.style.height = "12px");
}
p(Si, "setTerminalWidth");
var oS = /* @__PURE__ */ p((e, t) => {
  F.debug("Moving label abc88 ", e.id, e.label, ya.get(e.id), t);
  let r = t.updatedPath ? t.updatedPath : t.originalPath;
  const i = ft(), { subGraphTitleTotalMargin: n } = Zo(i);
  if (e.label) {
    const a = ya.get(e.id);
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcLabelPosition(r);
      F.debug(
        "Moving label " + e.label + " from (",
        s,
        ",",
        o,
        ") to (",
        l.x,
        ",",
        l.y,
        ") abc88"
      ), t.updatedPath && (s = l.x, o = l.y);
    }
    a.attr("transform", `translate(${s}, ${o + n / 2})`);
  }
  if (e.startLabelLeft) {
    const a = Mt.get(e.id).startLeft;
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", r);
      s = l.x, o = l.y;
    }
    a.attr("transform", `translate(${s}, ${o})`);
  }
  if (e.startLabelRight) {
    const a = Mt.get(e.id).startRight;
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcTerminalLabelPosition(
        e.arrowTypeStart ? 10 : 0,
        "start_right",
        r
      );
      s = l.x, o = l.y;
    }
    a.attr("transform", `translate(${s}, ${o})`);
  }
  if (e.endLabelLeft) {
    const a = Mt.get(e.id).endLeft;
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", r);
      s = l.x, o = l.y;
    }
    a.attr("transform", `translate(${s}, ${o})`);
  }
  if (e.endLabelRight) {
    const a = Mt.get(e.id).endRight;
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", r);
      s = l.x, o = l.y;
    }
    a.attr("transform", `translate(${s}, ${o})`);
  }
}, "positionEdgeLabel"), lS = /* @__PURE__ */ p((e, t) => {
  const r = e.x, i = e.y, n = Math.abs(t.x - r), a = Math.abs(t.y - i), s = e.width / 2, o = e.height / 2;
  return n >= s || a >= o;
}, "outsideNode"), cS = /* @__PURE__ */ p((e, t, r) => {
  F.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(r)}
  node        : x:${e.x} y:${e.y} w:${e.width} h:${e.height}`);
  const i = e.x, n = e.y, a = Math.abs(i - r.x), s = e.width / 2;
  let o = r.x < t.x ? s - a : s + a;
  const l = e.height / 2, c = Math.abs(t.y - r.y), h = Math.abs(t.x - r.x);
  if (Math.abs(n - t.y) * s > Math.abs(i - t.x) * l) {
    let u = r.y < t.y ? t.y - l - n : n - l - t.y;
    o = h * u / c;
    const f = {
      x: r.x < t.x ? r.x + o : r.x - h + o,
      y: r.y < t.y ? r.y + c - u : r.y - c + u
    };
    return o === 0 && (f.x = t.x, f.y = t.y), h === 0 && (f.x = t.x), c === 0 && (f.y = t.y), F.debug(`abc89 top/bottom calc, Q ${c}, q ${u}, R ${h}, r ${o}`, f), f;
  } else {
    r.x < t.x ? o = t.x - s - i : o = i - s - t.x;
    let u = c * o / h, f = r.x < t.x ? r.x + h - o : r.x - h + o, d = r.y < t.y ? r.y + u : r.y - u;
    return F.debug(`sides calc abc89, Q ${c}, q ${u}, R ${h}, r ${o}`, { _x: f, _y: d }), o === 0 && (f = t.x, d = t.y), h === 0 && (f = t.x), c === 0 && (d = t.y), { x: f, y: d };
  }
}, "intersection"), hh = /* @__PURE__ */ p((e, t) => {
  F.warn("abc88 cutPathAtIntersect", e, t);
  let r = [], i = e[0], n = !1;
  return e.forEach((a) => {
    if (F.info("abc88 checking point", a, t), !lS(t, a) && !n) {
      const s = cS(t, i, a);
      F.debug("abc88 inside", a, i, s), F.debug("abc88 intersection", s, t);
      let o = !1;
      r.forEach((l) => {
        o = o || l.x === s.x && l.y === s.y;
      }), r.some((l) => l.x === s.x && l.y === s.y) ? F.warn("abc88 no intersect", s, r) : r.push(s), n = !0;
    } else
      F.warn("abc88 outside", a, i), i = a, n || r.push(a);
  }), F.debug("returning points", r), r;
}, "cutPathAtIntersect");
function Ug(e) {
  const t = [], r = [];
  for (let i = 1; i < e.length - 1; i++) {
    const n = e[i - 1], a = e[i], s = e[i + 1];
    (n.x === a.x && a.y === s.y && Math.abs(a.x - s.x) > 5 && Math.abs(a.y - n.y) > 5 || n.y === a.y && a.x === s.x && Math.abs(a.x - n.x) > 5 && Math.abs(a.y - s.y) > 5) && (t.push(a), r.push(i));
  }
  return { cornerPoints: t, cornerPointPositions: r };
}
p(Ug, "extractCornerPoints");
var uh = /* @__PURE__ */ p(function(e, t, r) {
  const i = t.x - e.x, n = t.y - e.y, a = Math.sqrt(i * i + n * n), s = r / a;
  return { x: t.x - s * i, y: t.y - s * n };
}, "findAdjacentPoint"), hS = /* @__PURE__ */ p(function(e) {
  const { cornerPointPositions: t } = Ug(e), r = [];
  for (let i = 0; i < e.length; i++)
    if (t.includes(i)) {
      const n = e[i - 1], a = e[i + 1], s = e[i], o = uh(n, s, 5), l = uh(a, s, 5), c = l.x - o.x, h = l.y - o.y;
      r.push(o);
      const u = Math.sqrt(2) * 2;
      let f = { x: s.x, y: s.y };
      if (Math.abs(a.x - n.x) > 10 && Math.abs(a.y - n.y) >= 10) {
        F.debug(
          "Corner point fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
        const d = 5;
        s.x === o.x ? f = {
          x: c < 0 ? o.x - d + u : o.x + d - u,
          y: h < 0 ? o.y - u : o.y + u
        } : f = {
          x: c < 0 ? o.x - u : o.x + u,
          y: h < 0 ? o.y - d + u : o.y + d - u
        };
      } else
        F.debug(
          "Corner point skipping fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
      r.push(f, l);
    } else
      r.push(e[i]);
  return r;
}, "fixCorners"), uS = /* @__PURE__ */ p((e, t, r) => {
  const i = e - t - r, n = 2, a = 2, s = n + a, o = Math.floor(i / s), l = Array(o).fill(`${n} ${a}`).join(" ");
  return `0 ${t} ${l} ${r}`;
}, "generateDashArray"), fS = /* @__PURE__ */ p(function(e, t, r, i, n, a, s, o = !1) {
  const { handDrawnSeed: l } = ft();
  let c = t.points, h = !1;
  const u = n;
  var f = a;
  const d = [];
  for (const B in t.cssCompiledStyles)
    kd(B) || d.push(t.cssCompiledStyles[B]);
  F.debug("UIO intersect check", t.points, f.x, u.x), f.intersect && u.intersect && !o && (c = c.slice(1, t.points.length - 1), c.unshift(u.intersect(c[0])), F.debug(
    "Last point UIO",
    t.start,
    "-->",
    t.end,
    c[c.length - 1],
    f,
    f.intersect(c[c.length - 1])
  ), c.push(f.intersect(c[c.length - 1])));
  const g = btoa(JSON.stringify(c));
  t.toCluster && (F.info("to cluster abc88", r.get(t.toCluster)), c = hh(t.points, r.get(t.toCluster).node), h = !0), t.fromCluster && (F.debug(
    "from cluster abc88",
    r.get(t.fromCluster),
    JSON.stringify(c, null, 2)
  ), c = hh(c.reverse(), r.get(t.fromCluster).node).reverse(), h = !0);
  let m = c.filter((B) => !Number.isNaN(B.y));
  m = hS(m);
  let y = Ln;
  switch (y = Xn, t.curve) {
    case "linear":
      y = Xn;
      break;
    case "basis":
      y = Ln;
      break;
    case "cardinal":
      y = Tu;
      break;
    case "bumpX":
      y = _u;
      break;
    case "bumpY":
      y = wu;
      break;
    case "catmullRom":
      y = Au;
      break;
    case "monotoneX":
      y = Du;
      break;
    case "monotoneY":
      y = Ou;
      break;
    case "natural":
      y = Iu;
      break;
    case "step":
      y = Pu;
      break;
    case "stepAfter":
      y = zu;
      break;
    case "stepBefore":
      y = Nu;
      break;
    default:
      y = Ln;
  }
  const { x, y: b } = hC(t), C = G1().x(x).y(b).curve(y);
  let k;
  switch (t.thickness) {
    case "normal":
      k = "edge-thickness-normal";
      break;
    case "thick":
      k = "edge-thickness-thick";
      break;
    case "invisible":
      k = "edge-thickness-invisible";
      break;
    default:
      k = "edge-thickness-normal";
  }
  switch (t.pattern) {
    case "solid":
      k += " edge-pattern-solid";
      break;
    case "dotted":
      k += " edge-pattern-dotted";
      break;
    case "dashed":
      k += " edge-pattern-dashed";
      break;
    default:
      k += " edge-pattern-solid";
  }
  let w, A = t.curve === "rounded" ? Gg(Xg(m, t), 5) : C(m);
  const S = Array.isArray(t.style) ? t.style : [t.style];
  let D = S.find((B) => B?.startsWith("stroke:")), I = !1;
  if (t.look === "handDrawn") {
    const B = j.svg(e);
    Object.assign([], m);
    const L = B.path(A, {
      roughness: 0.3,
      seed: l
    });
    k += " transition", w = ht(L).select("path").attr("id", t.id).attr("class", " " + k + (t.classes ? " " + t.classes : "")).attr("style", S ? S.reduce((E, M) => E + ";" + M, "") : "");
    let T = w.attr("d");
    w.attr("d", T), e.node().appendChild(w.node());
  } else {
    const B = d.join(";"), L = S ? S.reduce((J, Z) => J + Z + ";", "") : "";
    let T = "";
    t.animate && (T = " edge-animation-fast"), t.animation && (T = " edge-animation-" + t.animation);
    const E = (B ? B + ";" + L + ";" : L) + ";" + (S ? S.reduce((J, Z) => J + ";" + Z, "") : "");
    w = e.append("path").attr("d", A).attr("id", t.id).attr(
      "class",
      " " + k + (t.classes ? " " + t.classes : "") + (T ?? "")
    ).attr("style", E), D = E.match(/stroke:([^;]+)/)?.[1], I = t.animate === !0 || !!t.animation || B.includes("animation");
    const M = w.node(), q = typeof M.getTotalLength == "function" ? M.getTotalLength() : 0, X = Bc[t.arrowTypeStart] || 0, K = Bc[t.arrowTypeEnd] || 0;
    if (t.look === "neo" && !I) {
      const Z = `stroke-dasharray: ${t.pattern === "dotted" || t.pattern === "dashed" ? uS(q, X, K) : `0 ${X} ${q - X - K} ${K}`}; stroke-dashoffset: 0;`;
      w.attr("style", Z + w.attr("style"));
    }
  }
  w.attr("data-edge", !0), w.attr("data-et", "edge"), w.attr("data-id", t.id), w.attr("data-points", g), t.showPoints && m.forEach((B) => {
    e.append("circle").style("stroke", "red").style("fill", "red").attr("r", 1).attr("cx", B.x).attr("cy", B.y);
  });
  let O = "";
  (ft().flowchart.arrowMarkerAbsolute || ft().state.arrowMarkerAbsolute) && (O = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, O = O.replace(/\(/g, "\\(").replace(/\)/g, "\\)")), F.info("arrowTypeStart", t.arrowTypeStart), F.info("arrowTypeEnd", t.arrowTypeEnd), nS(w, t, O, s, i, D);
  const $ = Math.floor(c.length / 2), N = c[$];
  ce.isLabelCoordinateInPath(N, w.attr("d")) || (h = !0);
  let R = {};
  return h && (R.updatedPath = c), R.originalPath = t.points, R;
}, "insertEdge");
function Gg(e, t) {
  if (e.length < 2)
    return "";
  let r = "";
  const i = e.length, n = 1e-5;
  for (let a = 0; a < i; a++) {
    const s = e[a], o = e[a - 1], l = e[a + 1];
    if (a === 0)
      r += `M${s.x},${s.y}`;
    else if (a === i - 1)
      r += `L${s.x},${s.y}`;
    else {
      const c = s.x - o.x, h = s.y - o.y, u = l.x - s.x, f = l.y - s.y, d = Math.hypot(c, h), g = Math.hypot(u, f);
      if (d < n || g < n) {
        r += `L${s.x},${s.y}`;
        continue;
      }
      const m = c / d, y = h / d, x = u / g, b = f / g, C = m * x + y * b, k = Math.max(-1, Math.min(1, C)), w = Math.acos(k);
      if (w < n || Math.abs(Math.PI - w) < n) {
        r += `L${s.x},${s.y}`;
        continue;
      }
      const A = Math.min(t / Math.sin(w / 2), d / 2, g / 2), S = s.x - m * A, D = s.y - y * A, I = s.x + x * A, O = s.y + b * A;
      r += `L${S},${D}`, r += `Q${s.x},${s.y} ${I},${O}`;
    }
  }
  return r;
}
p(Gg, "generateRoundedPath");
function po(e, t) {
  if (!e || !t)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  const r = t.x - e.x, i = t.y - e.y;
  return { angle: Math.atan2(i, r), deltaX: r, deltaY: i };
}
p(po, "calculateDeltaAndAngle");
function Xg(e, t) {
  const r = e.map((n) => ({ ...n }));
  if (e.length >= 2 && Ft[t.arrowTypeStart]) {
    const n = Ft[t.arrowTypeStart], a = e[0], s = e[1], { angle: o } = po(a, s), l = n * Math.cos(o), c = n * Math.sin(o);
    r[0].x = a.x + l, r[0].y = a.y + c;
  }
  const i = e.length;
  if (i >= 2 && Ft[t.arrowTypeEnd]) {
    const n = Ft[t.arrowTypeEnd], a = e[i - 1], s = e[i - 2], { angle: o } = po(s, a), l = n * Math.cos(o), c = n * Math.sin(o);
    r[i - 1].x = a.x - l, r[i - 1].y = a.y - c;
  }
  return r;
}
p(Xg, "applyMarkerOffsetsToPoints");
var dS = /* @__PURE__ */ p((e, t, r, i) => {
  t.forEach((n) => {
    LS[n](e, r, i);
  });
}, "insertMarkers"), pS = /* @__PURE__ */ p((e, t, r) => {
  F.trace("Making markers for ", r), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
}, "extension"), gS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "composition"), mS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "aggregation"), yS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "dependency"), xS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
}, "lollipop"), bS = /* @__PURE__ */ p((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "point"), CS = /* @__PURE__ */ p((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "circle"), _S = /* @__PURE__ */ p((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
}, "cross"), wS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "barb"), kS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneStart").attr("class", "marker onlyOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M9,0 L9,18 M15,0 L15,18"), e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneEnd").attr("class", "marker onlyOne " + t).attr("refX", 18).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M3,0 L3,18 M9,0 L9,18");
}, "only_one"), vS = /* @__PURE__ */ p((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneStart").attr("class", "marker zeroOrOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 21).attr("cy", 9).attr("r", 6), i.append("path").attr("d", "M9,0 L9,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneEnd").attr("class", "marker zeroOrOne " + t).attr("refX", 30).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 9).attr("r", 6), n.append("path").attr("d", "M21,0 L21,18");
}, "zero_or_one"), SS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreStart").attr("class", "marker oneOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M0,18 Q 18,0 36,18 Q 18,36 0,18 M42,9 L42,27"), e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreEnd").attr("class", "marker oneOrMore " + t).attr("refX", 27).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M3,9 L3,27 M9,18 Q27,0 45,18 Q27,36 9,18");
}, "one_or_more"), TS = /* @__PURE__ */ p((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreStart").attr("class", "marker zeroOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 48).attr("cy", 18).attr("r", 6), i.append("path").attr("d", "M0,18 Q18,0 36,18 Q18,36 0,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreEnd").attr("class", "marker zeroOrMore " + t).attr("refX", 39).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 18).attr("r", 6), n.append("path").attr("d", "M21,18 Q39,0 57,18 Q39,36 21,18");
}, "zero_or_more"), BS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_arrowEnd").attr("refX", 20).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("path").attr(
    "d",
    `M0,0
      L20,10
      M20,10
      L0,20`
  );
}, "requirement_arrow"), AS = /* @__PURE__ */ p((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_containsStart").attr("refX", 0).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("g");
  i.append("circle").attr("cx", 10).attr("cy", 10).attr("r", 9).attr("fill", "none"), i.append("line").attr("x1", 1).attr("x2", 19).attr("y1", 10).attr("y2", 10), i.append("line").attr("y1", 1).attr("y2", 19).attr("x1", 10).attr("x2", 10);
}, "requirement_contains"), LS = {
  extension: pS,
  composition: gS,
  aggregation: mS,
  dependency: yS,
  lollipop: xS,
  point: bS,
  circle: CS,
  cross: _S,
  barb: wS,
  only_one: kS,
  zero_or_one: vS,
  one_or_more: SS,
  zero_or_more: TS,
  requirement_arrow: BS,
  requirement_contains: AS
}, MS = dS, $S = {
  common: Qr,
  getConfig: Dt,
  insertCluster: Nv,
  insertEdge: fS,
  insertEdgeLabel: sS,
  insertMarkers: MS,
  insertNode: Yg,
  interpolateToCurve: el,
  labelHelper: it,
  log: F,
  positionEdgeLabel: oS
}, Hi = {}, Vg = /* @__PURE__ */ p((e) => {
  for (const t of e)
    Hi[t.name] = t;
}, "registerLayoutLoaders"), ES = /* @__PURE__ */ p(() => {
  Vg([
    {
      name: "dagre",
      loader: /* @__PURE__ */ p(async () => await import("./dagre-6UL2VRFP-DlElnUNt.js"), "loader")
    },
    {
      name: "cose-bilkent",
      loader: /* @__PURE__ */ p(async () => await import("./cose-bilkent-S5V4N54A-MJBdzCIx.js"), "loader")
    }
  ]);
}, "registerDefaultLayoutLoaders");
ES();
var xL = /* @__PURE__ */ p(async (e, t) => {
  if (!(e.layoutAlgorithm in Hi))
    throw new Error(`Unknown layout algorithm: ${e.layoutAlgorithm}`);
  const r = Hi[e.layoutAlgorithm];
  return (await r.loader()).render(e, t, $S, {
    algorithm: r.algorithm
  });
}, "render"), bL = /* @__PURE__ */ p((e = "", { fallback: t = "dagre" } = {}) => {
  if (e in Hi)
    return e;
  if (t in Hi)
    return F.warn(`Layout algorithm ${e} is not registered. Using ${t} as fallback.`), t;
  throw new Error(`Both layout algorithms ${e} and ${t} are not registered.`);
}, "getRegisteredLayoutAlgorithm"), Zg = "comm", Kg = "rule", Qg = "decl", FS = "@import", DS = "@namespace", OS = "@keyframes", RS = "@layer", Jg = Math.abs, _l = String.fromCharCode;
function tm(e) {
  return e.trim();
}
function Dn(e, t, r) {
  return e.replace(t, r);
}
function IS(e, t, r) {
  return e.indexOf(t, r);
}
function Dr(e, t) {
  return e.charCodeAt(t) | 0;
}
function Zr(e, t, r) {
  return e.slice(t, r);
}
function be(e) {
  return e.length;
}
function PS(e) {
  return e.length;
}
function _n(e, t) {
  return t.push(e), e;
}
var Ha = 1, Kr = 1, em = 0, ee = 0, wt = 0, ii = "";
function wl(e, t, r, i, n, a, s, o) {
  return { value: e, root: t, parent: r, type: i, props: n, children: a, line: Ha, column: Kr, length: s, return: "", siblings: o };
}
function NS() {
  return wt;
}
function zS() {
  return wt = ee > 0 ? Dr(ii, --ee) : 0, Kr--, wt === 10 && (Kr = 1, Ha--), wt;
}
function ue() {
  return wt = ee < em ? Dr(ii, ee++) : 0, Kr++, wt === 10 && (Kr = 1, Ha++), wt;
}
function We() {
  return Dr(ii, ee);
}
function On() {
  return ee;
}
function ja(e, t) {
  return Zr(ii, e, t);
}
function ji(e) {
  switch (e) {
    // \0 \t \n \r \s whitespace token
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    // ! + , / > @ ~ isolate token
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    // ; { } breakpoint token
    case 59:
    case 123:
    case 125:
      return 4;
    // : accompanied token
    case 58:
      return 3;
    // " ' ( [ opening delimit token
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    // ) ] closing delimit token
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function WS(e) {
  return Ha = Kr = 1, em = be(ii = e), ee = 0, [];
}
function qS(e) {
  return ii = "", e;
}
function _s(e) {
  return tm(ja(ee - 1, go(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
}
function HS(e) {
  for (; (wt = We()) && wt < 33; )
    ue();
  return ji(e) > 2 || ji(wt) > 3 ? "" : " ";
}
function jS(e, t) {
  for (; --t && ue() && !(wt < 48 || wt > 102 || wt > 57 && wt < 65 || wt > 70 && wt < 97); )
    ;
  return ja(e, On() + (t < 6 && We() == 32 && ue() == 32));
}
function go(e) {
  for (; ue(); )
    switch (wt) {
      // ] ) " '
      case e:
        return ee;
      // " '
      case 34:
      case 39:
        e !== 34 && e !== 39 && go(wt);
        break;
      // (
      case 40:
        e === 41 && go(e);
        break;
      // \
      case 92:
        ue();
        break;
    }
  return ee;
}
function YS(e, t) {
  for (; ue() && e + wt !== 57; )
    if (e + wt === 84 && We() === 47)
      break;
  return "/*" + ja(t, ee - 1) + "*" + _l(e === 47 ? e : ue());
}
function US(e) {
  for (; !ji(We()); )
    ue();
  return ja(e, ee);
}
function GS(e) {
  return qS(Rn("", null, null, null, [""], e = WS(e), 0, [0], e));
}
function Rn(e, t, r, i, n, a, s, o, l) {
  for (var c = 0, h = 0, u = s, f = 0, d = 0, g = 0, m = 1, y = 1, x = 1, b = 0, C = "", k = n, w = a, A = i, S = C; y; )
    switch (g = b, b = ue()) {
      // (
      case 40:
        if (g != 108 && Dr(S, u - 1) == 58) {
          IS(S += Dn(_s(b), "&", "&\f"), "&\f", Jg(c ? o[c - 1] : 0)) != -1 && (x = -1);
          break;
        }
      // " ' [
      case 34:
      case 39:
      case 91:
        S += _s(b);
        break;
      // \t \n \r \s
      case 9:
      case 10:
      case 13:
      case 32:
        S += HS(g);
        break;
      // \
      case 92:
        S += jS(On() - 1, 7);
        continue;
      // /
      case 47:
        switch (We()) {
          case 42:
          case 47:
            _n(XS(YS(ue(), On()), t, r, l), l), (ji(g || 1) == 5 || ji(We() || 1) == 5) && be(S) && Zr(S, -1, void 0) !== " " && (S += " ");
            break;
          default:
            S += "/";
        }
        break;
      // {
      case 123 * m:
        o[c++] = be(S) * x;
      // } ; \0
      case 125 * m:
      case 59:
      case 0:
        switch (b) {
          // \0 }
          case 0:
          case 125:
            y = 0;
          // ;
          case 59 + h:
            x == -1 && (S = Dn(S, /\f/g, "")), d > 0 && (be(S) - u || m === 0 && g === 47) && _n(d > 32 ? dh(S + ";", i, r, u - 1, l) : dh(Dn(S, " ", "") + ";", i, r, u - 2, l), l);
            break;
          // @ ;
          case 59:
            S += ";";
          // { rule/at-rule
          default:
            if (_n(A = fh(S, t, r, c, h, n, o, C, k = [], w = [], u, a), a), b === 123)
              if (h === 0)
                Rn(S, t, A, A, k, a, u, o, w);
              else {
                switch (f) {
                  // c(ontainer)
                  case 99:
                    if (Dr(S, 3) === 110) break;
                  // l(ayer)
                  case 108:
                    if (Dr(S, 2) === 97) break;
                  default:
                    h = 0;
                  // d(ocument) m(edia) s(upports)
                  case 100:
                  case 109:
                  case 115:
                }
                h ? Rn(e, A, A, i && _n(fh(e, A, A, 0, 0, n, o, C, n, k = [], u, w), w), n, w, u, o, i ? k : w) : Rn(S, A, A, A, [""], w, 0, o, w);
              }
        }
        c = h = d = 0, m = x = 1, C = S = "", u = s;
        break;
      // :
      case 58:
        u = 1 + be(S), d = g;
      default:
        if (m < 1) {
          if (b == 123)
            --m;
          else if (b == 125 && m++ == 0 && zS() == 125)
            continue;
        }
        switch (S += _l(b), b * m) {
          // &
          case 38:
            x = h > 0 ? 1 : (S += "\f", -1);
            break;
          // ,
          case 44:
            o[c++] = (be(S) - 1) * x, x = 1;
            break;
          // @
          case 64:
            We() === 45 && (S += _s(ue())), f = We(), h = u = be(C = S += US(On())), b++;
            break;
          // -
          case 45:
            g === 45 && be(S) == 2 && (m = 0);
        }
    }
  return a;
}
function fh(e, t, r, i, n, a, s, o, l, c, h, u) {
  for (var f = n - 1, d = n === 0 ? a : [""], g = PS(d), m = 0, y = 0, x = 0; m < i; ++m)
    for (var b = 0, C = Zr(e, f + 1, f = Jg(y = s[m])), k = e; b < g; ++b)
      (k = tm(y > 0 ? d[b] + " " + C : Dn(C, /&\f/g, d[b]))) && (l[x++] = k);
  return wl(e, t, r, n === 0 ? Kg : o, l, c, h, u);
}
function XS(e, t, r, i) {
  return wl(e, t, r, Zg, _l(NS()), Zr(e, 2, -2), 0, i);
}
function dh(e, t, r, i, n) {
  return wl(e, t, r, Qg, Zr(e, 0, i), Zr(e, i + 1, -1), i, n);
}
function mo(e, t) {
  for (var r = "", i = 0; i < e.length; i++)
    r += t(e[i], i, e, t) || "";
  return r;
}
function VS(e, t, r, i) {
  switch (e.type) {
    case RS:
      if (e.children.length) break;
    case FS:
    case DS:
    case Qg:
      return e.return = e.return || e.value;
    case Zg:
      return "";
    case OS:
      return e.return = e.value + "{" + mo(e.children, i) + "}";
    case Kg:
      if (!be(e.value = e.props.join(","))) return "";
  }
  return be(r = mo(e.children, i)) ? e.return = e.value + "{" + r + "}" : "";
}
var ZS = Bd(Object.keys, Object), KS = Object.prototype, QS = KS.hasOwnProperty;
function JS(e) {
  if (!Fa(e))
    return ZS(e);
  var t = [];
  for (var r in Object(e))
    QS.call(e, r) && r != "constructor" && t.push(r);
  return t;
}
var yo = br(ve, "DataView"), xo = br(ve, "Promise"), bo = br(ve, "Set"), Co = br(ve, "WeakMap"), ph = "[object Map]", tT = "[object Object]", gh = "[object Promise]", mh = "[object Set]", yh = "[object WeakMap]", xh = "[object DataView]", eT = xr(yo), rT = xr(Wi), iT = xr(xo), nT = xr(bo), aT = xr(Co), rr = ti;
(yo && rr(new yo(new ArrayBuffer(1))) != xh || Wi && rr(new Wi()) != ph || xo && rr(xo.resolve()) != gh || bo && rr(new bo()) != mh || Co && rr(new Co()) != yh) && (rr = function(e) {
  var t = ti(e), r = t == tT ? e.constructor : void 0, i = r ? xr(r) : "";
  if (i)
    switch (i) {
      case eT:
        return xh;
      case rT:
        return ph;
      case iT:
        return gh;
      case nT:
        return mh;
      case aT:
        return yh;
    }
  return t;
});
var sT = "[object Map]", oT = "[object Set]", lT = Object.prototype, cT = lT.hasOwnProperty;
function bh(e) {
  if (e == null)
    return !0;
  if (Da(e) && (oa(e) || typeof e == "string" || typeof e.splice == "function" || Jo(e) || tl(e) || sa(e)))
    return !e.length;
  var t = rr(e);
  if (t == sT || t == oT)
    return !e.size;
  if (Fa(e))
    return !JS(e).length;
  for (var r in e)
    if (cT.call(e, r))
      return !1;
  return !0;
}
var rm = "c4", hT = /* @__PURE__ */ p((e) => /^\s*C4Context|C4Container|C4Component|C4Dynamic|C4Deployment/.test(e), "detector"), uT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./c4Diagram-YG6GDRKO-D78zSe2p.js");
  return { id: rm, diagram: e };
}, "loader"), fT = {
  id: rm,
  detector: hT,
  loader: uT
}, dT = fT, im = "flowchart", pT = /* @__PURE__ */ p((e, t) => t?.flowchart?.defaultRenderer === "dagre-wrapper" || t?.flowchart?.defaultRenderer === "elk" ? !1 : /^\s*graph/.test(e), "detector"), gT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./flowDiagram-NV44I4VS-C-omRWsC.js");
  return { id: im, diagram: e };
}, "loader"), mT = {
  id: im,
  detector: pT,
  loader: gT
}, yT = mT, nm = "flowchart-v2", xT = /* @__PURE__ */ p((e, t) => t?.flowchart?.defaultRenderer === "dagre-d3" ? !1 : (t?.flowchart?.defaultRenderer === "elk" && (t.layout = "elk"), /^\s*graph/.test(e) && t?.flowchart?.defaultRenderer === "dagre-wrapper" ? !0 : /^\s*flowchart/.test(e)), "detector"), bT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./flowDiagram-NV44I4VS-C-omRWsC.js");
  return { id: nm, diagram: e };
}, "loader"), CT = {
  id: nm,
  detector: xT,
  loader: bT
}, _T = CT, am = "er", wT = /* @__PURE__ */ p((e) => /^\s*erDiagram/.test(e), "detector"), kT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./erDiagram-Q2GNP2WA-MkOqhwug.js");
  return { id: am, diagram: e };
}, "loader"), vT = {
  id: am,
  detector: wT,
  loader: kT
}, ST = vT, sm = "gitGraph", TT = /* @__PURE__ */ p((e) => /^\s*gitGraph/.test(e), "detector"), BT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./gitGraphDiagram-NY62KEGX-CDCsGnik.js");
  return { id: sm, diagram: e };
}, "loader"), AT = {
  id: sm,
  detector: TT,
  loader: BT
}, LT = AT, om = "gantt", MT = /* @__PURE__ */ p((e) => /^\s*gantt/.test(e), "detector"), $T = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./ganttDiagram-JELNMOA3-oHWP_sg9.js");
  return { id: om, diagram: e };
}, "loader"), ET = {
  id: om,
  detector: MT,
  loader: $T
}, FT = ET, lm = "info", DT = /* @__PURE__ */ p((e) => /^\s*info/.test(e), "detector"), OT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./infoDiagram-WHAUD3N6-DNIj2mVr.js");
  return { id: lm, diagram: e };
}, "loader"), RT = {
  id: lm,
  detector: DT,
  loader: OT
}, cm = "pie", IT = /* @__PURE__ */ p((e) => /^\s*pie/.test(e), "detector"), PT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./pieDiagram-ADFJNKIX-FcoKB8GS.js");
  return { id: cm, diagram: e };
}, "loader"), NT = {
  id: cm,
  detector: IT,
  loader: PT
}, hm = "quadrantChart", zT = /* @__PURE__ */ p((e) => /^\s*quadrantChart/.test(e), "detector"), WT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./quadrantDiagram-AYHSOK5B-DGovwVdt.js");
  return { id: hm, diagram: e };
}, "loader"), qT = {
  id: hm,
  detector: zT,
  loader: WT
}, HT = qT, um = "xychart", jT = /* @__PURE__ */ p((e) => /^\s*xychart(-beta)?/.test(e), "detector"), YT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./xychartDiagram-PRI3JC2R-DNIKODl-.js");
  return { id: um, diagram: e };
}, "loader"), UT = {
  id: um,
  detector: jT,
  loader: YT
}, GT = UT, fm = "requirement", XT = /* @__PURE__ */ p((e) => /^\s*requirement(Diagram)?/.test(e), "detector"), VT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./requirementDiagram-UZGBJVZJ-CQ3kljuR.js");
  return { id: fm, diagram: e };
}, "loader"), ZT = {
  id: fm,
  detector: XT,
  loader: VT
}, KT = ZT, dm = "sequence", QT = /* @__PURE__ */ p((e) => /^\s*sequenceDiagram/.test(e), "detector"), JT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./sequenceDiagram-WL72ISMW-B5oDDKfs.js");
  return { id: dm, diagram: e };
}, "loader"), tB = {
  id: dm,
  detector: QT,
  loader: JT
}, eB = tB, pm = "class", rB = /* @__PURE__ */ p((e, t) => t?.class?.defaultRenderer === "dagre-wrapper" ? !1 : /^\s*classDiagram/.test(e), "detector"), iB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./classDiagram-2ON5EDUG-DO3iIuoX.js");
  return { id: pm, diagram: e };
}, "loader"), nB = {
  id: pm,
  detector: rB,
  loader: iB
}, aB = nB, gm = "classDiagram", sB = /* @__PURE__ */ p((e, t) => /^\s*classDiagram/.test(e) && t?.class?.defaultRenderer === "dagre-wrapper" ? !0 : /^\s*classDiagram-v2/.test(e), "detector"), oB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./classDiagram-v2-WZHVMYZB-DO3iIuoX.js");
  return { id: gm, diagram: e };
}, "loader"), lB = {
  id: gm,
  detector: sB,
  loader: oB
}, cB = lB, mm = "state", hB = /* @__PURE__ */ p((e, t) => t?.state?.defaultRenderer === "dagre-wrapper" ? !1 : /^\s*stateDiagram/.test(e), "detector"), uB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./stateDiagram-FKZM4ZOC-Dz_va1l_.js");
  return { id: mm, diagram: e };
}, "loader"), fB = {
  id: mm,
  detector: hB,
  loader: uB
}, dB = fB, ym = "stateDiagram", pB = /* @__PURE__ */ p((e, t) => !!(/^\s*stateDiagram-v2/.test(e) || /^\s*stateDiagram/.test(e) && t?.state?.defaultRenderer === "dagre-wrapper"), "detector"), gB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./stateDiagram-v2-4FDKWEC3-BcOdQqYc.js");
  return { id: ym, diagram: e };
}, "loader"), mB = {
  id: ym,
  detector: pB,
  loader: gB
}, yB = mB, xm = "journey", xB = /* @__PURE__ */ p((e) => /^\s*journey/.test(e), "detector"), bB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./journeyDiagram-XKPGCS4Q-C7R17s3C.js");
  return { id: xm, diagram: e };
}, "loader"), CB = {
  id: xm,
  detector: xB,
  loader: bB
}, _B = CB, wB = /* @__PURE__ */ p((e, t, r) => {
  F.debug(`rendering svg for syntax error
`);
  const i = r2(t), n = i.append("g");
  i.attr("viewBox", "0 0 2412 512"), jh(i, 100, 512, !0), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m411.313,123.313c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32-9.375,9.375-20.688-20.688c-12.484-12.5-32.766-12.5-45.25,0l-16,16c-1.261,1.261-2.304,2.648-3.31,4.051-21.739-8.561-45.324-13.426-70.065-13.426-105.867,0-192,86.133-192,192s86.133,192 192,192 192-86.133 192-192c0-24.741-4.864-48.327-13.426-70.065 1.402-1.007 2.79-2.049 4.051-3.31l16-16c12.5-12.492 12.5-32.758 0-45.25l-20.688-20.688 9.375-9.375 32.001-31.999zm-219.313,100.687c-52.938,0-96,43.063-96,96 0,8.836-7.164,16-16,16s-16-7.164-16-16c0-70.578 57.422-128 128-128 8.836,0 16,7.164 16,16s-7.164,16-16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m459.02,148.98c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l16,16c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16.001-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m340.395,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16-16c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l15.999,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m400,64c8.844,0 16-7.164 16-16v-32c0-8.836-7.156-16-16-16-8.844,0-16,7.164-16,16v32c0,8.836 7.156,16 16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m496,96.586h-32c-8.844,0-16,7.164-16,16 0,8.836 7.156,16 16,16h32c8.844,0 16-7.164 16-16 0-8.836-7.156-16-16-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m436.98,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688l32-32c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32c-6.251,6.25-6.251,16.375-0.001,22.625z"
  ), n.append("text").attr("class", "error-text").attr("x", 1440).attr("y", 250).attr("font-size", "150px").style("text-anchor", "middle").text("Syntax error in text"), n.append("text").attr("class", "error-text").attr("x", 1250).attr("y", 400).attr("font-size", "100px").style("text-anchor", "middle").text(`mermaid version ${r}`);
}, "draw"), bm = { draw: wB }, kB = bm, vB = {
  db: {},
  renderer: bm,
  parser: {
    parse: /* @__PURE__ */ p(() => {
    }, "parse")
  }
}, SB = vB, Cm = "flowchart-elk", TB = /* @__PURE__ */ p((e, t = {}) => (
  // If diagram explicitly states flowchart-elk
  /^\s*flowchart-elk/.test(e) || // If a flowchart/graph diagram has their default renderer set to elk
  /^\s*(flowchart|graph)/.test(e) && t?.flowchart?.defaultRenderer === "elk" ? (t.layout = "elk", !0) : !1
), "detector"), BB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./flowDiagram-NV44I4VS-C-omRWsC.js");
  return { id: Cm, diagram: e };
}, "loader"), AB = {
  id: Cm,
  detector: TB,
  loader: BB
}, LB = AB, _m = "timeline", MB = /* @__PURE__ */ p((e) => /^\s*timeline/.test(e), "detector"), $B = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./timeline-definition-IT6M3QCI-DKB3M3Ne.js");
  return { id: _m, diagram: e };
}, "loader"), EB = {
  id: _m,
  detector: MB,
  loader: $B
}, FB = EB, wm = "mindmap", DB = /* @__PURE__ */ p((e) => /^\s*mindmap/.test(e), "detector"), OB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./mindmap-definition-VGOIOE7T-Cijp5VNA.js");
  return { id: wm, diagram: e };
}, "loader"), RB = {
  id: wm,
  detector: DB,
  loader: OB
}, IB = RB, km = "kanban", PB = /* @__PURE__ */ p((e) => /^\s*kanban/.test(e), "detector"), NB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./kanban-definition-3W4ZIXB7-BEhk2-Sp.js");
  return { id: km, diagram: e };
}, "loader"), zB = {
  id: km,
  detector: PB,
  loader: NB
}, WB = zB, vm = "sankey", qB = /* @__PURE__ */ p((e) => /^\s*sankey(-beta)?/.test(e), "detector"), HB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./sankeyDiagram-TZEHDZUN-wQjCXajd.js");
  return { id: vm, diagram: e };
}, "loader"), jB = {
  id: vm,
  detector: qB,
  loader: HB
}, YB = jB, Sm = "packet", UB = /* @__PURE__ */ p((e) => /^\s*packet(-beta)?/.test(e), "detector"), GB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./diagram-S2PKOQOG-zPAb03f4.js");
  return { id: Sm, diagram: e };
}, "loader"), XB = {
  id: Sm,
  detector: UB,
  loader: GB
}, Tm = "radar", VB = /* @__PURE__ */ p((e) => /^\s*radar-beta/.test(e), "detector"), ZB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./diagram-QEK2KX5R-DxQ5D7sE.js");
  return { id: Tm, diagram: e };
}, "loader"), KB = {
  id: Tm,
  detector: VB,
  loader: ZB
}, Bm = "block", QB = /* @__PURE__ */ p((e) => /^\s*block(-beta)?/.test(e), "detector"), JB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./blockDiagram-VD42YOAC-JAZZvLVI.js");
  return { id: Bm, diagram: e };
}, "loader"), tA = {
  id: Bm,
  detector: QB,
  loader: JB
}, eA = tA, Am = "architecture", rA = /* @__PURE__ */ p((e) => /^\s*architecture/.test(e), "detector"), iA = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./architectureDiagram-VXUJARFQ-C4SsiiqO.js");
  return { id: Am, diagram: e };
}, "loader"), nA = {
  id: Am,
  detector: rA,
  loader: iA
}, aA = nA, Lm = "treemap", sA = /* @__PURE__ */ p((e) => /^\s*treemap/.test(e), "detector"), oA = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./diagram-PSM6KHXK-CeeV9Cwt.js");
  return { id: Lm, diagram: e };
}, "loader"), lA = {
  id: Lm,
  detector: sA,
  loader: oA
}, Ch = !1, Ya = /* @__PURE__ */ p(() => {
  Ch || (Ch = !0, Wn("error", SB, (e) => e.toLowerCase().trim() === "error"), Wn(
    "---",
    // --- diagram type may appear if YAML front-matter is not parsed correctly
    {
      db: {
        clear: /* @__PURE__ */ p(() => {
        }, "clear")
      },
      styles: {},
      // should never be used
      renderer: {
        draw: /* @__PURE__ */ p(() => {
        }, "draw")
      },
      parser: {
        parse: /* @__PURE__ */ p(() => {
          throw new Error(
            "Diagrams beginning with --- are not valid. If you were trying to use a YAML front-matter, please ensure that you've correctly opened and closed the YAML front-matter with un-indented `---` blocks"
          );
        }, "parse")
      },
      init: /* @__PURE__ */ p(() => null, "init")
      // no op
    },
    (e) => e.toLowerCase().trimStart().startsWith("---")
  ), Ts(LB, IB, aA), Ts(
    dT,
    WB,
    cB,
    aB,
    ST,
    FT,
    RT,
    NT,
    KT,
    eB,
    _T,
    yT,
    FB,
    LT,
    yB,
    dB,
    _B,
    HT,
    YB,
    XB,
    GT,
    eA,
    KB,
    lA
  ));
}, "addDiagrams"), cA = /* @__PURE__ */ p(async () => {
  F.debug("Loading registered diagrams");
  const t = (await Promise.allSettled(
    Object.entries(hr).map(async ([r, { detector: i, loader: n }]) => {
      if (n)
        try {
          Ms(r);
        } catch {
          try {
            const { diagram: a, id: s } = await n();
            Wn(s, a, i);
          } catch (a) {
            throw F.error(`Failed to load external diagram with key ${r}. Removing from detectors.`), delete hr[r], a;
          }
        }
    })
  )).filter((r) => r.status === "rejected");
  if (t.length > 0) {
    F.error(`Failed to load ${t.length} external diagrams`);
    for (const r of t)
      F.error(r);
    throw new Error(`Failed to load ${t.length} external diagrams`);
  }
}, "loadRegisteredDiagrams"), hA = "graphics-document document";
function Mm(e, t) {
  e.attr("role", hA), t !== "" && e.attr("aria-roledescription", t);
}
p(Mm, "setA11yDiagramInfo");
function $m(e, t, r, i) {
  if (e.insert !== void 0) {
    if (r) {
      const n = `chart-desc-${i}`;
      e.attr("aria-describedby", n), e.insert("desc", ":first-child").attr("id", n).text(r);
    }
    if (t) {
      const n = `chart-title-${i}`;
      e.attr("aria-labelledby", n), e.insert("title", ":first-child").attr("id", n).text(t);
    }
  }
}
p($m, "addSVGa11yTitleDescription");
var cr, _o = (cr = class {
  constructor(t, r, i, n, a) {
    this.type = t, this.text = r, this.db = i, this.parser = n, this.renderer = a;
  }
  static async fromText(t, r = {}) {
    const i = Dt(), n = vo(t, i);
    t = lk(t) + `
`;
    try {
      Ms(n);
    } catch {
      const c = E0(n);
      if (!c)
        throw new Eh(`Diagram ${n} not found.`);
      const { id: h, diagram: u } = await c();
      Wn(h, u);
    }
    const { db: a, parser: s, renderer: o, init: l } = Ms(n);
    return s.parser && (s.parser.yy = a), a.clear?.(), l?.(i), r.title && a.setDiagramTitle?.(r.title), await s.parse(t), new cr(n, t, a, s, o);
  }
  async render(t, r) {
    await this.renderer.draw(this.text, t, r, this);
  }
  getParser() {
    return this.parser;
  }
  getType() {
    return this.type;
  }
}, p(cr, "Diagram"), cr), _h = [], uA = /* @__PURE__ */ p(() => {
  _h.forEach((e) => {
    e();
  }), _h = [];
}, "attachFunctions"), fA = /* @__PURE__ */ p((e) => e.replace(/^\s*%%(?!{)[^\n]+\n?/gm, "").trimStart(), "cleanupComments");
function Em(e) {
  const t = e.match($h);
  if (!t)
    return {
      text: e,
      metadata: {}
    };
  let r = cC(t[1], {
    // To support config, we need JSON schema.
    // https://www.yaml.org/spec/1.2/spec.html#id2803231
    schema: lC
  }) ?? {};
  r = typeof r == "object" && !Array.isArray(r) ? r : {};
  const i = {};
  return r.displayMode && (i.displayMode = r.displayMode.toString()), r.title && (i.title = r.title.toString()), r.config && (i.config = r.config), {
    text: e.slice(t[0].length),
    metadata: i
  };
}
p(Em, "extractFrontMatter");
var dA = /* @__PURE__ */ p((e) => e.replace(/\r\n?/g, `
`).replace(
  /<(\w+)([^>]*)>/g,
  (t, r, i) => "<" + r + i.replace(/="([^"]*)"/g, "='$1'") + ">"
), "cleanupText"), pA = /* @__PURE__ */ p((e) => {
  const { text: t, metadata: r } = Em(e), { displayMode: i, title: n, config: a = {} } = r;
  return i && (a.gantt || (a.gantt = {}), a.gantt.displayMode = i), { title: n, config: a, text: t };
}, "processFrontmatter"), gA = /* @__PURE__ */ p((e) => {
  const t = ce.detectInit(e) ?? {}, r = ce.detectDirective(e, "wrap");
  return Array.isArray(r) ? t.wrap = r.some(({ type: i }) => i === "wrap") : r?.type === "wrap" && (t.wrap = !0), {
    text: Vw(e),
    directive: t
  };
}, "processDirectives");
function kl(e) {
  const t = dA(e), r = pA(t), i = gA(r.text), n = sl(r.config, i.directive);
  return e = fA(i.text), {
    code: e,
    title: r.title,
    config: n
  };
}
p(kl, "preprocessDiagram");
function Fm(e) {
  const t = new TextEncoder().encode(e), r = Array.from(t, (i) => String.fromCodePoint(i)).join("");
  return btoa(r);
}
p(Fm, "toBase64");
var mA = 5e4, yA = "graph TB;a[Maximum text size in diagram exceeded];style a fill:#faa", xA = "sandbox", bA = "loose", CA = "http://www.w3.org/2000/svg", _A = "http://www.w3.org/1999/xlink", wA = "http://www.w3.org/1999/xhtml", kA = "100%", vA = "100%", SA = "border:0;margin:0;", TA = "margin:0", BA = "allow-top-navigation-by-user-activation allow-popups", AA = 'The "iframe" tag is not supported by your browser.', LA = ["foreignobject"], MA = ["dominant-baseline"];
function vl(e) {
  const t = kl(e);
  return Nn(), X0(t.config ?? {}), t;
}
p(vl, "processAndSetConfigs");
async function Dm(e, t) {
  Ya();
  try {
    const { code: r, config: i } = vl(e);
    return { diagramType: (await Rm(r)).type, config: i };
  } catch (r) {
    if (t?.suppressErrors)
      return !1;
    throw r;
  }
}
p(Dm, "parse");
var wh = /* @__PURE__ */ p((e, t, r = []) => `
.${e} ${t} { ${r.join(" !important; ")} !important; }`, "cssImportantStyles"), $A = /* @__PURE__ */ p((e, t = /* @__PURE__ */ new Map()) => {
  let r = "";
  if (e.themeCSS !== void 0 && (r += `
${e.themeCSS}`), e.fontFamily !== void 0 && (r += `
:root { --mermaid-font-family: ${e.fontFamily}}`), e.altFontFamily !== void 0 && (r += `
:root { --mermaid-alt-font-family: ${e.altFontFamily}}`), t instanceof Map) {
    const s = e.htmlLabels ?? e.flowchart?.htmlLabels ? ["> *", "span"] : ["rect", "polygon", "ellipse", "circle", "path"];
    t.forEach((o) => {
      bh(o.styles) || s.forEach((l) => {
        r += wh(o.id, l, o.styles);
      }), bh(o.textStyles) || (r += wh(
        o.id,
        "tspan",
        (o?.textStyles || []).map((l) => l.replace("color", "fill"))
      ));
    });
  }
  return r;
}, "createCssStyles"), EA = /* @__PURE__ */ p((e, t, r, i) => {
  const n = $A(e, r), a = py(t, n, e.themeVariables);
  return mo(GS(`${i}{${a}}`), VS);
}, "createUserStyles"), FA = /* @__PURE__ */ p((e = "", t, r) => {
  let i = e;
  return !r && !t && (i = i.replace(
    /marker-end="url\([\d+./:=?A-Za-z-]*?#/g,
    'marker-end="url(#'
  )), i = Cr(i), i = i.replace(/<br>/g, "<br/>"), i;
}, "cleanUpSvgCode"), DA = /* @__PURE__ */ p((e = "", t) => {
  const r = t?.viewBox?.baseVal?.height ? t.viewBox.baseVal.height + "px" : vA, i = Fm(`<body style="${TA}">${e}</body>`);
  return `<iframe style="width:${kA};height:${r};${SA}" src="data:text/html;charset=UTF-8;base64,${i}" sandbox="${BA}">
  ${AA}
</iframe>`;
}, "putIntoIFrame"), kh = /* @__PURE__ */ p((e, t, r, i, n) => {
  const a = e.append("div");
  a.attr("id", r), i && a.attr("style", i);
  const s = a.append("svg").attr("id", t).attr("width", "100%").attr("xmlns", CA);
  return n && s.attr("xmlns:xlink", n), s.append("g"), e;
}, "appendDivSvgG");
function wo(e, t) {
  return e.append("iframe").attr("id", t).attr("style", "width: 100%; height: 100%;").attr("sandbox", "");
}
p(wo, "sandboxedIframe");
var OA = /* @__PURE__ */ p((e, t, r, i) => {
  e.getElementById(t)?.remove(), e.getElementById(r)?.remove(), e.getElementById(i)?.remove();
}, "removeExistingElements"), RA = /* @__PURE__ */ p(async function(e, t, r) {
  Ya();
  const i = vl(t);
  t = i.code;
  const n = Dt();
  F.debug(n), t.length > (n?.maxTextSize ?? mA) && (t = yA);
  const a = "#" + e, s = "i" + e, o = "#" + s, l = "d" + e, c = "#" + l, h = /* @__PURE__ */ p(() => {
    const R = ht(f ? o : c).node();
    R && "remove" in R && R.remove();
  }, "removeTempElements");
  let u = ht("body");
  const f = n.securityLevel === xA, d = n.securityLevel === bA, g = n.fontFamily;
  if (r !== void 0) {
    if (r && (r.innerHTML = ""), f) {
      const N = wo(ht(r), s);
      u = ht(N.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = ht(r);
    kh(u, e, l, `font-family: ${g}`, _A);
  } else {
    if (OA(document, e, l, s), f) {
      const N = wo(ht("body"), s);
      u = ht(N.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = ht("body");
    kh(u, e, l);
  }
  let m, y;
  try {
    m = await _o.fromText(t, { title: i.title });
  } catch (N) {
    if (n.suppressErrorRendering)
      throw h(), N;
    m = await _o.fromText("error"), y = N;
  }
  const x = u.select(c).node(), b = m.type, C = x.firstChild, k = C.firstChild, w = m.renderer.getClasses?.(t, m), A = EA(n, b, w, a), S = document.createElement("style");
  S.innerHTML = A, C.insertBefore(S, k);
  try {
    await m.renderer.draw(t, e, ql.version, m);
  } catch (N) {
    throw n.suppressErrorRendering ? h() : kB.draw(t, e, ql.version), N;
  }
  const D = u.select(`${c} svg`), I = m.db.getAccTitle?.(), O = m.db.getAccDescription?.();
  Im(b, D, I, O), u.select(`[id="${e}"]`).selectAll("foreignobject > *").attr("xmlns", wA);
  let $ = u.select(c).node().innerHTML;
  if (F.debug("config.arrowMarkerAbsolute", n.arrowMarkerAbsolute), $ = FA($, f, Bt(n.arrowMarkerAbsolute)), f) {
    const N = u.select(c + " svg").node();
    $ = DA($, N);
  } else d || ($ = Hr.sanitize($, {
    ADD_TAGS: LA,
    ADD_ATTR: MA,
    HTML_INTEGRATION_POINTS: { foreignobject: !0 }
  }));
  if (uA(), y)
    throw y;
  return h(), {
    diagramType: b,
    svg: $,
    bindFunctions: m.db.bindFunctions
  };
}, "render");
function Om(e = {}) {
  const t = St({}, e);
  t?.fontFamily && !t.themeVariables?.fontFamily && (t.themeVariables || (t.themeVariables = {}), t.themeVariables.fontFamily = t.fontFamily), U0(t), t?.theme && t.theme in Ee ? t.themeVariables = Ee[t.theme].getThemeVariables(
    t.themeVariables
  ) : t && (t.themeVariables = Ee.default.getThemeVariables(t.themeVariables));
  const r = typeof t == "object" ? Y0(t) : Ih();
  ko(r.logLevel), Ya();
}
p(Om, "initialize");
var Rm = /* @__PURE__ */ p((e, t = {}) => {
  const { code: r } = kl(e);
  return _o.fromText(r, t);
}, "getDiagramFromText");
function Im(e, t, r, i) {
  Mm(t, e), $m(t, r, i, t.attr("id"));
}
p(Im, "addA11yInfo");
var mr = Object.freeze({
  render: RA,
  parse: Dm,
  getDiagramFromText: Rm,
  initialize: Om,
  getConfig: Dt,
  setConfig: Ph,
  getSiteConfig: Ih,
  updateSiteConfig: G0,
  reset: /* @__PURE__ */ p(() => {
    Nn();
  }, "reset"),
  globalReset: /* @__PURE__ */ p(() => {
    Nn(jr);
  }, "globalReset"),
  defaultConfig: jr
});
ko(Dt().logLevel);
Nn(Dt());
var IA = /* @__PURE__ */ p((e, t, r) => {
  F.warn(e), al(e) ? (r && r(e.str, e.hash), t.push({ ...e, message: e.str, error: e })) : (r && r(e), e instanceof Error && t.push({
    str: e.message,
    message: e.message,
    hash: e.name,
    error: e
  }));
}, "handleError"), Pm = /* @__PURE__ */ p(async function(e = {
  querySelector: ".mermaid"
}) {
  try {
    await PA(e);
  } catch (t) {
    if (al(t) && F.error(t.str), Re.parseError && Re.parseError(t), !e.suppressErrors)
      throw F.error("Use the suppressErrors option to suppress these errors"), t;
  }
}, "run"), PA = /* @__PURE__ */ p(async function({ postRenderCallback: e, querySelector: t, nodes: r } = {
  querySelector: ".mermaid"
}) {
  const i = mr.getConfig();
  F.debug(`${e ? "" : "No "}Callback function found`);
  let n;
  if (r)
    n = r;
  else if (t)
    n = document.querySelectorAll(t);
  else
    throw new Error("Nodes and querySelector are both undefined");
  F.debug(`Found ${n.length} diagrams`), i?.startOnLoad !== void 0 && (F.debug("Start On Load: " + i?.startOnLoad), mr.updateSiteConfig({ startOnLoad: i?.startOnLoad }));
  const a = new ce.InitIDGenerator(i.deterministicIds, i.deterministicIDSeed);
  let s;
  const o = [];
  for (const l of Array.from(n)) {
    if (F.info("Rendering diagram: " + l.id), l.getAttribute("data-processed"))
      continue;
    l.setAttribute("data-processed", "true");
    const c = `mermaid-${a.next()}`;
    s = l.innerHTML, s = ap(ce.entityDecode(s)).trim().replace(/<br\s*\/?>/gi, "<br/>");
    const h = ce.detectInit(s);
    h && F.debug("Detected early reinit: ", h);
    try {
      const { svg: u, bindFunctions: f } = await qm(c, s, l);
      l.innerHTML = u, e && await e(c), f && f(l);
    } catch (u) {
      IA(u, o, Re.parseError);
    }
  }
  if (o.length > 0)
    throw o[0];
}, "runThrowsErrors"), Nm = /* @__PURE__ */ p(function(e) {
  mr.initialize(e);
}, "initialize"), NA = /* @__PURE__ */ p(async function(e, t, r) {
  F.warn("mermaid.init is deprecated. Please use run instead."), e && Nm(e);
  const i = { postRenderCallback: r, querySelector: ".mermaid" };
  typeof t == "string" ? i.querySelector = t : t && (t instanceof HTMLElement ? i.nodes = [t] : i.nodes = t), await Pm(i);
}, "init"), zA = /* @__PURE__ */ p(async (e, {
  lazyLoad: t = !0
} = {}) => {
  Ya(), Ts(...e), t === !1 && await cA();
}, "registerExternalDiagrams"), zm = /* @__PURE__ */ p(function() {
  if (Re.startOnLoad) {
    const { startOnLoad: e } = mr.getConfig();
    e && Re.run().catch((t) => F.error("Mermaid failed to initialize", t));
  }
}, "contentLoaded");
typeof document < "u" && window.addEventListener("load", zm, !1);
var WA = /* @__PURE__ */ p(function(e) {
  Re.parseError = e;
}, "setParseErrorHandler"), xa = [], ws = !1, Wm = /* @__PURE__ */ p(async () => {
  if (!ws) {
    for (ws = !0; xa.length > 0; ) {
      const e = xa.shift();
      if (e)
        try {
          await e();
        } catch (t) {
          F.error("Error executing queue", t);
        }
    }
    ws = !1;
  }
}, "executeQueue"), qA = /* @__PURE__ */ p(async (e, t) => new Promise((r, i) => {
  const n = /* @__PURE__ */ p(() => new Promise((a, s) => {
    mr.parse(e, t).then(
      (o) => {
        a(o), r(o);
      },
      (o) => {
        F.error("Error parsing", o), Re.parseError?.(o), s(o), i(o);
      }
    );
  }), "performCall");
  xa.push(n), Wm().catch(i);
}), "parse"), qm = /* @__PURE__ */ p((e, t, r) => new Promise((i, n) => {
  const a = /* @__PURE__ */ p(() => new Promise((s, o) => {
    mr.render(e, t, r).then(
      (l) => {
        s(l), i(l);
      },
      (l) => {
        F.error("Error parsing", l), Re.parseError?.(l), o(l), n(l);
      }
    );
  }), "performCall");
  xa.push(a), Wm().catch(n);
}), "render"), HA = /* @__PURE__ */ p(() => Object.keys(hr).map((e) => ({
  id: e
})), "getRegisteredDiagramsMetadata"), Re = {
  startOnLoad: !0,
  mermaidAPI: mr,
  parse: qA,
  render: qm,
  init: NA,
  run: Pm,
  registerExternalDiagrams: zA,
  registerLayoutLoaders: Vg,
  initialize: Nm,
  parseError: void 0,
  contentLoaded: zm,
  setParseErrorHandler: WA,
  detectType: vo,
  registerIconPacks: fv,
  getRegisteredDiagramsMetadata: HA
}, jA = Re;
const CL = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: jA
}, Symbol.toStringTag, { value: "Module" }));
export {
  Yh as $,
  Bi as A,
  r0 as B,
  ky as C,
  sl as D,
  Rh as E,
  Dt as F,
  tk as G,
  r2 as H,
  ql as I,
  lC as J,
  P0 as K,
  Yr as L,
  GA as M,
  Oa as N,
  iy as O,
  So as P,
  tc as Q,
  G1 as R,
  Ln as S,
  Jw as T,
  Ui as U,
  uy as V,
  Yi as W,
  H as X,
  et as Y,
  Yw as Z,
  p as _,
  yy as a,
  w_ as a$,
  H1 as a0,
  Po as a1,
  JA as a2,
  rL as a3,
  Br as a4,
  Cc as a5,
  bc as a6,
  nL as a7,
  iL as a8,
  eL as a9,
  pv as aA,
  j1 as aB,
  UA as aC,
  Da as aD,
  oa as aE,
  Id as aF,
  Ji as aG,
  fv as aH,
  uv as aI,
  Do as aJ,
  ze as aK,
  Di as aL,
  dc as aM,
  kb as aN,
  bw as aO,
  Od as aP,
  Ad as aQ,
  k_ as aR,
  na as aS,
  v_ as aT,
  Ki as aU,
  rr as aV,
  pw as aW,
  zc as aX,
  yr as aY,
  S_ as aZ,
  Jo as a_,
  KA as aa,
  QA as ab,
  tL as ac,
  sL as ad,
  aL as ae,
  Nv as af,
  Yg as ag,
  mL as ah,
  hC as ai,
  Bt as aj,
  Xe as ak,
  Zo as al,
  yp as am,
  Cr as an,
  Hd as ao,
  st as ap,
  _e as aq,
  MS as ar,
  gL as as,
  yL as at,
  dL as au,
  G as av,
  pL as aw,
  fS as ax,
  oS as ay,
  sS as az,
  my as b,
  A_ as b0,
  ei as b1,
  xw as b2,
  Ww as b3,
  F_ as b4,
  Dw as b5,
  Ko as b6,
  bh as b7,
  U as b8,
  kd as b9,
  CL as bA,
  Vt as ba,
  mb as bb,
  Fo as bc,
  au as bd,
  Xi as be,
  lu as bf,
  ZA as bg,
  e0 as bh,
  zw as bi,
  Fw as bj,
  qw as bk,
  Ma as bl,
  C_ as bm,
  Qo as bn,
  Dd as bo,
  jw as bp,
  ti as bq,
  Sw as br,
  JS as bs,
  Zi as bt,
  sa as bu,
  Ge as bv,
  Oc as bw,
  tl as bx,
  Md as by,
  bo as bz,
  ft as c,
  ht as d,
  jh as e,
  St as f,
  by as g,
  Oe as h,
  te as i,
  mC as j,
  Qr as k,
  F as l,
  Yd as m,
  XA as n,
  bL as o,
  Cy as p,
  _y as q,
  xL as r,
  xy as s,
  cC as t,
  ce as u,
  iS as v,
  ik as w,
  oL as x,
  gy as y,
  VA as z
};
