import { a as r } from "./mermaid-parser.core-BweWFFPJ.js";
import { P as t } from "./mermaid-parser.core-BweWFFPJ.js";
export {
  t as PacketModule,
  r as createPacketServices
};
