import { _ as i } from "./mermaid.core-SaKAUzus.js";
function t(c, e) {
  c.accDescr && e.setAccDescription?.(c.accDescr), c.accTitle && e.setAccTitle?.(c.accTitle), c.title && e.setDiagramTitle?.(c.title);
}
i(t, "populateCommonDb");
export {
  t as p
};
