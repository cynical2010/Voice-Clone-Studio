function J(n) {
  return Math.abs(n = Math.round(n)) >= 1e21 ? n.toLocaleString("en").replace(/,/g, "") : n.toString(10);
}
function j(n, t) {
  if (!isFinite(n) || n === 0) return null;
  var e = (n = t ? n.toExponential(t - 1) : n.toExponential()).indexOf("e"), i = n.slice(0, e);
  return [
    i.length > 1 ? i[0] + i.slice(2) : i,
    +n.slice(e + 1)
  ];
}
function K(n) {
  return n = j(Math.abs(n)), n ? n[1] : NaN;
}
function Q(n, t) {
  return function(e, i) {
    for (var o = e.length, a = [], c = 0, h = n[0], M = 0; o > 0 && h > 0 && (M + h + 1 > i && (h = Math.max(1, i - M)), a.push(e.substring(o -= h, o + h)), !((M += h + 1) > i)); )
      h = n[c = (c + 1) % n.length];
    return a.reverse().join(t);
  };
}
function V(n) {
  return function(t) {
    return t.replace(/[0-9]/g, function(e) {
      return n[+e];
    });
  };
}
var W = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;
function $(n) {
  if (!(t = W.exec(n))) throw new Error("invalid format: " + n);
  var t;
  return new L({
    fill: t[1],
    align: t[2],
    sign: t[3],
    symbol: t[4],
    zero: t[5],
    width: t[6],
    comma: t[7],
    precision: t[8] && t[8].slice(1),
    trim: t[9],
    type: t[10]
  });
}
$.prototype = L.prototype;
function L(n) {
  this.fill = n.fill === void 0 ? " " : n.fill + "", this.align = n.align === void 0 ? ">" : n.align + "", this.sign = n.sign === void 0 ? "-" : n.sign + "", this.symbol = n.symbol === void 0 ? "" : n.symbol + "", this.zero = !!n.zero, this.width = n.width === void 0 ? void 0 : +n.width, this.comma = !!n.comma, this.precision = n.precision === void 0 ? void 0 : +n.precision, this.trim = !!n.trim, this.type = n.type === void 0 ? "" : n.type + "";
}
L.prototype.toString = function() {
  return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (this.width === void 0 ? "" : Math.max(1, this.width | 0)) + (this.comma ? "," : "") + (this.precision === void 0 ? "" : "." + Math.max(0, this.precision | 0)) + (this.trim ? "~" : "") + this.type;
};
function _(n) {
  n: for (var t = n.length, e = 1, i = -1, o; e < t; ++e)
    switch (n[e]) {
      case ".":
        i = o = e;
        break;
      case "0":
        i === 0 && (i = e), o = e;
        break;
      default:
        if (!+n[e]) break n;
        i > 0 && (i = 0);
        break;
    }
  return i > 0 ? n.slice(0, i) + n.slice(o + 1) : n;
}
var N;
function v(n, t) {
  var e = j(n, t);
  if (!e) return N = void 0, n.toPrecision(t);
  var i = e[0], o = e[1], a = o - (N = Math.max(-8, Math.min(8, Math.floor(o / 3))) * 3) + 1, c = i.length;
  return a === c ? i : a > c ? i + new Array(a - c + 1).join("0") : a > 0 ? i.slice(0, a) + "." + i.slice(a) : "0." + new Array(1 - a).join("0") + j(n, Math.max(0, t + a - 1))[0];
}
function X(n, t) {
  var e = j(n, t);
  if (!e) return n + "";
  var i = e[0], o = e[1];
  return o < 0 ? "0." + new Array(-o).join("0") + i : i.length > o + 1 ? i.slice(0, o + 1) + "." + i.slice(o + 1) : i + new Array(o - i.length + 2).join("0");
}
const O = {
  "%": (n, t) => (n * 100).toFixed(t),
  b: (n) => Math.round(n).toString(2),
  c: (n) => n + "",
  d: J,
  e: (n, t) => n.toExponential(t),
  f: (n, t) => n.toFixed(t),
  g: (n, t) => n.toPrecision(t),
  o: (n) => Math.round(n).toString(8),
  p: (n, t) => X(n * 100, t),
  r: X,
  s: v,
  X: (n) => Math.round(n).toString(16).toUpperCase(),
  x: (n) => Math.round(n).toString(16)
};
function R(n) {
  return n;
}
var U = Array.prototype.map, Y = ["y", "z", "a", "f", "p", "n", "µ", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];
function nn(n) {
  var t = n.grouping === void 0 || n.thousands === void 0 ? R : Q(U.call(n.grouping, Number), n.thousands + ""), e = n.currency === void 0 ? "" : n.currency[0] + "", i = n.currency === void 0 ? "" : n.currency[1] + "", o = n.decimal === void 0 ? "." : n.decimal + "", a = n.numerals === void 0 ? R : V(U.call(n.numerals, String)), c = n.percent === void 0 ? "%" : n.percent + "", h = n.minus === void 0 ? "−" : n.minus + "", M = n.nan === void 0 ? "NaN" : n.nan + "";
  function T(f, g) {
    f = $(f);
    var b = f.fill, p = f.align, m = f.sign, w = f.symbol, S = f.zero, E = f.width, F = f.comma, y = f.precision, C = f.trim, d = f.type;
    d === "n" ? (F = !0, d = "g") : O[d] || (y === void 0 && (y = 12), C = !0, d = "g"), (S || b === "0" && p === "=") && (S = !0, b = "0", p = "=");
    var q = (g && g.prefix !== void 0 ? g.prefix : "") + (w === "$" ? e : w === "#" && /[boxX]/.test(d) ? "0" + d.toLowerCase() : ""), B = (w === "$" ? i : /[%p]/.test(d) ? c : "") + (g && g.suffix !== void 0 ? g.suffix : ""), D = O[d], H = /[defgprs%]/.test(d);
    y = y === void 0 ? 6 : /[gprs]/.test(d) ? Math.max(1, Math.min(21, y)) : Math.max(0, Math.min(20, y));
    function G(r) {
      var l = q, u = B, x, I, k;
      if (d === "c")
        u = D(r) + u, r = "";
      else {
        r = +r;
        var P = r < 0 || 1 / r < 0;
        if (r = isNaN(r) ? M : D(Math.abs(r), y), C && (r = _(r)), P && +r == 0 && m !== "+" && (P = !1), l = (P ? m === "(" ? m : h : m === "-" || m === "(" ? "" : m) + l, u = (d === "s" && !isNaN(r) && N !== void 0 ? Y[8 + N / 3] : "") + u + (P && m === "(" ? ")" : ""), H) {
          for (x = -1, I = r.length; ++x < I; )
            if (k = r.charCodeAt(x), 48 > k || k > 57) {
              u = (k === 46 ? o + r.slice(x + 1) : r.slice(x)) + u, r = r.slice(0, x);
              break;
            }
        }
      }
      F && !S && (r = t(r, 1 / 0));
      var z = l.length + r.length + u.length, s = z < E ? new Array(E - z + 1).join(b) : "";
      switch (F && S && (r = t(s + r, s.length ? E - u.length : 1 / 0), s = ""), p) {
        case "<":
          r = l + r + u + s;
          break;
        case "=":
          r = l + s + r + u;
          break;
        case "^":
          r = s.slice(0, z = s.length >> 1) + l + r + u + s.slice(z);
          break;
        default:
          r = s + l + r + u;
          break;
      }
      return a(r);
    }
    return G.toString = function() {
      return f + "";
    }, G;
  }
  function Z(f, g) {
    var b = Math.max(-8, Math.min(8, Math.floor(K(g) / 3))) * 3, p = Math.pow(10, -b), m = T((f = $(f), f.type = "f", f), { suffix: Y[8 + b / 3] });
    return function(w) {
      return m(p * w);
    };
  }
  return {
    format: T,
    formatPrefix: Z
  };
}
var A, tn, rn;
en({
  thousands: ",",
  grouping: [3],
  currency: ["$", ""]
});
function en(n) {
  return A = nn(n), tn = A.format, rn = A.formatPrefix, A;
}
export {
  rn as a,
  tn as b,
  K as e,
  $ as f
};
