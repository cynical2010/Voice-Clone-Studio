import { c as e } from "./mermaid-parser.core-BweWFFPJ.js";
import { I as t } from "./mermaid-parser.core-BweWFFPJ.js";
export {
  t as InfoModule,
  e as createInfoServices
};
