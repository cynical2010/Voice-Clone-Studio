import { b as r } from "./mermaid-parser.core-BweWFFPJ.js";
import { d as t } from "./mermaid-parser.core-BweWFFPJ.js";
export {
  t as PieModule,
  r as createPieServices
};
