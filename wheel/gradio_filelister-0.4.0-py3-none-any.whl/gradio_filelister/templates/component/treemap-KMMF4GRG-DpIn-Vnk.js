import { h as r } from "./mermaid-parser.core-BweWFFPJ.js";
import { T as m } from "./mermaid-parser.core-BweWFFPJ.js";
export {
  m as TreemapModule,
  r as createTreemapServices
};
