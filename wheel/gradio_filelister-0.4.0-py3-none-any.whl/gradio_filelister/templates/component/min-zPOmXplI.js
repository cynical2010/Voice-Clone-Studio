import { b, a as m, c as d, d as h, i as l } from "./_baseUniq-DDPDfPVw.js";
import { aD as g, aE as o, aF as p } from "./mermaid.core-SaKAUzus.js";
function L(a) {
  var n = a == null ? 0 : a.length;
  return n ? b(a) : [];
}
function v(a, n) {
  var s = -1, t = g(a) ? Array(a.length) : [];
  return m(a, function(f, i, e) {
    t[++s] = n(f, i, e);
  }), t;
}
function M(a, n) {
  var s = o(a) ? h : v;
  return s(a, d(n));
}
function x(a, n) {
  return a < n;
}
function A(a, n, s) {
  for (var t = -1, f = a.length; ++t < f; ) {
    var i = a[t], e = n(i);
    if (e != null && (r === void 0 ? e === e && !l(e) : s(e, r)))
      var r = e, u = i;
  }
  return u;
}
function k(a) {
  return a && a.length ? A(a, p, x) : void 0;
}
export {
  x as a,
  A as b,
  v as c,
  k as d,
  L as f,
  M as m
};
