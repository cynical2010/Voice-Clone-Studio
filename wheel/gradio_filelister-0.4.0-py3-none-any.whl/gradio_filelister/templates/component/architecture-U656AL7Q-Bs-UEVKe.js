import { e as r } from "./mermaid-parser.core-BweWFFPJ.js";
import { A as o } from "./mermaid-parser.core-BweWFFPJ.js";
export {
  o as ArchitectureModule,
  r as createArchitectureServices
};
