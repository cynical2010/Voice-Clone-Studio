import { g as a } from "./mermaid-parser.core-BweWFFPJ.js";
import { R as t } from "./mermaid-parser.core-BweWFFPJ.js";
export {
  t as RadarModule,
  a as createRadarServices
};
