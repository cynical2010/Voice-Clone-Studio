import "../../../../../assets/svelte/svelte_internal_flags_legacy.js";
import * as e from "../../../../../assets/svelte/svelte_internal_client.js";
var d = e.from_html("<div> </div>");
function c(f, r) {
  let a = e.prop(r, "value", 8), s = e.prop(r, "type", 8), n = e.prop(r, "selected", 8, !1);
  function p(t) {
    return t ? typeof t == "object" && t.files ? `${t.files.length} file(s)` : Array.isArray(t) ? `${t.length} file(s)` : String(t) : "";
  }
  var l = d();
  let i;
  var u = e.child(l, !0);
  e.reset(l), e.template_effect(
    (t) => {
      i = e.set_class(l, 1, "svelte-s3apn9", null, i, {
        table: s() === "table",
        gallery: s() === "gallery",
        selected: n()
      }), e.set_text(u, t);
    },
    [
      () => (e.deep_read_state(a()), e.untrack(() => p(a())))
    ]
  ), e.append(f, l);
}
export {
  c as default
};
